"""
测试脚本
@Time: 2024-12-30
"""

import argparse
import json
import logging
import os
import sys
from datetime import datetime

import numpy as np

from src.utils.visualization import plot_confusion_matrix, plot_per_class_recall

CLASS_NAMES_4 = ["Neutral", "Happy", "Sad", "Angry"]
CLASS_NAMES_7 = ["Neutral", "Happy", "Sad", "Angry", "Disgust", "Fear", "Surprise"]


def get_test_args():
    parser = argparse.ArgumentParser(description="Emotion Classification Test")

    parser.add_argument(
        "--results_dir", type=str, required=True, help="Path to experiment results directory"
    )
    parser.add_argument("--gpu", type=int, default=0)
    parser.add_argument("--seed", type=int, default=42)

    args = parser.parse_args()
    return args


def load_experiment_config(results_dir):
    json_files = [
        f for f in os.listdir(results_dir) if f.startswith("results_") and f.endswith(".json")
    ]
    if not json_files:
        raise FileNotFoundError(f"No results JSON found in {results_dir}")

    results_path = os.path.join(results_dir, json_files[0])
    with open(results_path, "r") as f:
        results = json.load(f)

    return results


def setup_logging(log_dir, exp_name):
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, f"{exp_name}.log")

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler(sys.stdout),
        ],
    )
    return logging.getLogger(__name__)


def print_detailed_results(logger, results, num_classes=4):
    class_names = CLASS_NAMES_4 if num_classes == 4 else CLASS_NAMES_7

    logger.info("\n" + "=" * 80)
    logger.info("DETAILED TEST RESULTS")
    logger.info("=" * 80)

    logger.info("\n[Overall Metrics]")
    overall = results["overall"]
    logger.info(
        f"  WA (Weighted Accuracy):     {overall['WA']['mean']:.4f} ± {overall['WA']['std']:.4f}"
    )
    logger.info(
        f"  UA (Unweighted Accuracy):   {overall['UA']['mean']:.4f} ± {overall['UA']['std']:.4f}"
    )
    logger.info(
        f"  Macro F1:                   {overall['macro_f1']['mean']:.4f} ± {overall['macro_f1']['std']:.4f}"
    )
    logger.info(
        f"  Weighted F1:                {overall['weighted_f1']['mean']:.4f} ± {overall['weighted_f1']['std']:.4f}"
    )
    logger.info(f"  Macro Precision:            {overall['macro_precision']:.4f}")
    logger.info(f"  Weighted Precision:         {overall['weighted_precision']:.4f}")

    logger.info("\n[Per-Fold Results]")
    logger.info(f"{'Fold':<6} {'WA':<10} {'UA':<10} {'Macro-F1':<12} {'Weighted-F1':<12}")
    logger.info("-" * 50)
    for fold_result in results["fold_results"]:
        logger.info(
            f"{fold_result['fold']:<6} "
            f"{fold_result['WA']:<10.4f} "
            f"{fold_result['UA']:<10.4f} "
            f"{fold_result['macro_f1']:<12.4f} "
            f"{fold_result['weighted_f1']:<12.4f}"
        )

    logger.info("\n[Per-Class Metrics (Averaged across folds)]")
    avg_recall = np.mean([f["per_class_recall"] for f in results["fold_results"]], axis=0)
    avg_precision = np.mean([f["per_class_precision"] for f in results["fold_results"]], axis=0)
    avg_f1 = np.mean([f["per_class_f1"] for f in results["fold_results"]], axis=0)

    logger.info(f"{'Class':<12} {'Recall':<12} {'Precision':<12} {'F1':<12}")
    logger.info("-" * 48)
    for i, name in enumerate(class_names):
        logger.info(
            f"{name:<12} {avg_recall[i]:<12.4f} {avg_precision[i]:<12.4f} {avg_f1[i]:<12.4f}"
        )

    logger.info("\n[Aggregated Confusion Matrix]")
    cm = np.array(results["aggregated_confusion_matrix"])

    header = "Pred→  " + "  ".join([f"{name[:4]:>6}" for name in class_names])
    logger.info(header)
    logger.info("-" * len(header))
    for i, name in enumerate(class_names):
        row = f"{name[:4]:<6} " + "  ".join([f"{cm[i, j]:>6}" for j in range(num_classes)])
        logger.info(row)

    logger.info("\n[Normalized Confusion Matrix (Row-wise)]")
    cm_norm = cm.astype(float) / cm.sum(axis=1, keepdims=True)
    cm_norm = np.nan_to_num(cm_norm)

    header = "Pred→  " + "  ".join([f"{name[:4]:>6}" for name in class_names])
    logger.info(header)
    logger.info("-" * len(header))
    for i, name in enumerate(class_names):
        row = f"{name[:4]:<6} " + "  ".join([f"{cm_norm[i, j]:>6.2f}" for j in range(num_classes)])
        logger.info(row)

    logger.info("\n" + "=" * 80)


def generate_latex_table(results, num_classes=4):
    class_names = CLASS_NAMES_4 if num_classes == 4 else CLASS_NAMES_7
    overall = results["overall"]

    latex = []
    latex.append("% LaTeX table for paper")
    latex.append("\\begin{table}[h]")
    latex.append("\\centering")
    latex.append("\\caption{5-Fold Cross-Validation Results on IEMOCAP}")
    latex.append("\\begin{tabular}{lcccc}")
    latex.append("\\toprule")
    latex.append("Metric & Mean & Std \\\\")
    latex.append("\\midrule")
    latex.append(f"WA & {overall['WA']['mean']:.4f} & {overall['WA']['std']:.4f} \\\\")
    latex.append(f"UA & {overall['UA']['mean']:.4f} & {overall['UA']['std']:.4f} \\\\")
    latex.append(
        f"Macro F1 & {overall['macro_f1']['mean']:.4f} & {overall['macro_f1']['std']:.4f} \\\\"
    )
    latex.append(
        f"Weighted F1 & {overall['weighted_f1']['mean']:.4f} & {overall['weighted_f1']['std']:.4f} \\\\"
    )
    latex.append("\\bottomrule")
    latex.append("\\end{tabular}")
    latex.append("\\end{table}")

    return "\n".join(latex)


def main():
    args = get_test_args()

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    results = load_experiment_config(args.results_dir)

    test_dir = os.path.join(args.results_dir, f"test_{timestamp}")
    os.makedirs(test_dir, exist_ok=True)

    logger = setup_logging(test_dir, f"test_{timestamp}")

    logger.info(f"Loading results from: {args.results_dir}")

    config = results.get("config", {})
    num_classes = int(config.get("num_classes", 4))

    print_detailed_results(logger, results, num_classes)

    latex_table = generate_latex_table(results, num_classes)
    latex_path = os.path.join(test_dir, "latex_table.tex")
    with open(latex_path, "w") as f:
        f.write(latex_table)
    logger.info(f"\nLaTeX table saved to: {latex_path}")

    cm = np.array(results["aggregated_confusion_matrix"])
    plot_confusion_matrix(
        cm, test_dir, num_classes, fold_idx=None, timestamp=timestamp, normalize=True
    )
    plot_confusion_matrix(
        cm, test_dir, num_classes, fold_idx=None, timestamp=timestamp, normalize=False
    )

    avg_recall = np.mean([f["per_class_recall"] for f in results["fold_results"]], axis=0)
    plot_per_class_recall(avg_recall, test_dir, num_classes, fold_idx=None, timestamp=timestamp)

    logger.info(f"Figures saved to: {test_dir}")

    logger.info("\n" + "=" * 80)
    logger.info("TEST COMPLETE")
    logger.info("=" * 80)


if __name__ == "__main__":
    main()
