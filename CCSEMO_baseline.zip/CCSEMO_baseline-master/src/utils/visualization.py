"""
可视化模块
@Time: 2024-12-30
"""

import os

import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

plt.rcParams["font.family"] = "DejaVu Sans"
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["figure.dpi"] = 150
plt.rcParams["savefig.dpi"] = 300
plt.rcParams["savefig.bbox"] = "tight"
plt.rcParams["savefig.pad_inches"] = 0.1


CLASS_NAMES_4 = ["Neutral", "Happy", "Sad", "Angry"]
CLASS_NAMES_7 = ["Neutral", "Happy", "Sad", "Angry", "Disgust", "Fear", "Surprise"]


def plot_training_curves(history, save_dir, fold_idx=None, timestamp=""):
    prefix = f"fold{fold_idx}_" if fold_idx is not None else ""

    fig, axes = plt.subplots(1, 3, figsize=(15, 4))

    epochs = range(1, len(history["train_loss"]) + 1)

    axes[0].plot(epochs, history["train_loss"], "b-", label="Train", linewidth=2)
    axes[0].plot(epochs, history["val_loss"], "r-", label="Val", linewidth=2)
    axes[0].set_xlabel("Epoch", fontsize=12)
    axes[0].set_ylabel("Loss", fontsize=12)
    axes[0].set_title("Training & Validation Loss", fontsize=14)
    axes[0].legend(fontsize=10)
    axes[0].grid(True, alpha=0.3)

    axes[1].plot(epochs, history["train_uar"], "b-", label="Train", linewidth=2)
    axes[1].plot(epochs, history["val_uar"], "r-", label="Val", linewidth=2)
    axes[1].set_xlabel("Epoch", fontsize=12)
    axes[1].set_ylabel("UAR", fontsize=12)
    axes[1].set_title("Training & Validation UAR", fontsize=14)
    axes[1].legend(fontsize=10)
    axes[1].grid(True, alpha=0.3)

    axes[2].plot(epochs, history["train_acc"], "b-", label="Train", linewidth=2)
    axes[2].plot(epochs, history["val_acc"], "r-", label="Val", linewidth=2)
    axes[2].set_xlabel("Epoch", fontsize=12)
    axes[2].set_ylabel("Accuracy", fontsize=12)
    axes[2].set_title("Training & Validation Accuracy", fontsize=14)
    axes[2].legend(fontsize=10)
    axes[2].grid(True, alpha=0.3)

    plt.tight_layout()
    save_path = os.path.join(save_dir, f"{prefix}training_curves_{timestamp}.png")
    plt.savefig(save_path)
    plt.close()

    return save_path


def plot_loss_curve(history, save_dir, fold_idx=None, timestamp=""):
    prefix = f"fold{fold_idx}_" if fold_idx is not None else ""

    fig, ax = plt.subplots(figsize=(8, 6))
    epochs = range(1, len(history["train_loss"]) + 1)

    ax.plot(
        epochs,
        history["train_loss"],
        "b-",
        label="Train Loss",
        linewidth=2,
        marker="o",
        markersize=3,
    )
    ax.plot(
        epochs, history["val_loss"], "r-", label="Val Loss", linewidth=2, marker="s", markersize=3
    )

    ax.set_xlabel("Epoch", fontsize=14)
    ax.set_ylabel("Loss", fontsize=14)
    ax.set_title("Loss Curve", fontsize=16, fontweight="bold")
    ax.legend(fontsize=12)
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    save_path = os.path.join(save_dir, f"{prefix}loss_curve_{timestamp}.png")
    plt.savefig(save_path)
    plt.close()

    return save_path


def plot_accuracy_curve(history, save_dir, fold_idx=None, timestamp=""):
    prefix = f"fold{fold_idx}_" if fold_idx is not None else ""

    fig, ax = plt.subplots(figsize=(8, 6))
    epochs = range(1, len(history["train_acc"]) + 1)

    ax.plot(
        epochs, history["train_acc"], "b-", label="Train Acc", linewidth=2, marker="o", markersize=3
    )
    ax.plot(
        epochs, history["val_acc"], "r-", label="Val Acc", linewidth=2, marker="s", markersize=3
    )

    ax.set_xlabel("Epoch", fontsize=14)
    ax.set_ylabel("Accuracy", fontsize=14)
    ax.set_title("Accuracy Curve", fontsize=16, fontweight="bold")
    ax.legend(fontsize=12)
    ax.grid(True, alpha=0.3)
    ax.set_ylim([0, 1])

    plt.tight_layout()
    save_path = os.path.join(save_dir, f"{prefix}accuracy_curve_{timestamp}.png")
    plt.savefig(save_path)
    plt.close()

    return save_path


def plot_uar_curve(history, save_dir, fold_idx=None, timestamp=""):
    prefix = f"fold{fold_idx}_" if fold_idx is not None else ""

    fig, ax = plt.subplots(figsize=(8, 6))
    epochs = range(1, len(history["train_uar"]) + 1)

    ax.plot(
        epochs, history["train_uar"], "b-", label="Train UAR", linewidth=2, marker="o", markersize=3
    )
    ax.plot(
        epochs, history["val_uar"], "r-", label="Val UAR", linewidth=2, marker="s", markersize=3
    )

    ax.set_xlabel("Epoch", fontsize=14)
    ax.set_ylabel("UAR (Unweighted Average Recall)", fontsize=14)
    ax.set_title("UAR Curve", fontsize=16, fontweight="bold")
    ax.legend(fontsize=12)
    ax.grid(True, alpha=0.3)
    ax.set_ylim([0, 1])

    plt.tight_layout()
    save_path = os.path.join(save_dir, f"{prefix}uar_curve_{timestamp}.png")
    plt.savefig(save_path)
    plt.close()

    return save_path


def plot_confusion_matrix(cm, save_dir, num_classes=4, fold_idx=None, timestamp="", normalize=True):
    prefix = f"fold{fold_idx}_" if fold_idx is not None else ""

    actual_num_classes = cm.shape[0]
    if actual_num_classes == 4:
        class_names = CLASS_NAMES_4
    elif actual_num_classes == 7:
        class_names = CLASS_NAMES_7
    else:
        class_names = [f"Class {i}" for i in range(actual_num_classes)]

    if normalize:
        cm_normalized = cm.astype("float") / cm.sum(axis=1, keepdims=True)
        cm_normalized = np.nan_to_num(cm_normalized)
    else:
        cm_normalized = cm

    fig, ax = plt.subplots(figsize=(8, 6))

    sns.heatmap(
        cm_normalized,
        annot=True,
        fmt=".2f" if normalize else "d",
        cmap="Blues",
        xticklabels=class_names,
        yticklabels=class_names,
        ax=ax,
        vmin=0,
        vmax=1 if normalize else None,
        annot_kws={"size": 12},
    )

    ax.set_xlabel("Predicted Label", fontsize=14)
    ax.set_ylabel("True Label", fontsize=14)
    title = "Normalized Confusion Matrix" if normalize else "Confusion Matrix"
    ax.set_title(title, fontsize=16, fontweight="bold")

    plt.tight_layout()
    suffix = "normalized" if normalize else "raw"
    save_path = os.path.join(save_dir, f"{prefix}confusion_matrix_{suffix}_{timestamp}.png")
    plt.savefig(save_path)
    plt.close()

    return save_path


def plot_per_class_recall(per_class_recall, save_dir, num_classes=4, fold_idx=None, timestamp=""):
    prefix = f"fold{fold_idx}_" if fold_idx is not None else ""
    actual_num_classes = len(per_class_recall)
    if actual_num_classes == 4:
        class_names = CLASS_NAMES_4
    elif actual_num_classes == 7:
        class_names = CLASS_NAMES_7
    else:
        class_names = [f"Class {i}" for i in range(actual_num_classes)]

    fig, ax = plt.subplots(figsize=(8, 6))

    colors = plt.cm.Set2(np.linspace(0, 1, actual_num_classes))
    bars = ax.bar(class_names, per_class_recall, color=colors, edgecolor="black", linewidth=1.2)

    for bar, recall in zip(bars, per_class_recall):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 0.02,
            f"{recall:.2f}",
            ha="center",
            va="bottom",
            fontsize=12,
            fontweight="bold",
        )

    ax.set_xlabel("Emotion Class", fontsize=14)
    ax.set_ylabel("Recall", fontsize=14)
    ax.set_title("Per-Class Recall", fontsize=16, fontweight="bold")
    ax.set_ylim([0, 1.1])
    ax.grid(True, alpha=0.3, axis="y")

    plt.tight_layout()
    save_path = os.path.join(save_dir, f"{prefix}per_class_recall_{timestamp}.png")
    plt.savefig(save_path)
    plt.close()

    return save_path


def plot_5fold_summary(fold_results, save_dir, timestamp=""):
    num_folds = len(fold_results)
    folds = [f"Fold {i + 1}" for i in range(num_folds)]

    uars = [r["uar"] for r in fold_results]
    accs = [r["accuracy"] for r in fold_results]
    wf1s = [r["weighted_f1"] for r in fold_results]

    fig, axes = plt.subplots(1, 3, figsize=(15, 5))

    x = np.arange(num_folds)
    width = 0.6

    bars1 = axes[0].bar(x, uars, width, color="steelblue", edgecolor="black")
    axes[0].axhline(
        y=np.mean(uars),
        color="red",
        linestyle="--",
        linewidth=2,
        label=f"Mean: {np.mean(uars):.4f}",
    )
    axes[0].set_xlabel("Fold", fontsize=12)
    axes[0].set_ylabel("UAR", fontsize=12)
    axes[0].set_title("UAR per Fold", fontsize=14, fontweight="bold")
    axes[0].set_xticks(x)
    axes[0].set_xticklabels(folds)
    axes[0].legend(fontsize=10)
    axes[0].set_ylim([0, 1])
    for bar, val in zip(bars1, uars):
        axes[0].text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 0.02,
            f"{val:.3f}",
            ha="center",
            fontsize=10,
        )

    bars2 = axes[1].bar(x, accs, width, color="seagreen", edgecolor="black")
    axes[1].axhline(
        y=np.mean(accs),
        color="red",
        linestyle="--",
        linewidth=2,
        label=f"Mean: {np.mean(accs):.4f}",
    )
    axes[1].set_xlabel("Fold", fontsize=12)
    axes[1].set_ylabel("Accuracy", fontsize=12)
    axes[1].set_title("Accuracy per Fold", fontsize=14, fontweight="bold")
    axes[1].set_xticks(x)
    axes[1].set_xticklabels(folds)
    axes[1].legend(fontsize=10)
    axes[1].set_ylim([0, 1])
    for bar, val in zip(bars2, accs):
        axes[1].text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 0.02,
            f"{val:.3f}",
            ha="center",
            fontsize=10,
        )

    bars3 = axes[2].bar(x, wf1s, width, color="coral", edgecolor="black")
    axes[2].axhline(
        y=np.mean(wf1s),
        color="red",
        linestyle="--",
        linewidth=2,
        label=f"Mean: {np.mean(wf1s):.4f}",
    )
    axes[2].set_xlabel("Fold", fontsize=12)
    axes[2].set_ylabel("Weighted F1", fontsize=12)
    axes[2].set_title("Weighted F1 per Fold", fontsize=14, fontweight="bold")
    axes[2].set_xticks(x)
    axes[2].set_xticklabels(folds)
    axes[2].legend(fontsize=10)
    axes[2].set_ylim([0, 1])
    for bar, val in zip(bars3, wf1s):
        axes[2].text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 0.02,
            f"{val:.3f}",
            ha="center",
            fontsize=10,
        )

    plt.tight_layout()
    save_path = os.path.join(save_dir, f"5fold_summary_{timestamp}.png")
    plt.savefig(save_path)
    plt.close()

    return save_path


def save_all_figures(history, test_metrics, save_dir, num_classes=4, fold_idx=None, timestamp=""):
    os.makedirs(save_dir, exist_ok=True)

    saved_paths = []

    saved_paths.append(plot_training_curves(history, save_dir, fold_idx, timestamp))
    saved_paths.append(plot_loss_curve(history, save_dir, fold_idx, timestamp))
    saved_paths.append(plot_accuracy_curve(history, save_dir, fold_idx, timestamp))
    saved_paths.append(plot_uar_curve(history, save_dir, fold_idx, timestamp))

    if "confusion_matrix" in test_metrics:
        saved_paths.append(
            plot_confusion_matrix(
                test_metrics["confusion_matrix"],
                save_dir,
                num_classes,
                fold_idx,
                timestamp,
                normalize=True,
            )
        )
        saved_paths.append(
            plot_confusion_matrix(
                test_metrics["confusion_matrix"],
                save_dir,
                num_classes,
                fold_idx,
                timestamp,
                normalize=False,
            )
        )

    if "per_class_recall" in test_metrics:
        saved_paths.append(
            plot_per_class_recall(
                test_metrics["per_class_recall"], save_dir, num_classes, fold_idx, timestamp
            )
        )

    return saved_paths
