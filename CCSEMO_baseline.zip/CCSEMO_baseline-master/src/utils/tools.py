"""
工具函数模块
@Time: 2024-12-30
"""

import os
import random

import numpy as np
import torch
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
)


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def get_device(gpu_id):
    if torch.cuda.is_available() and gpu_id >= 0:
        return torch.device(f"cuda:{gpu_id}")
    return torch.device("cpu")


class AverageMeter:
    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count


class EarlyStopping:
    def __init__(self, patience=10, mode="max", delta=0.0):
        self.patience = patience
        self.mode = mode
        self.delta = delta
        self.counter = 0
        self.best_score = None
        self.early_stop = False
        self.best_model_state = None

    def __call__(self, score, model):
        if self.mode == "max":
            is_better = self.best_score is None or score > self.best_score + self.delta
        else:
            is_better = self.best_score is None or score < self.best_score - self.delta

        if is_better:
            self.best_score = score
            self.counter = 0
            self.best_model_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}
        else:
            self.counter += 1
            if self.counter >= self.patience:
                self.early_stop = True

        return is_better

    def load_best_model(self, model):
        if self.best_model_state is not None:
            model.load_state_dict(self.best_model_state)


def compute_metrics(preds, labels, num_classes=4):
    preds = np.array(preds)
    labels = np.array(labels)

    wa = accuracy_score(labels, preds)
    ua = recall_score(labels, preds, average="macro", zero_division=0)

    macro_f1 = f1_score(labels, preds, average="macro", zero_division=0)
    weighted_f1 = f1_score(labels, preds, average="weighted", zero_division=0)

    macro_precision = precision_score(labels, preds, average="macro", zero_division=0)
    weighted_precision = precision_score(labels, preds, average="weighted", zero_division=0)
    macro_recall = recall_score(labels, preds, average="macro", zero_division=0)
    weighted_recall = recall_score(labels, preds, average="weighted", zero_division=0)

    cm = confusion_matrix(labels, preds, labels=list(range(num_classes)))

    per_class_recall = []
    per_class_precision = []
    per_class_f1 = []
    for i in range(num_classes):
        tp = cm[i, i]
        fn = cm[i].sum() - tp
        fp = cm[:, i].sum() - tp

        recall_i = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        precision_i = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        f1_i = (
            2 * precision_i * recall_i / (precision_i + recall_i)
            if (precision_i + recall_i) > 0
            else 0.0
        )

        per_class_recall.append(recall_i)
        per_class_precision.append(precision_i)
        per_class_f1.append(f1_i)

    return {
        "WA": wa,
        "UA": ua,
        "accuracy": wa,
        "uar": ua,
        "macro_f1": macro_f1,
        "weighted_f1": weighted_f1,
        "macro_precision": macro_precision,
        "weighted_precision": weighted_precision,
        "macro_recall": macro_recall,
        "weighted_recall": weighted_recall,
        "per_class_recall": per_class_recall,
        "per_class_precision": per_class_precision,
        "per_class_f1": per_class_f1,
        "confusion_matrix": cm,
    }


def save_checkpoint(model, optimizer, epoch, metrics, save_path):
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    torch.save(
        {
            "epoch": epoch,
            "model_state_dict": model.state_dict(),
            "optimizer_state_dict": optimizer.state_dict(),
            "metrics": metrics,
        },
        save_path,
    )


def load_checkpoint(model, optimizer, load_path):
    checkpoint = torch.load(load_path, map_location="cpu")
    model.load_state_dict(checkpoint["model_state_dict"])
    if optimizer is not None:
        optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
    return checkpoint["epoch"], checkpoint["metrics"]
