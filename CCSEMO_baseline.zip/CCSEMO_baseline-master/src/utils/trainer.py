"""
训练器模块
@Time: 2024-12-30
"""

import torch
from tqdm import tqdm

from src.utils.tools import AverageMeter, compute_metrics


def train_epoch(model, dataloader, optimizer, criterion, device, scheduler=None, num_classes=4):
    model.train()
    loss_meter = AverageMeter()
    all_preds = []
    all_labels = []

    pbar = tqdm(dataloader, desc="Training", leave=False)
    for features, labels, mask, _ in pbar:
        if features is None:
            continue
        features = features.to(device)
        labels = labels.to(device)
        mask = mask.to(device)

        optimizer.zero_grad()
        logits = model(features, mask)
        loss = criterion(logits, labels)

        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()

        if scheduler is not None:
            scheduler.step()

        loss_meter.update(loss.item(), labels.size(0))
        preds = logits.argmax(dim=1).cpu().numpy()
        all_preds.extend(preds)
        all_labels.extend(labels.cpu().numpy())

        pbar.set_postfix({"loss": f"{loss_meter.avg:.4f}"})

    metrics = compute_metrics(all_preds, all_labels, num_classes=num_classes)
    metrics["loss"] = loss_meter.avg

    return metrics


@torch.no_grad()
def evaluate(model, dataloader, criterion, device, num_classes=4):
    model.eval()
    loss_meter = AverageMeter()
    all_preds = []
    all_labels = []

    for features, labels, mask, _ in dataloader:
        if features is None:
            continue
        features = features.to(device)
        labels = labels.to(device)
        mask = mask.to(device)

        logits = model(features, mask)
        loss = criterion(logits, labels)

        loss_meter.update(loss.item(), labels.size(0))
        preds = logits.argmax(dim=1).cpu().numpy()
        all_preds.extend(preds)
        all_labels.extend(labels.cpu().numpy())

    metrics = compute_metrics(all_preds, all_labels, num_classes=num_classes)
    metrics["loss"] = loss_meter.avg

    return metrics
