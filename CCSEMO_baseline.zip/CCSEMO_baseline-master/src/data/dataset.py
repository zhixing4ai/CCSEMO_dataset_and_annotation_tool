"""
数据集模块
可解耦一下，方便替换数据集
@Time: 2024-12-30
"""

import os
import pickle

import pandas as pd
import torch
from torch.nn.utils.rnn import pad_sequence
from torch.utils.data import DataLoader, Dataset

from src.config.config import DATASET_CONFIG, EMOTION_LABELS


class EmotionDataset(Dataset):
    def __init__(
        self,
        df,
        feature_path,
        label_map,
        max_len=None,
        use_all_layers=False,
        use_fusion_layers=False,
        feature_path_12=None,
        feature_path_last=None,
        preload=False,
    ):
        self.feature_path = feature_path
        self.label_map = label_map
        self.max_len = max_len
        self.use_all_layers = use_all_layers
        self.use_fusion_layers = use_fusion_layers
        self.feature_path_12 = feature_path_12
        self.feature_path_last = feature_path_last
        self.preload = preload
        self.cache = {}

        self.samples = []
        missing_count = 0

        for _, row in df.iterrows():
            emotion = row["discrete_emotion"]
            if emotion not in label_map:
                continue

            audio_name = row["name"]
            if audio_name.endswith(".wav"):
                audio_name = audio_name[:-4]

            feature_filename = f"{audio_name}.p"

            if use_fusion_layers:
                path_12 = os.path.join(feature_path_12, feature_filename)
                path_last = os.path.join(feature_path_last, feature_filename)
                if os.path.exists(path_12) and os.path.exists(path_last):
                    self.samples.append(
                        {
                            "feature_file_12": path_12,
                            "feature_file_last": path_last,
                            "label": label_map[emotion],
                            "name": audio_name,
                        }
                    )
                else:
                    missing_count += 1
            else:
                path_single = os.path.join(feature_path, feature_filename)
                if os.path.exists(path_single):
                    self.samples.append(
                        {
                            "feature_file": path_single,
                            "label": label_map[emotion],
                            "name": audio_name,
                        }
                    )
                else:
                    missing_count += 1

        if len(self.samples) == 0:
            raise FileNotFoundError(
                f"No feature files found. Checked feature_path={feature_path}, "
                f"feature_path_12={feature_path_12}, feature_path_last={feature_path_last}. "
                "Ensure FEATURE_ROOT points to the directory that contains the extracted features."
            )

        if missing_count > 0:
            print(f"[Warning] Skipped {missing_count} samples due to missing feature files.")

        if preload:
            for sample in self.samples:
                if use_fusion_layers:
                    with open(sample["feature_file_12"], "rb") as f:
                        self.cache[sample["feature_file_12"]] = pickle.load(f)
                    with open(sample["feature_file_last"], "rb") as f:
                        self.cache[sample["feature_file_last"]] = pickle.load(f)
                else:
                    with open(sample["feature_file"], "rb") as f:
                        self.cache[sample["feature_file"]] = pickle.load(f)

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        sample = self.samples[idx]

        try:
            if self.use_fusion_layers:
                if self.preload:
                    feat_12 = self.cache[sample["feature_file_12"]]
                    feat_last = self.cache[sample["feature_file_last"]]
                else:
                    with open(sample["feature_file_12"], "rb") as f:
                        feat_12 = pickle.load(f)
                    with open(sample["feature_file_last"], "rb") as f:
                        feat_last = pickle.load(f)

                feat_12 = torch.tensor(feat_12, dtype=torch.float32)
                feat_last = torch.tensor(feat_last, dtype=torch.float32)

                min_len = min(feat_12.shape[0], feat_last.shape[0])
                feat_12 = feat_12[:min_len]
                feat_last = feat_last[:min_len]

                if self.max_len is not None and min_len > self.max_len:
                    feat_12 = feat_12[: self.max_len]
                    feat_last = feat_last[: self.max_len]

                feature = torch.stack([feat_12, feat_last], dim=0)
            else:
                if self.preload:
                    feature = self.cache[sample["feature_file"]]
                else:
                    with open(sample["feature_file"], "rb") as f:
                        feature = pickle.load(f)

                feature = torch.tensor(feature, dtype=torch.float32)

                if self.use_all_layers:
                    if self.max_len is not None and feature.shape[1] > self.max_len:
                        feature = feature[:, : self.max_len, :]
                else:
                    if self.max_len is not None and feature.shape[0] > self.max_len:
                        feature = feature[: self.max_len]

            label = torch.tensor(sample["label"], dtype=torch.long)

            return feature, label, sample["name"]
        except FileNotFoundError:
            return None


def collate_fn(batch):
    # 过滤掉None
    batch = [b for b in batch if b is not None]
    if len(batch) == 0:
        return None, None, None, None

    features, labels, names = zip(*batch)

    if features[0].dim() == 3:
        num_layers = features[0].shape[0]
        lengths = torch.tensor([f.shape[1] for f in features], dtype=torch.long)
        max_len = max(lengths)

        batch_size = len(features)
        hidden_dim = features[0].shape[2]
        features_padded = torch.zeros(batch_size, num_layers, max_len, hidden_dim)
        for i, f in enumerate(features):
            features_padded[i, :, : f.shape[1], :] = f

        mask = torch.arange(max_len).unsqueeze(0) < lengths.unsqueeze(1)
    else:
        lengths = torch.tensor([f.shape[0] for f in features], dtype=torch.long)
        features_padded = pad_sequence(features, batch_first=True, padding_value=0.0)
        max_len = features_padded.shape[1]
        mask = torch.arange(max_len).unsqueeze(0) < lengths.unsqueeze(1)

    labels = torch.stack(labels)

    return features_padded, labels, mask, names


def _create_dataloaders(train_df, val_df, test_df, args, label_map):
    use_all_layers = getattr(args, "use_all_layers", False)
    use_fusion_layers = getattr(args, "use_fusion_layers", False)
    feature_path_12 = getattr(args, "feature_path_12", None)
    feature_path_last = getattr(args, "feature_path_last", None)
    preload = getattr(args, "preload", False)

    train_dataset = EmotionDataset(
        train_df,
        args.feature_path,
        label_map,
        use_all_layers=use_all_layers,
        use_fusion_layers=use_fusion_layers,
        feature_path_12=feature_path_12,
        feature_path_last=feature_path_last,
        preload=preload,
    )
    val_dataset = EmotionDataset(
        val_df,
        args.feature_path,
        label_map,
        use_all_layers=use_all_layers,
        use_fusion_layers=use_fusion_layers,
        feature_path_12=feature_path_12,
        feature_path_last=feature_path_last,
        preload=preload,
    )
    test_dataset = EmotionDataset(
        test_df,
        args.feature_path,
        label_map,
        use_all_layers=use_all_layers,
        use_fusion_layers=use_fusion_layers,
        feature_path_12=feature_path_12,
        feature_path_last=feature_path_last,
        preload=preload,
    )

    pin_mem = not (use_all_layers or use_fusion_layers)
    num_workers = 0 if preload else args.num_workers

    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=num_workers,
        collate_fn=collate_fn,
        pin_memory=True,
        drop_last=True if len(train_dataset) > args.batch_size else False,
    )

    val_loader = DataLoader(
        val_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=num_workers,
        collate_fn=collate_fn,
        pin_memory=True,
    )

    test_loader = DataLoader(
        test_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=num_workers,
        collate_fn=collate_fn,
        pin_memory=True,
    )

    return train_loader, val_loader, test_loader


def get_dataloaders_iemocap(args, test_session_idx, val_session_idx):
    """IEMOCAP数据集：按session划分5折"""
    dataset_cfg = DATASET_CONFIG["iemocap"]
    csv_path = dataset_cfg["csv_path"]
    sessions = dataset_cfg["sessions"]

    label_map = EMOTION_LABELS[f"iemocap_{args.num_classes}class"]

    df = pd.read_csv(csv_path)

    test_sessions = [sessions[test_session_idx - 1]]
    val_sessions = [sessions[val_session_idx - 1]]
    train_sessions = [s for s in sessions if s not in test_sessions and s not in val_sessions]

    train_df = df[df["session"].isin(train_sessions)]
    val_df = df[df["session"].isin(val_sessions)]
    test_df = df[df["session"].isin(test_sessions)]

    return _create_dataloaders(train_df, val_df, test_df, args, label_map)


def get_dataloaders_ccsemo(args, fold_idx):
    """CCSEMO数据集：使用预定义的5折划分"""
    dataset_cfg = DATASET_CONFIG["ccsemo"]
    fold_dir = dataset_cfg["fold_dir"]

    label_map = EMOTION_LABELS[f"ccsemo_{args.num_classes}class"]

    fold_csv = os.path.join(fold_dir, f"fold{fold_idx}.csv")
    df = pd.read_csv(fold_csv)

    train_df = df[df["split_set"] == "train"]
    val_df = df[df["split_set"] == "val"]
    test_df = df[df["split_set"] == "test"]

    return _create_dataloaders(train_df, val_df, test_df, args, label_map)


def get_dataloaders_msp(args):
    """MSP数据集：使用split_set列划分（Train/Validation/Test）"""
    dataset_cfg = DATASET_CONFIG["msp"]
    csv_path = dataset_cfg["csv_path"]

    label_map = EMOTION_LABELS[f"msp_{args.num_classes}class"]

    df = pd.read_csv(csv_path)

    train_df = df[df["split_set"] == "Train"]
    val_df = df[df["split_set"] == "Validation"]
    test_df = df[df["split_set"] == "Test"]

    return _create_dataloaders(train_df, val_df, test_df, args, label_map)


def get_dataloaders(args, test_session_idx=None, val_session_idx=None, fold_idx=None):
    if args.dataset == "iemocap":
        return get_dataloaders_iemocap(args, test_session_idx, val_session_idx)
    elif args.dataset == "ccsemo":
        return get_dataloaders_ccsemo(args, fold_idx)
    elif args.dataset == "msp":
        return get_dataloaders_msp(args)
    else:
        raise ValueError(f"Unknown dataset: {args.dataset}")
