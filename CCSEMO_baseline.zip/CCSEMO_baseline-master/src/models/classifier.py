"""
Transformer
@Time: 2024-12-30
"""

import math

import torch
import torch.nn as nn
import torch.nn.functional as F


class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=5000, dropout=0.1):
        super().__init__()
        self.dropout = nn.Dropout(p=dropout)

        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)
        self.register_buffer("pe", pe)

    def forward(self, x):
        x = x + self.pe[:, : x.size(1), :]
        return self.dropout(x)


class LayerWeightedSum(nn.Module):
    def __init__(self, num_layers, normalize=False):
        super().__init__()
        self.num_layers = num_layers
        self.normalize = normalize
        self.weights = nn.Parameter(torch.zeros(num_layers))

    def forward(self, x):
        # print(f"LayerWeightedSum input: {x.shape}")
        if self.normalize:
            x = F.layer_norm(x, (x.shape[-1],))
        norm_weights = F.softmax(self.weights, dim=-1)
        batch_size, num_layers, seq_len, hidden_dim = x.shape
        x_flat = x.permute(1, 0, 2, 3).reshape(num_layers, -1)
        weighted_x = (norm_weights.unsqueeze(-1) * x_flat).sum(dim=0)
        weighted_x = weighted_x.view(batch_size, seq_len, hidden_dim)
        # print(f"LayerWeightedSum output: {weighted_x.shape}")
        return weighted_x


class EmotionClassifier(nn.Module):
    def __init__(
        self,
        input_dim,
        hidden_dim,
        num_classes,
        num_heads=4,
        num_layers=2,
        dropout=0.3,
        use_all_layers=False,
        use_fusion_layers=False,
        ssl_num_layers=25,
    ):
        super().__init__()
        self.use_all_layers = use_all_layers
        self.use_fusion_layers = use_fusion_layers

        if use_all_layers or use_fusion_layers:
            self.layer_weighted_sum = LayerWeightedSum(ssl_num_layers, normalize=True)

        self.input_proj = nn.Linear(input_dim, hidden_dim)
        self.pos_encoder = PositionalEncoding(hidden_dim, dropout=dropout)

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=hidden_dim,
            nhead=num_heads,
            dim_feedforward=hidden_dim * 4,
            dropout=dropout,
            activation="gelu",
            batch_first=True,
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)

        self.pool = nn.AdaptiveAvgPool1d(1)

        self.classifier = nn.Sequential(
            nn.LayerNorm(hidden_dim),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim // 2, num_classes),
        )

        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def forward(self, x, mask=None):
        if self.use_all_layers or self.use_fusion_layers:
            x = self.layer_weighted_sum(x)

        x = self.input_proj(x)
        # print(f"Input shape: {x.shape}")
        x = self.pos_encoder(x)
        # print(f"After pos encoding: {x.shape}")

        if mask is not None:
            src_key_padding_mask = ~mask
        else:
            src_key_padding_mask = None
        # print(f"After transformer: {x.shape}")
        x = self.transformer(x, src_key_padding_mask=src_key_padding_mask)
        # print(f"After transformer: {x.shape}")

        x = x.transpose(1, 2)
        x = self.pool(x).squeeze(-1)
        # print(f"After pooling: {x.shape}")

        logits = self.classifier(x)

        # print(f"Final logits shape: {logits.shape}")
        return logits


def build_model(args):
    use_all_layers = getattr(args, "use_all_layers", False)
    use_fusion_layers = getattr(args, "use_fusion_layers", False)
    ssl_num_layers = getattr(args, "ssl_num_layers", 25)

    model = EmotionClassifier(
        input_dim=args.feature_dim,
        hidden_dim=args.hidden_dim,
        num_classes=args.num_classes,
        num_heads=args.num_heads,
        num_layers=args.num_layers,
        dropout=args.dropout,
        use_all_layers=use_all_layers,
        use_fusion_layers=use_fusion_layers,
        ssl_num_layers=ssl_num_layers,
    )
    return model


if __name__ == "__main__":
    import argparse

    import torch

    batch_size, seq_len, feat_dim = 2, 100, 1024

    print("=== Test all_layers mode ===")
    x = torch.randn(batch_size, 25, seq_len, feat_dim)
    mask = torch.ones(batch_size, seq_len, dtype=torch.bool)
    args = argparse.Namespace(
        feature_dim=1024,
        hidden_dim=512,
        num_classes=4,
        num_heads=4,
        num_layers=2,
        dropout=0.3,
        use_all_layers=True,
        ssl_num_layers=25,
    )
    model = build_model(args)
    with torch.no_grad():
        output = model(x, mask)
        # print(f"Input shape: {x.shape}")
        # print(f"Mask shape: {mask.shape}")
        # print(f"Output shape: {output.shape}")
        print(f"Model parameters: {sum(p.numel() for p in model.parameters())}")
