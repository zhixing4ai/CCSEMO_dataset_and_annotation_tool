"""
配置文件模块
@Time: 2024-12-30
"""

import argparse
import os
from pathlib import Path

EMOTION_LABELS = {
    # 4-class: neutral, happy, sad, angry
    "iemocap_4class": {
        "neutral": 0,
        "happiness": 1,
        "excitement": 1,  # exc -> happy
        "sadness": 2,
        "anger": 3,
    },
    # 7-class: neutral, happy, sad, angry, disgust, fear, surprise
    "iemocap_7class": {
        "neutral": 0,
        "happiness": 1,
        "excitement": 1,  # exc -> happy
        "sadness": 2,
        "anger": 3,
        "disgust": 4,
        "fear": 5,
        "surprise": 6,
    },
    # Ignored IEMOCAP labels: fru, oth, xxx
    "msp_4class": {
        "neutral": 0,
        "happiness": 1,
        "sadness": 2,
        "anger": 3,
    },
    "msp_7class": {
        "neutral": 0,
        "happiness": 1,
        "sadness": 2,
        "anger": 3,
        "disgust": 4,
        "fear": 5,
        "surprise": 6,
    },
    # Ignored MSP labels: C, O, X
    "ccsemo_4class": {
        "neutral": 0,
        "happiness": 1,
        "sadness": 2,
        "anger": 3,
    },
    "ccsemo_7class": {
        "neutral": 0,
        "happiness": 1,
        "sadness": 2,
        "anger": 3,
        "disgust": 4,
        "fear": 5,
        "surprise": 6,
    },
}

FEATURE_DIM = {
    "hubert_large": 1024,
    "wav2vec_large": 1024,
    "wavlm_large": 1024,
}

DATASET_CONFIG = {
    "iemocap": {
        "csv_path": "/mnt/shareEEx/liuyang/code/CCSEMO_baseline/prepared/files/iemocap_label.csv",
        "sessions": ["Session1", "Session2", "Session3", "Session4", "Session5"],
        "num_classes": 4,
        "cv_type": "session",  # 5-fold
    },
    "ccsemo": {
        "fold_dir": "/mnt/shareEEx/liuyang/resources/datasets/SER/CCSEMO/5fold",
        "num_classes": 7,
        "cv_type": "fold",  # 5-fold
    },
    "msp": {
        "csv_path": "/mnt/shareEEx/liuyang/code/CCSEMO_baseline/prepared/files/msp-1.0_label.csv",
        "num_classes": 4,
        "cv_type": "split_set",  # Train/Validation/Test
    },
}


def _default_feature_root():
    env_root = os.environ.get("FEATURE_ROOT")
    if env_root:
        return env_root

    project_root = Path(__file__).resolve().parents[2]
    local_data = project_root / "data"
    if local_data.exists():
        return str(local_data)

    return "/tmp/data"


FEATURE_ROOT = _default_feature_root()


def get_args():  # noqa: ANN201
    parser = argparse.ArgumentParser(description="Emotion Classification")

    parser.add_argument(
        "--dataset", type=str, default="iemocap", choices=["iemocap", "ccsemo", "msp"]
    )
    parser.add_argument(
        "--feature_type",
        type=str,
        default="hubert_large",
        choices=["hubert_large", "wav2vec_large", "wavlm_large"],
    )
    parser.add_argument(
        "--layer",
        type=str,
        default="last_layer",
        choices=["last_layer", "12_layer", "all_layer", "fusion_layer"],
    )

    parser.add_argument("--num_classes", type=int, default=4)
    parser.add_argument("--hidden_dim", type=int, default=256)
    parser.add_argument("--num_heads", type=int, default=4)
    parser.add_argument("--num_layers", type=int, default=2)
    parser.add_argument("--dropout", type=float, default=0.3)

    parser.add_argument("--batch_size", type=int, default=32)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--patience", type=int, default=10)

    parser.add_argument("--gpu", type=int, default=0)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--num_workers", type=int, default=4)

    parser.add_argument("--save_dir", type=str, default="checkpoints")
    parser.add_argument("--log_dir", type=str, default="logs")

    parser.add_argument(
        "--test_session", type=int, default=1, help="1-5, session index for testing"
    )
    parser.add_argument(
        "--val_session", type=int, default=None, help="1-5, session index for validation"
    )

    parser.add_argument(
        "--note", type=str, default="", help="Custom note to append to experiment folder name"
    )
    parser.add_argument(
        "--use_class_weight",
        action="store_true",
        help="Use class-weighted loss for imbalanced data",
    )
    parser.add_argument(
        "--preload",
        action="store_true",
        help="Preload all features into memory for faster training",
    )

    args = parser.parse_args()

    args.feature_dim = FEATURE_DIM[args.feature_type]
    args.use_all_layers = args.layer == "all_layer"
    args.use_fusion_layers = args.layer == "fusion_layer"
    if args.use_all_layers:
        args.ssl_num_layers = 25
    elif args.use_fusion_layers:
        args.ssl_num_layers = 2
    else:
        args.ssl_num_layers = 1  # 单层不需要加权

    if args.use_fusion_layers:
        # fusion_layer: 需要同时读取12_layer和last_layer
        args.feature_path_12 = f"{FEATURE_ROOT}/{args.feature_type}/{args.dataset}/12_layer"
        args.feature_path_last = f"{FEATURE_ROOT}/{args.feature_type}/{args.dataset}/last_layer"
        args.feature_path = args.feature_path_12
    else:
        args.feature_path = f"{FEATURE_ROOT}/{args.feature_type}/{args.dataset}/{args.layer}"

    return args
