#!/bin/bash
# IEMOCAP情感分类测试脚本
# @Time: 2024-12-30

cd /mnt/shareEEEx/yangyudong/workspace/emotion_classification

RESULTS_DIR=$1

if [ -z "$RESULTS_DIR" ]; then
    echo "Usage: bash scripts/run_test.sh <results_dir>"
    echo "Example: bash scripts/run_test.sh logs/iemocap_hubert_large_last_layer_20241230_120000"
    exit 1
fi

python test.py \
    --results_dir ${RESULTS_DIR} \
    --gpu 0 \
    --seed 42
