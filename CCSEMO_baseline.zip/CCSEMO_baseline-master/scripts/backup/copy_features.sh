#!/bin/bash
# 多线程复制特征文件到本地临时目录
# Usage: ./scripts/copy_features.sh

SRC_BASE="/mnt/shareEEEx/yangyudong/workspace/emotion_classification/data/wav2vec_large/msp"
DST_BASE="/tmp/datasets_emotion/wav2vec_large/msp"

mkdir -p "${DST_BASE}/12_layer"
mkdir -p "${DST_BASE}/last_layer"

NUM_THREADS=8


echo ""
echo "## 复制 12_layer ##"
find "${SRC_BASE}/12_layer" -type f -name "*.p" | xargs -P ${NUM_THREADS} -I {} cp -a {} "${DST_BASE}/12_layer/"
echo "12_layer 复制完成"


echo ""
echo "## 复制 last_layer ##"
find "${SRC_BASE}/last_layer" -type f -name "*.p" | xargs -P ${NUM_THREADS} -I {} cp -a {} "${DST_BASE}/last_layer/"
echo "last_layer 复制完成"

echo "#########################"
SRC_12=$(find "${SRC_BASE}/12_layer" -type f -name "*.p" | wc -l)
DST_12=$(find "${DST_BASE}/12_layer" -type f -name "*.p" | wc -l)
SRC_LAST=$(find "${SRC_BASE}/last_layer" -type f -name "*.p" | wc -l)
DST_LAST=$(find "${DST_BASE}/last_layer" -type f -name "*.p" | wc -l)

echo "### 源 12_layer 文件数: ${SRC_12}"
echo "### 目标 12_layer 文件数: ${DST_12}"
echo "### 源 last_layer 文件数: ${SRC_LAST}"
echo "### 目标 last_layer 文件数: ${DST_LAST}"

echo ""
echo "复制完成!"
