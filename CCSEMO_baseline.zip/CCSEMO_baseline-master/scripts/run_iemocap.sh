#!/bin/bash
# IEMOCAP情感分类训练脚本
# @Time: 2024-12-30


DATASET="iemocap"
FEATURE_TYPE="wav2vec_large"
LAYER="fusion_layer"

GPU=0
SEED=42

BATCH_SIZE=32
LR=1e-4
WEIGHT_DECAY=1e-4
EPOCHS=100
PATIENCE=10

HIDDEN_DIM=256
NUM_HEADS=4
NUM_LAYERS=2
DROPOUT=0.3

NUM_CLASSES=4

USE_CLASS_WEIGHT=true  

LOG_DIR="logs/FINAL"

if [ "$USE_CLASS_WEIGHT" = true ]; then
    NOTE="${NUM_CLASSES}_class_weighted"
    CLASS_WEIGHT_FLAG="--use_class_weight"
else
    NOTE="${NUM_CLASSES}_class"
    CLASS_WEIGHT_FLAG=""
fi

python train.py \
    --dataset ${DATASET} \
    --feature_type ${FEATURE_TYPE} \
    --layer ${LAYER} \
    --gpu ${GPU} \
    --seed ${SEED} \
    --batch_size ${BATCH_SIZE} \
    --lr ${LR} \
    --weight_decay ${WEIGHT_DECAY} \
    --epochs ${EPOCHS} \
    --patience ${PATIENCE} \
    --hidden_dim ${HIDDEN_DIM} \
    --num_heads ${NUM_HEADS} \
    --num_layers ${NUM_LAYERS} \
    --dropout ${DROPOUT} \
    --num_classes ${NUM_CLASSES} \
    --save_dir checkpoints \
    --log_dir ${LOG_DIR} \
    --note ${NOTE} \
    ${CLASS_WEIGHT_FLAG} \
