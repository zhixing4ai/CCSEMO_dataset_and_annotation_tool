"""
情感分类训练脚本（支持IEMOCAP/CCSEMO/MSP）
@Time: 2024-12-30
"""

import json
import logging
import os
import sys
from datetime import datetime

import numpy as np
import torch
import torch.nn as nn

from src.config.config import get_args
from src.data.dataset import get_dataloaders
from src.models.classifier import build_model
from src.utils.tools import EarlyStopping, get_device, save_checkpoint, set_seed
from src.utils.trainer import evaluate, train_epoch
from src.utils.visualization import plot_5fold_summary, save_all_figures


def setup_logging(log_dir, exp_name):
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, f"{exp_name}.log")

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler(sys.stdout),
        ],
    )
    return logging.getLogger(__name__)


def train_single_fold(
    args, logger, fig_dir, ckpt_dir, timestamp, fold_idx=None, test_session=None, val_session=None
):
    if args.dataset == "iemocap":
        logger.info(f"Test Session: {test_session}, Val Session: {val_session}")
        train_loader, val_loader, test_loader = get_dataloaders(
            args, test_session_idx=test_session, val_session_idx=val_session
        )
    elif args.dataset == "ccsemo":
        logger.info(f"Fold: {fold_idx}")
        train_loader, val_loader, test_loader = get_dataloaders(args, fold_idx=fold_idx)
    elif args.dataset == "msp":
        logger.info("Using pre-defined Train/Validation/Test split")
        train_loader, val_loader, test_loader = get_dataloaders(args)
    logger.info(
        f"Train: {len(train_loader.dataset)}, Val: {len(val_loader.dataset)}, Test: {len(test_loader.dataset)}"
    )

    device = get_device(args.gpu)
    model = build_model(args).to(device)

    num_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    logger.info(f"Model parameters: {num_params:,}")

    # X
    if args.use_class_weight:
        class_counts = np.zeros(args.num_classes)
        for sample in train_loader.dataset.samples:
            class_counts[sample["label"]] += 1
        # 逆频率加权: weight = total / (num_classes * count)
        total = class_counts.sum()
        class_weights = total / (args.num_classes * class_counts + 1e-6)
        class_weights = torch.tensor(class_weights, dtype=torch.float32).to(device)
        logger.info(f"Class counts: {class_counts.astype(int).tolist()}")
        logger.info(f"Class weights: {[f'{w:.2f}' for w in class_weights.cpu().numpy()]}")
        criterion = nn.CrossEntropyLoss(weight=class_weights)
    else:
        criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)

    total_steps = len(train_loader) * args.epochs
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=total_steps)

    early_stopping = EarlyStopping(patience=args.patience, mode="max")

    history = {
        "train_loss": [],
        "train_uar": [],
        "train_acc": [],
        "val_loss": [],
        "val_uar": [],
        "val_acc": [],
    }

    best_val_uar = 0.0
    for epoch in range(1, args.epochs + 1):
        train_metrics = train_epoch(
            model,
            train_loader,
            optimizer,
            criterion,
            device,
            scheduler,
            num_classes=args.num_classes,
        )
        val_metrics = evaluate(model, val_loader, criterion, device, num_classes=args.num_classes)

        history["train_loss"].append(train_metrics["loss"])
        history["train_uar"].append(train_metrics["uar"])
        history["train_acc"].append(train_metrics["accuracy"])
        history["val_loss"].append(val_metrics["loss"])
        history["val_uar"].append(val_metrics["uar"])
        history["val_acc"].append(val_metrics["accuracy"])

        logger.info(
            f"Epoch {epoch:03d} | "
            f"Train Loss: {train_metrics['loss']:.4f}, UAR: {train_metrics['uar']:.4f} | "
            f"Val Loss: {val_metrics['loss']:.4f}, UAR: {val_metrics['uar']:.4f}"
        )

        is_best = early_stopping(val_metrics["uar"], model)
        if is_best:
            best_val_uar = val_metrics["uar"]
            logger.info(f"New best Val UAR: {best_val_uar:.4f}")

        if early_stopping.early_stop:
            logger.info(f"Early stopping at epoch {epoch}")
            break

    fold_name = fold_idx if fold_idx else test_session

    # 评测 last 模型
    logger.info(f"--- Last Model (Epoch {epoch}) Test Results ---")
    last_ckpt_path = os.path.join(ckpt_dir, f"fold{fold_name}_last.pt")
    save_checkpoint(model, optimizer, epoch, {"last_epoch": epoch}, last_ckpt_path)
    logger.info(f"Saved last model checkpoint to {last_ckpt_path}")

    last_test_metrics = evaluate(
        model, test_loader, criterion, device, num_classes=args.num_classes
    )
    logger.info(f"  WA: {last_test_metrics['WA']:.4f}, UA: {last_test_metrics['UA']:.4f}")
    logger.info(
        f"  Macro F1: {last_test_metrics['macro_f1']:.4f}, Weighted F1: {last_test_metrics['weighted_f1']:.4f}"
    )
    logger.info(
        f"  Per-class Recall: {[f'{x:.4f}' for x in last_test_metrics['per_class_recall']]}"
    )

    # 评测 best 模型
    early_stopping.load_best_model(model)
    model.to(device)

    logger.info(f"--- Best Model (Val UAR: {best_val_uar:.4f}) Test Results ---")
    best_ckpt_path = os.path.join(ckpt_dir, f"fold{fold_name}_best.pt")
    save_checkpoint(model, optimizer, epoch, {"best_val_uar": best_val_uar}, best_ckpt_path)
    logger.info(f"Saved best model checkpoint to {best_ckpt_path}")

    best_test_metrics = evaluate(
        model, test_loader, criterion, device, num_classes=args.num_classes
    )
    logger.info(f"  WA: {best_test_metrics['WA']:.4f}, UA: {best_test_metrics['UA']:.4f}")
    logger.info(
        f"  Macro F1: {best_test_metrics['macro_f1']:.4f}, Weighted F1: {best_test_metrics['weighted_f1']:.4f}"
    )
    logger.info(
        f"  Per-class Recall: {[f'{x:.4f}' for x in best_test_metrics['per_class_recall']]}"
    )
    logger.info(
        f"  Per-class Precision: {[f'{x:.4f}' for x in best_test_metrics['per_class_precision']]}"
    )
    logger.info(f"  Per-class F1: {[f'{x:.4f}' for x in best_test_metrics['per_class_f1']]}")

    saved_figs = save_all_figures(
        history,
        best_test_metrics,
        fig_dir,
        num_classes=args.num_classes,
        fold_idx=fold_name,
        timestamp=timestamp,
    )
    logger.info(f"Saved {len(saved_figs)} figures to {fig_dir}")

    return {"best": best_test_metrics, "last": last_test_metrics}, history


def run_5fold_cv(args, logger, exp_dir, timestamp):
    """IEMOCAP和CCSEMO的5折交叉验证"""
    all_results = []
    all_histories = []

    fig_dir = os.path.join(exp_dir, "figures")
    os.makedirs(fig_dir, exist_ok=True)

    ckpt_dir = os.path.join(exp_dir, "checkpoints")
    os.makedirs(ckpt_dir, exist_ok=True)

    for fold_idx in range(1, 6):
        logger.info(f"\n{'=' * 60}")
        logger.info(f"Fold {fold_idx}/5")
        logger.info(f"{'=' * 60}")

        set_seed(args.seed + fold_idx)

        if args.dataset == "iemocap":
            # IEMOCAP: 按session划分
            test_idx = fold_idx
            val_idx = (fold_idx % 5) + 1
            if val_idx == test_idx:
                val_idx = ((fold_idx + 1) % 5) + 1
            fold_metrics, fold_history = train_single_fold(
                args,
                logger,
                fig_dir,
                ckpt_dir,
                timestamp,
                test_session=test_idx,
                val_session=val_idx,
            )
        elif args.dataset == "ccsemo":
            # CCSEMO: 使用预定义的fold
            fold_metrics, fold_history = train_single_fold(
                args, logger, fig_dir, ckpt_dir, timestamp, fold_idx=fold_idx
            )

        all_results.append(fold_metrics)
        all_histories.append(fold_history)

    best_results = [r["best"] for r in all_results]
    last_results = [r["last"] for r in all_results]

    for model_type, results in [("Best", best_results), ("Last", last_results)]:
        avg_wa = np.mean([r["WA"] for r in results])
        avg_ua = np.mean([r["UA"] for r in results])
        avg_macro_f1 = np.mean([r["macro_f1"] for r in results])
        avg_weighted_f1 = np.mean([r["weighted_f1"] for r in results])
        avg_macro_precision = np.mean([r["macro_precision"] for r in results])
        avg_weighted_precision = np.mean([r["weighted_precision"] for r in results])

        std_wa = np.std([r["WA"] for r in results])
        std_ua = np.std([r["UA"] for r in results])
        std_macro_f1 = np.std([r["macro_f1"] for r in results])
        std_weighted_f1 = np.std([r["weighted_f1"] for r in results])

        logger.info(f"\n{'=' * 70}")
        logger.info(f"5-Fold Cross Validation Final Results ({model_type} Model)")
        logger.info(f"{'=' * 70}")
        logger.info(f"WA (Weighted Accuracy):     {avg_wa:.4f} ± {std_wa:.4f}")
        logger.info(f"UA (Unweighted Accuracy):   {avg_ua:.4f} ± {std_ua:.4f}")
        logger.info(f"Macro F1:                   {avg_macro_f1:.4f} ± {std_macro_f1:.4f}")
        logger.info(f"Weighted F1:                {avg_weighted_f1:.4f} ± {std_weighted_f1:.4f}")
        logger.info(f"Macro Precision:            {avg_macro_precision:.4f}")
        logger.info(f"Weighted Precision:         {avg_weighted_precision:.4f}")
        logger.info(f"{'=' * 70}")

        logger.info(f"\nPer-Fold Results ({model_type}):")
        logger.info(f"{'Fold':<6} {'WA':<10} {'UA':<10} {'Macro-F1':<12} {'Weighted-F1':<12}")
        logger.info("-" * 50)
        for i, r in enumerate(results, 1):
            logger.info(
                f"{i:<6} {r['WA']:<10.4f} {r['UA']:<10.4f} {r['macro_f1']:<12.4f} {r['weighted_f1']:<12.4f}"
            )

    total_cm = sum(r["confusion_matrix"] for r in best_results)
    logger.info("\nAggregated Confusion Matrix (sum of 5 folds, Best Model):")
    logger.info(f"{total_cm}")

    summary_fig = plot_5fold_summary(best_results, fig_dir, timestamp)
    logger.info(f"Saved 5-fold summary figure: {summary_fig}")

    avg_wa = np.mean([r["WA"] for r in best_results])
    avg_ua = np.mean([r["UA"] for r in best_results])
    avg_macro_f1 = np.mean([r["macro_f1"] for r in best_results])
    avg_weighted_f1 = np.mean([r["weighted_f1"] for r in best_results])
    avg_macro_precision = np.mean([r["macro_precision"] for r in best_results])
    avg_weighted_precision = np.mean([r["weighted_precision"] for r in best_results])
    std_wa = np.std([r["WA"] for r in best_results])
    std_ua = np.std([r["UA"] for r in best_results])
    std_macro_f1 = np.std([r["macro_f1"] for r in best_results])
    std_weighted_f1 = np.std([r["weighted_f1"] for r in best_results])

    results_summary = {
        "overall_best": {
            "WA": {"mean": float(avg_wa), "std": float(std_wa)},
            "UA": {"mean": float(avg_ua), "std": float(std_ua)},
            "macro_f1": {"mean": float(avg_macro_f1), "std": float(std_macro_f1)},
            "weighted_f1": {"mean": float(avg_weighted_f1), "std": float(std_weighted_f1)},
            "macro_precision": float(avg_macro_precision),
            "weighted_precision": float(avg_weighted_precision),
        },
        "overall_last": {
            "WA": {
                "mean": float(np.mean([r["WA"] for r in last_results])),
                "std": float(np.std([r["WA"] for r in last_results])),
            },
            "UA": {
                "mean": float(np.mean([r["UA"] for r in last_results])),
                "std": float(np.std([r["UA"] for r in last_results])),
            },
            "macro_f1": {
                "mean": float(np.mean([r["macro_f1"] for r in last_results])),
                "std": float(np.std([r["macro_f1"] for r in last_results])),
            },
            "weighted_f1": {
                "mean": float(np.mean([r["weighted_f1"] for r in last_results])),
                "std": float(np.std([r["weighted_f1"] for r in last_results])),
            },
        },
        "fold_results_best": [
            {
                "fold": i + 1,
                "WA": float(r["WA"]),
                "UA": float(r["UA"]),
                "macro_f1": float(r["macro_f1"]),
                "weighted_f1": float(r["weighted_f1"]),
                "macro_precision": float(r["macro_precision"]),
                "weighted_precision": float(r["weighted_precision"]),
                "per_class_recall": [float(x) for x in r["per_class_recall"]],
                "per_class_precision": [float(x) for x in r["per_class_precision"]],
                "per_class_f1": [float(x) for x in r["per_class_f1"]],
                "confusion_matrix": r["confusion_matrix"].tolist(),
            }
            for i, r in enumerate(best_results)
        ],
        "fold_results_last": [
            {
                "fold": i + 1,
                "WA": float(r["WA"]),
                "UA": float(r["UA"]),
                "macro_f1": float(r["macro_f1"]),
                "weighted_f1": float(r["weighted_f1"]),
            }
            for i, r in enumerate(last_results)
        ],
        "aggregated_confusion_matrix": total_cm.tolist(),
        "config": {k: str(v) for k, v in vars(args).items()},
    }

    results_path = os.path.join(exp_dir, f"results_{timestamp}.json")
    with open(results_path, "w") as f:
        json.dump(results_summary, f, indent=2)
    logger.info(f"Saved results to {results_path}")

    return results_summary


def run_single_split(args, logger, exp_dir, timestamp):
    """MSP数据集：使用预定义的Train/Validation/Test划分"""
    fig_dir = os.path.join(exp_dir, "figures")
    os.makedirs(fig_dir, exist_ok=True)

    ckpt_dir = os.path.join(exp_dir, "checkpoints")
    os.makedirs(ckpt_dir, exist_ok=True)

    set_seed(args.seed)

    metrics_dict, history = train_single_fold(
        args,
        logger,
        fig_dir,
        ckpt_dir,
        timestamp,
        fold_idx=1,  # MSP只有一个划分
    )

    best_metrics = metrics_dict["best"]
    last_metrics = metrics_dict["last"]

    for model_type, test_metrics in [("Best", best_metrics), ("Last", last_metrics)]:
        logger.info(f"\n{'=' * 70}")
        logger.info(f"Final Results ({model_type} Model)")
        logger.info(f"{'=' * 70}")
        logger.info(f"WA (Weighted Accuracy):     {test_metrics['WA']:.4f}")
        logger.info(f"UA (Unweighted Accuracy):   {test_metrics['UA']:.4f}")
        logger.info(f"Macro F1:                   {test_metrics['macro_f1']:.4f}")
        logger.info(f"Weighted F1:                {test_metrics['weighted_f1']:.4f}")
        logger.info(f"Macro Precision:            {test_metrics['macro_precision']:.4f}")
        logger.info(f"Weighted Precision:         {test_metrics['weighted_precision']:.4f}")
        logger.info(f"{'=' * 70}")

    results_summary = {
        "overall_best": {
            "WA": float(best_metrics["WA"]),
            "UA": float(best_metrics["UA"]),
            "macro_f1": float(best_metrics["macro_f1"]),
            "weighted_f1": float(best_metrics["weighted_f1"]),
            "macro_precision": float(best_metrics["macro_precision"]),
            "weighted_precision": float(best_metrics["weighted_precision"]),
        },
        "overall_last": {
            "WA": float(last_metrics["WA"]),
            "UA": float(last_metrics["UA"]),
            "macro_f1": float(last_metrics["macro_f1"]),
            "weighted_f1": float(last_metrics["weighted_f1"]),
        },
        "per_class_recall": [float(x) for x in best_metrics["per_class_recall"]],
        "per_class_precision": [float(x) for x in best_metrics["per_class_precision"]],
        "per_class_f1": [float(x) for x in best_metrics["per_class_f1"]],
        "confusion_matrix": best_metrics["confusion_matrix"].tolist(),
        "config": {k: str(v) for k, v in vars(args).items()},
    }

    results_path = os.path.join(exp_dir, f"results_{timestamp}.json")
    with open(results_path, "w") as f:
        json.dump(results_summary, f, indent=2)
    logger.info(f"Saved results to {results_path}")

    return results_summary


def main() -> None:
    args = get_args()

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    if args.note:
        exp_name = (
            f"{args.dataset}_{args.feature_type}_{args.layer}_{args.num_classes}_class_{timestamp}"
        )
        log_base_dir = os.path.join(args.log_dir, args.note)
    else:
        exp_name = f"{args.dataset}_{args.feature_type}_{args.layer}_{timestamp}"
        log_base_dir = args.log_dir

    exp_dir = os.path.join(log_base_dir, exp_name)
    os.makedirs(exp_dir, exist_ok=True)

    logger = setup_logging(exp_dir, exp_name)

    logger.info("Configuration:")
    for k, v in vars(args).items():
        logger.info(f"  {k}: {v}")

    set_seed(args.seed)

    if args.dataset in ["iemocap", "ccsemo"]:
        run_5fold_cv(args, logger, exp_dir, timestamp)
    elif args.dataset == "msp":
        run_single_split(args, logger, exp_dir, timestamp)


if __name__ == "__main__":
    main()
