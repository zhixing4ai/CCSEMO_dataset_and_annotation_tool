"""
提取实验结果
@Time: 2024-12-30
"""

import argparse
import re
from pathlib import Path

import pandas as pd


def extract_final_results(log_file):
    results = {}

    with open(log_file, "r") as f:
        content = f.read()

    if "Final Results" not in content:
        return None

    patterns = {
        "WA": r"WA \(Weighted Accuracy\):\s+([\d.]+)",
        "UA": r"UA \(Unweighted Accuracy\):\s+([\d.]+)",
        "Macro_F1": r"Macro F1:\s+([\d.]+)",
        "Weighted_F1": r"Weighted F1:\s+([\d.]+)",
        "Macro_Precision": r"Macro Precision:\s+([\d.]+)",
        "Weighted_Precision": r"Weighted Precision:\s+([\d.]+)",
    }

    for key, pattern in patterns.items():
        match = re.search(pattern, content)
        if match:
            results[key] = float(match.group(1))

    log_name = Path(log_file).parent.name
    parts = log_name.split("_")

    if len(parts) >= 4:
        results["dataset"] = parts[0]
        results["feature"] = parts[1] + "_" + parts[2]  # e.g., wavlm_large
        results["layer"] = parts[3] + "_" + parts[4] if len(parts) > 4 else parts[3]

        if "4_class" in log_name:
            results["num_classes"] = 4
        elif "7_class" in log_name:
            results["num_classes"] = 7
        else:
            results["num_classes"] = "unknown"

        results["weighted_loss"] = "weighted" in log_name

    results["exp_name"] = log_name

    return results


def extract_5fold_results(log_file):
    results = {}

    with open(log_file, "r") as f:
        content = f.read()

    if "5-Fold Cross Validation Final Results" not in content:
        return None

    patterns = {
        "WA": r"WA \(Weighted Accuracy\):\s+([\d.]+)\s*±\s*([\d.]+)",
        "UA": r"UA \(Unweighted Accuracy\):\s+([\d.]+)\s*±\s*([\d.]+)",
        "Macro_F1": r"Macro F1:\s+([\d.]+)\s*±\s*([\d.]+)",
        "Weighted_F1": r"Weighted F1:\s+([\d.]+)\s*±\s*([\d.]+)",
    }

    for key, pattern in patterns.items():
        match = re.search(pattern, content)
        if match:
            results[key] = float(match.group(1))
            results[f"{key}_std"] = float(match.group(2))

    simple_patterns = {
        "Macro_Precision": r"Macro Precision:\s+([\d.]+)",
        "Weighted_Precision": r"Weighted Precision:\s+([\d.]+)",
    }

    for key, pattern in simple_patterns.items():
        match = re.search(pattern, content)
        if match:
            results[key] = float(match.group(1))

    log_name = Path(log_file).parent.name
    parts = log_name.split("_")

    if len(parts) >= 4:
        results["dataset"] = parts[0]
        results["feature"] = parts[1] + "_" + parts[2]
        results["layer"] = parts[3] + "_" + parts[4] if len(parts) > 4 else parts[3]

        if "4_class" in log_name:
            results["num_classes"] = 4
        elif "7_class" in log_name:
            results["num_classes"] = 7
        else:
            results["num_classes"] = "unknown"

        results["weighted_loss"] = "weighted" in log_name

    results["exp_name"] = log_name

    return results


def main():
    parser = argparse.ArgumentParser(description="Extract experiment results from logs")
    parser.add_argument("--log_dir", type=str, default="logs", help="Log directory")
    parser.add_argument(
        "--prefix", type=str, default="", help="Filter by prefix (e.g., 'msp', 'iemocap', 'ccsemo')"
    )
    parser.add_argument("--output", type=str, default="results_summary.csv", help="Output CSV file")
    args = parser.parse_args()

    log_dir = Path(args.log_dir)
    all_results = []

    for exp_dir in sorted(log_dir.iterdir()):
        if not exp_dir.is_dir():
            continue

        if args.prefix and not exp_dir.name.startswith(args.prefix):
            continue

        log_files = list(exp_dir.glob("*.log"))
        if not log_files:
            continue

        log_file = log_files[0]

        results = extract_final_results(log_file)
        if results is None:
            results = extract_5fold_results(log_file)

        if results:
            all_results.append(results)
            print(f"Extracted: {exp_dir.name}")

    if not all_results:
        print("No results found!")
        return

    df = pd.DataFrame(all_results)

    cols_order = [
        "exp_name",
        "dataset",
        "feature",
        "layer",
        "num_classes",
        "weighted_loss",
        "WA",
        "UA",
        "Macro_F1",
        "Weighted_F1",
        "Macro_Precision",
        "Weighted_Precision",
    ]
    cols_order = [c for c in cols_order if c in df.columns]
    other_cols = [c for c in df.columns if c not in cols_order]
    df = df[cols_order + other_cols]

    layer_order = {"last_layer": 0, "12_layer": 1}
    df["layer_order"] = df["layer"].map(lambda x: layer_order.get(x, 2))
    df = df.sort_values(by=["layer_order", "num_classes", "feature"]).drop(columns=["layer_order"])

    output_path = log_dir / args.output
    df.to_csv(output_path, index=False)
    print(f"\nSaved {len(all_results)} results to {output_path}")

    print("\n" + "=" * 80)
    print("Results Summary:")
    print("=" * 80)

    for layer in ["last_layer", "12_layer"]:
        for nc in [4, 7]:
            subset = df[(df["layer"] == layer) & (df["num_classes"] == nc)]
            if len(subset) == 0:
                continue
            print(f"\n--- {layer} / {nc}-class ---")
            display_cols = ["feature", "WA", "UA", "Macro_F1", "Weighted_F1"]
            display_cols = [c for c in display_cols if c in subset.columns]
            print(subset[display_cols].to_string(index=False))


if __name__ == "__main__":
    main()
