# CCSEMO Baseline

A PyTorch-based Speech Emotion Recognition (SER) baseline supporting multiple datasets and self-supervised learning features.

## Features

- **Multi-dataset Support**: IEMOCAP, CCSEMO, MSP-IMPROV
- **Self-supervised Features**: HuBERT-Large, Wav2Vec2-Large, WavLM-Large
- **Flexible Architecture**: Transformer-based classifier with multi-head attention
- **Layer Fusion**: Supports weighted fusion of all SSL model layers or single-layer features
- **Class Weighting**: Optional class-balanced loss for imbalanced datasets
- **5-Fold Cross-Validation**: Session-based (IEMOCAP) or speaker-independent (CCSEMO/MSP)

## Requirements

- Python >= 3.12
- PyTorch 2.6.0
- CUDA-compatible GPU (recommended)

Dependencies are managed via [uv](https://github.com/astral-sh/uv). Install from `pyproject.toml`:

```bash
uv sync
```

## Project Structure

```
.
├── src/
│   ├── config/          # Dataset configs and emotion label mappings
│   ├── data/            # DataLoaders for IEMOCAP/CCSEMO/MSP
│   ├── models/          # Transformer classifier with layer fusion
│   └── utils/           # Training, evaluation, visualization utilities
├── scripts/             # Shell scripts for training (IEMOCAP/CCSEMO/MSP)
├── train.py             # Main training script with 5-fold CV
└── pyproject.toml       # Project dependencies
```

## Quick Start

### 1. Prepare Features

Extract features from pre-trained SSL models (HuBERT/Wav2Vec2/WavLM). Features should be saved as:

```
data/{model_name}/{dataset}/last_layer/*.p  # Single-layer features
data/{model_name}/{dataset}/all_layers/*.p  # All-layer features (for fusion)
```

Each `.p` file contains a NumPy array of shape `(seq_len, hidden_dim)` or `(num_layers, seq_len, hidden_dim)`.

### 2. Prepare Labels

- **IEMOCAP**: CSV file at `prepared/files/iemocap_label.csv` with columns: `file_path, emotion, session`
- **CCSEMO**: 5-fold split files in `{fold_dir}/fold_{1-5}_train.csv` and `fold_{1-5}_test.csv`
- **MSP-IMPROV**: Similar to CCSEMO structure

### 3. Run Training

Use provided shell scripts in `scripts/`:

```bash
# CCSEMO (4-class, weighted loss)
bash scripts/run_ccsemo.sh

# IEMOCAP (4-class)
bash scripts/run_iemocap.sh

# MSP-IMPROV (4-class)
bash scripts/run_msp.sh
```

Or run directly with `train.py`:

```bash
uv run python train.py \
    --dataset ccsemo \
    --feature_type wav2vec_large \
    --layer fusion_layer \
    --num_classes 4 \
    --batch_size 32 \
    --lr 1e-4 \
    --epochs 100 \
    --use_class_weight
```

## Key Arguments

| Argument | Description | Default |
|----------|-------------|---------|
| `--dataset` | Dataset name: `iemocap`, `ccsemo`, `msp` | - |
| `--feature_type` | SSL model: `hubert_large`, `wav2vec_large`, `wavlm_large` | - |
| `--layer` | Feature layer: `last_layer` or `fusion_layer` (all layers) | `last_layer` |
| `--num_classes` | Number of emotion classes (4 or 7) | 4 |
| `--hidden_dim` | Transformer hidden dimension | 256 |
| `--num_heads` | Multi-head attention heads | 4 |
| `--num_layers` | Transformer encoder layers | 2 |
| `--dropout` | Dropout rate | 0.3 |
| `--use_class_weight` | Enable class-balanced loss | False |
| `--patience` | Early stopping patience (epochs) | 10 |

## Outputs

Training generates:

- **Logs**: `logs/{NOTE}/{timestamp}.log` with per-fold metrics
- **Checkpoints**: `checkpoints/{NOTE}/{timestamp}/fold_X_best.pth`
- **Visualizations**: Loss curves, confusion matrices, 5-fold summary plots

Final metrics are averaged across 5 folds and logged at the end.
