import os
import sqlite3
import sys
from config import Config

# 添加项目根目录到Python路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.unified_db_manager import unified_db_manager

class UserModel:
    """用户数据模型类"""
    
    def __init__(self):
        """初始化数据库连接"""
        # 使用统一数据库管理器
        self.db_manager = unified_db_manager
    
    def init_database(self):
        """初始化数据库表（已由统一数据库管理器处理）"""
        # 数据库初始化已由统一数据库管理器处理
        pass
    
    def add_user(self, wechat_name, phone_number):
        """添加新用户"""
        return self.db_manager.create_user(wechat_name, phone_number)
    
    def get_user(self, wechat_name):
        """根据微信名获取用户信息"""
        return self.db_manager.get_user(wechat_name)
    
    def verify_user(self, wechat_name, phone_number):
        """验证用户信息"""
        user = self.get_user(wechat_name)
        if user and user['phone_number'] == phone_number:
            return True
        return False
    
    def get_all_users(self):
        """获取所有用户"""
        return self.db_manager.get_all_users()
    
    def update_user_test_settings(self, wechat_name, skip_test=None, skip_consistency_test=None):
        """更新用户测试设置"""
        update_data = {}
        if skip_test is not None:
            update_data['skip_test'] = skip_test
        if skip_consistency_test is not None:
            update_data['skip_consistency_test'] = skip_consistency_test
        
        if update_data:
            return self.db_manager.update_user(wechat_name, **update_data)
        return True
    
    def get_user_test_settings(self, wechat_name):
        """获取用户的测试跳过设置"""
        user = self.get_user(wechat_name)
        if user:
            return {
                'skip_test': user.get('skip_test', False),
                'skip_consistency_test': user.get('skip_consistency_test', False),
                'second_consistency_test_completed': user.get('second_consistency_test_completed', False)
            }
        return None
    
    def save_volume_setting(self, wechat_name, volume):
        """保存用户音量设置"""
        return self.db_manager.update_user(wechat_name, volume_setting=volume, volume_test_completed=True)
    
    def get_volume_setting(self, wechat_name):
        """获取用户音量设置"""
        user = self.get_user(wechat_name)
        if user:
            return {
                'volume_setting': user.get('volume_setting'),
                'volume_test_completed': user.get('volume_test_completed', False)
            }
        return None
    
    def has_completed_volume_test(self, wechat_name):
        """检查用户是否已完成音量测试"""
        volume_info = self.get_volume_setting(wechat_name)
        return volume_info and volume_info.get('volume_test_completed', False)
    
    def mark_second_consistency_test_completed(self, wechat_name):
        """标记第二次一致性测试完成"""
        return self.db_manager.update_user(wechat_name, second_consistency_test_completed=True)
    
    def update_volume_setting(self, wechat_name, volume_setting):
        """更新用户音量设置"""
        return self.db_manager.update_user(wechat_name, volume_setting=volume_setting)
    
    def mark_volume_test_completed(self, wechat_name):
        """标记音量测试完成"""
        return self.db_manager.update_user(wechat_name, volume_test_completed=True)
    
    def update_user_group(self, wechat_name, group_id):
        """更新用户分组"""
        return self.db_manager.update_user(wechat_name, group_id=group_id)