# -*- coding: utf-8 -*-
"""
性能优化配置文件
用于配置各种性能优化参数
"""

import os
from typing import Dict, Any

class PerformanceConfig:
    """
    性能优化配置类
    """
    
    def __init__(self):
        self.config = self._load_default_config()
        self._load_env_overrides()
    
    def _load_default_config(self) -> Dict[str, Any]:
        """
        加载默认配置
        
        Returns:
            Dict[str, Any]: 默认配置字典
        """
        return {
            # 数据库优化配置
            'database': {
                'batch_update_interval': 30,  # 批量更新间隔（秒）
                'cache_expiry': 300,  # 缓存过期时间（秒）
                'connection_pool_size': 10,  # 连接池大小
                'query_timeout': 30,  # 查询超时时间（秒）
                'enable_wal_mode': True,  # 启用WAL模式
                'enable_foreign_keys': True,  # 启用外键约束
                'pragma_settings': {
                    'journal_mode': 'WAL',
                    'synchronous': 'NORMAL',
                    'cache_size': -64000,  # 64MB缓存
                    'temp_store': 'MEMORY',
                    'mmap_size': 268435456,  # 256MB内存映射
                }
            },
            
            # 前端优化配置
            'frontend': {
                'consistency_check': {
                    'time_interval': 30,  # 时间间隔检查（秒）
                    'save_count_interval': 10,  # 保存次数间隔检查
                    'cache_duration': 60,  # 缓存持续时间（秒）
                    'enable_smart_check': True,  # 启用智能检查
                },
                'ui_optimization': {
                    'debounce_delay': 300,  # 防抖延迟（毫秒）
                    'throttle_delay': 100,  # 节流延迟（毫秒）
                    'lazy_load_threshold': 50,  # 懒加载阈值
                    'virtual_scroll_enabled': True,  # 启用虚拟滚动
                },
                'network': {
                    'request_timeout': 30000,  # 请求超时（毫秒）
                    'retry_attempts': 3,  # 重试次数
                    'retry_delay': 1000,  # 重试延迟（毫秒）
                    'enable_request_cache': True,  # 启用请求缓存
                }
            },
            
            # 音频处理优化配置
            'audio': {
                'duration_calculation': {
                    'enable_async': True,  # 启用异步计算
                    'batch_size': 20,  # 批量处理大小
                    'cache_results': True,  # 缓存计算结果
                    'use_metadata': True,  # 优先使用元数据
                },
                'loading': {
                    'preload_count': 3,  # 预加载音频数量
                    'enable_compression': True,  # 启用压缩
                    'quality_level': 'medium',  # 音质级别
                }
            },
            
            # 进度更新优化配置
            'progress': {
                'update_strategy': 'batch',  # 更新策略: 'immediate', 'batch', 'hybrid'
                'batch_size': 50,  # 批量大小
                'update_interval': 30,  # 更新间隔（秒）
                'enable_real_time': False,  # 启用实时更新
                'cache_user_progress': True,  # 缓存用户进度
            },
            
            # 日志和监控配置
            'monitoring': {
                'enable_performance_logging': True,  # 启用性能日志
                'log_slow_queries': True,  # 记录慢查询
                'slow_query_threshold': 1.0,  # 慢查询阈值（秒）
                'enable_metrics': True,  # 启用指标收集
                'metrics_interval': 60,  # 指标收集间隔（秒）
            },
            
            # 系统资源配置
            'system': {
                'max_memory_usage': '512MB',  # 最大内存使用
                'max_cpu_usage': 80,  # 最大CPU使用率（%）
                'enable_gc_optimization': True,  # 启用垃圾回收优化
                'thread_pool_size': 4,  # 线程池大小
            }
        }
    
    def _load_env_overrides(self):
        """
        从环境变量加载配置覆盖
        """
        # 数据库配置覆盖
        if os.getenv('DB_BATCH_INTERVAL'):
            self.config['database']['batch_update_interval'] = int(os.getenv('DB_BATCH_INTERVAL'))
        
        if os.getenv('DB_CACHE_EXPIRY'):
            self.config['database']['cache_expiry'] = int(os.getenv('DB_CACHE_EXPIRY'))
        
        # 前端配置覆盖
        if os.getenv('CONSISTENCY_CHECK_INTERVAL'):
            self.config['frontend']['consistency_check']['time_interval'] = int(os.getenv('CONSISTENCY_CHECK_INTERVAL'))
        
        if os.getenv('CONSISTENCY_SAVE_INTERVAL'):
            self.config['frontend']['consistency_check']['save_count_interval'] = int(os.getenv('CONSISTENCY_SAVE_INTERVAL'))
        
        # 进度更新策略覆盖
        if os.getenv('PROGRESS_UPDATE_STRATEGY'):
            strategy = os.getenv('PROGRESS_UPDATE_STRATEGY')
            if strategy in ['immediate', 'batch', 'hybrid']:
                self.config['progress']['update_strategy'] = strategy
    
    def get(self, key_path: str, default=None):
        """
        获取配置值
        
        Args:
            key_path: 配置键路径，如 'database.batch_update_interval'
            default: 默认值
            
        Returns:
            配置值
        """
        keys = key_path.split('.')
        value = self.config
        
        try:
            for key in keys:
                value = value[key]
            return value
        except (KeyError, TypeError):
            return default
    
    def set(self, key_path: str, value):
        """
        设置配置值
        
        Args:
            key_path: 配置键路径
            value: 配置值
        """
        keys = key_path.split('.')
        config = self.config
        
        for key in keys[:-1]:
            if key not in config:
                config[key] = {}
            config = config[key]
        
        config[keys[-1]] = value
    
    def get_database_config(self) -> Dict[str, Any]:
        """
        获取数据库配置
        
        Returns:
            Dict[str, Any]: 数据库配置
        """
        return self.config['database']
    
    def get_frontend_config(self) -> Dict[str, Any]:
        """
        获取前端配置
        
        Returns:
            Dict[str, Any]: 前端配置
        """
        return self.config['frontend']
    
    def get_optimization_level(self) -> str:
        """
        根据当前配置确定优化级别
        
        Returns:
            str: 优化级别 ('conservative', 'balanced', 'aggressive')
        """
        # 根据关键配置参数判断优化级别
        batch_interval = self.get('database.batch_update_interval')
        cache_expiry = self.get('database.cache_expiry')
        consistency_interval = self.get('frontend.consistency_check.time_interval')
        
        if batch_interval >= 60 and cache_expiry >= 600 and consistency_interval >= 60:
            return 'conservative'  # 保守优化
        elif batch_interval <= 15 and cache_expiry <= 120 and consistency_interval <= 15:
            return 'aggressive'  # 激进优化
        else:
            return 'balanced'  # 平衡优化
    
    def apply_optimization_preset(self, preset: str):
        """
        应用优化预设
        
        Args:
            preset: 预设名称 ('conservative', 'balanced', 'aggressive')
        """
        presets = {
            'conservative': {
                'database.batch_update_interval': 60,
                'database.cache_expiry': 600,
                'frontend.consistency_check.time_interval': 60,
                'frontend.consistency_check.save_count_interval': 20,
                'progress.update_strategy': 'batch',
            },
            'balanced': {
                'database.batch_update_interval': 30,
                'database.cache_expiry': 300,
                'frontend.consistency_check.time_interval': 30,
                'frontend.consistency_check.save_count_interval': 10,
                'progress.update_strategy': 'hybrid',
            },
            'aggressive': {
                'database.batch_update_interval': 15,
                'database.cache_expiry': 120,
                'frontend.consistency_check.time_interval': 15,
                'frontend.consistency_check.save_count_interval': 5,
                'progress.update_strategy': 'immediate',
            }
        }
        
        if preset in presets:
            for key_path, value in presets[preset].items():
                self.set(key_path, value)
    
    def export_config(self) -> Dict[str, Any]:
        """
        导出当前配置
        
        Returns:
            Dict[str, Any]: 完整配置字典
        """
        return self.config.copy()
    
    def import_config(self, config: Dict[str, Any]):
        """
        导入配置
        
        Args:
            config: 配置字典
        """
        self.config.update(config)

# 全局配置实例
performance_config = PerformanceConfig()

# 便捷函数
def get_config(key_path: str, default=None):
    """
    获取配置值的便捷函数
    
    Args:
        key_path: 配置键路径
        default: 默认值
        
    Returns:
        配置值
    """
    return performance_config.get(key_path, default)

def set_config(key_path: str, value):
    """
    设置配置值的便捷函数
    
    Args:
        key_path: 配置键路径
        value: 配置值
    """
    performance_config.set(key_path, value)

def apply_preset(preset: str):
    """
    应用优化预设的便捷函数
    
    Args:
        preset: 预设名称
    """
    performance_config.apply_optimization_preset(preset)