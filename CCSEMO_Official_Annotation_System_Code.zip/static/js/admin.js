/**
 * 管理员仪表板JavaScript
 * 处理管理员后台的前端交互逻辑
 */

class AdminDashboard {
    /**
     * 初始化管理员仪表板
     */
    constructor() {
        this.currentSection = 'users';
        this.charts = {};
        this.init();
    }

    /**
     * 将分组文本转换为group_id
     * @param {string} groupText - 分组文本（如"第一组"）
     * @returns {number|null} group_id
     */
    parseGroupTextToId(groupText) {
        if (!groupText || groupText === '未分组') return null;
        
        // 删除了测试组功能
        
        // 处理中文数字的分组
        const chineseNumbers = {
            '一': 1,
            '二': 2,
            '三': 3,
            '四': 4,
            '五': 5,
            '六': 6,
            '七': 7,
            '八': 8,
            '九': 9,
            '十': 10
        };
        
        const match = groupText.match(/第([一二三四五六七八九十])组/);
        if (match) {
            return chineseNumbers[match[1]] || null;
        }
        
        // 兼容阿拉伯数字格式
        const arabicMatch = groupText.match(/第(\d+)组/);
        return arabicMatch ? parseInt(arabicMatch[1]) : null;
    }

    /**
     * 将group_id转换为显示文本
     * @param {number|null} groupId - group_id
     * @returns {string} 显示文本
     */
    formatGroupIdToText(groupId) {
        if (!groupId) return '未分组';
        // 删除了测试组功能
        
        // 将数字转换为中文数字显示
        const numberToChinese = {
            1: '一',
            2: '二', 
            3: '三',
            5: '五',
            6: '六',
            7: '七',
            8: '八',
            9: '九',
            10: '十'
        };
        
        const chineseNumber = numberToChinese[groupId];
        return chineseNumber ? `第${chineseNumber}组` : `第${groupId}组`;
    }

    /**
     * 初始化仪表板
     */
    init() {
        this.bindEvents();
        this.loadUsersData();
        this.setupNavigation();
    }

    /**
     * 绑定事件监听器
     */
    bindEvents() {
        // 登出按钮
        document.getElementById('logout-btn').addEventListener('click', () => {
            this.logout();
        });

        // 刷新按钮
        document.getElementById('refresh-users')?.addEventListener('click', () => {
            this.loadUsersData();
        });

        document.getElementById('refresh-admins')?.addEventListener('click', () => {
            this.loadAdminsData();
        });

        document.getElementById('refresh-test-settings')?.addEventListener('click', () => {
            this.loadTestSettingsData();
        });

        document.getElementById('refresh-speakers')?.addEventListener('click', () => {
            this.loadSpeakersData();
        });

        // 绑定分组选择事件
        document.getElementById('group-filter')?.addEventListener('change', (e) => {
            this.onGroupFilterChange(e.target.value);
        });

        // 用户分组筛选事件
        document.getElementById('user-group-filter')?.addEventListener('change', (e) => {
            this.loadUsersData(); // 重新加载用户数据以应用筛选
        });

        // 质量分析分组选择事件
        document.getElementById('quality-group-filter')?.addEventListener('change', (e) => {
            this.onQualityGroupFilterChange(e.target.value);
        });

        // 质量分析刷新按钮
        document.getElementById('refresh-quality')?.addEventListener('click', () => {
            const groupId = document.getElementById('quality-group-filter')?.value;
            this.loadQualityData(groupId || null);
        });

        document.getElementById('refresh-system-status')?.addEventListener('click', () => {
            this.loadSystemStatus();
        });

        // 管理员管理按钮
        document.getElementById('create-admin-btn')?.addEventListener('click', () => {
            this.showCreateAdminModal();
        });

        document.getElementById('change-password-btn')?.addEventListener('click', () => {
            this.showChangePasswordModal();
        });

        // 管理员表单提交
        document.getElementById('create-admin-form')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.createAdmin();
        });

        document.getElementById('change-password-form')?.addEventListener('submit', (e) => {
            console.log('修改密码表单提交事件触发');
            e.preventDefault();
            this.changePassword();
        });

        // 用户分组表单提交
        document.getElementById('user-group-form')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.updateUserGroup();
        });

        // 导出按钮
        document.getElementById('export-btn')?.addEventListener('click', () => {
            this.exportData();
        });

        // 直接下载按钮
        document.getElementById('download-btn')?.addEventListener('click', () => {
            this.downloadData();
        });

        // 用户详情导出CSV按钮
        document.getElementById('export-user-csv-btn')?.addEventListener('click', () => {
            this.exportUserDetailsToCSV();
        });

        document.getElementById('backup-btn')?.addEventListener('click', () => {
            this.backupDatabase();
        });

        // 一致性分析按钮
        // 第一次一致性计算按钮
        const calculateFirstBtn = document.getElementById('calculate-first-consistency');
        console.log('计算第一次一致性按钮元素:', calculateFirstBtn);
        calculateFirstBtn?.addEventListener('click', () => {
            console.log('计算第一次一致性按钮被点击');
            this.calculateFirstConsistency();
        });

        // 第二次一致性计算按钮
        const calculateSecondBtn = document.getElementById('calculate-second-consistency');
        console.log('计算第二次一致性按钮元素:', calculateSecondBtn);
        calculateSecondBtn?.addEventListener('click', () => {
            console.log('计算第二次一致性按钮被点击');
            this.calculateSecondConsistency();
        });

        document.getElementById('export-consistency-data')?.addEventListener('click', () => {
            this.showExportOptions();
        });

        document.getElementById('generate-consistency-report')?.addEventListener('click', () => {
            this.generateDetailedConsistencyReport();
        });

        document.getElementById('export-all-consistency-results')?.addEventListener('click', () => {
            this.exportAllConsistencyResults();
        });

        // 第二次一致性报告按钮
        document.getElementById('generate-second-consistency-report')?.addEventListener('click', () => {
            this.generateDetailedSecondConsistencyReport();
        });

        document.getElementById('export-second-consistency-data')?.addEventListener('click', () => {
            this.showSecondExportOptions();
        });

        document.getElementById('export-all-second-consistency-results')?.addEventListener('click', () => {
            this.exportAllSecondConsistencyResults();
        });

        // 模态框关闭
        document.querySelectorAll('.close').forEach(closeBtn => {
            closeBtn.addEventListener('click', (e) => {
                e.target.closest('.modal').style.display = 'none';
            });
        });

        // 点击模态框外部关闭
        window.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                e.target.style.display = 'none';
            }
        });

        // 图表导出按钮事件监听器 - 使用事件委托处理所有导出按钮
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('export-chart-btn')) {
                const chartId = e.target.getAttribute('data-chart');
                let filename = '';
                
                // 根据图表ID确定文件名
                switch(chartId) {
                    case 'a-value-chart':
                        filename = '分组A值分布图';
                        break;
                    case 'v-value-chart':
                        filename = '分组V值分布图';
                        break;
                    case 'discrete-emotion-user-chart':
                        filename = '分组离散情感分布图';
                        break;
                    case 'global-a-value-chart':
                        filename = '全局A值分布图';
                        break;
                    case 'global-v-value-chart':
                        filename = '全局V值分布图';
                        break;
                    case 'discrete-emotion-chart':
                        filename = '全局离散情感分布图';
                        break;
                    default:
                        filename = '图表';
                }
                
                this.exportChartAsImage(chartId, filename);
            }
        });
    }

    /**
     * 设置导航
     */
    setupNavigation() {
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = link.dataset.section;
                this.switchSection(section);
            });
        });
    }

    /**
     * 切换页面部分
     * @param {string} section - 要切换到的部分
     */
    switchSection(section) {
        // 更新导航状态
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
        });
        document.querySelector(`[data-section="${section}"]`).classList.add('active');

        // 更新内容区域
        document.querySelectorAll('.content-section').forEach(sec => {
            sec.classList.remove('active');
        });
        document.getElementById(`${section}-section`).classList.add('active');

        this.currentSection = section;

        // 加载对应数据
        this.loadSectionData(section);
    }

    /**
     * 加载指定部分的数据
     * @param {string} section - 部分名称
     */
    loadSectionData(section) {
        switch (section) {
            case 'users':
                this.loadUsersData();
                break;
            case 'admins':
                this.loadAdminsData();
                break;
            case 'test-settings':
                this.loadTestSettingsData();
                break;
            case 'speakers':
                this.loadGroupsList();
                this.loadSpeakersData();
                break;

            case 'quality':
                this.loadQualityGroupsList();
                this.loadQualityData();
                break;
            case 'consistency':
                this.loadConsistencyData();
                break;
            case 'system':
                this.loadSystemStatus();
                break;
        }
    }

    /**
     * 加载用户数据
     */
    async loadUsersData() {
        try {
            const response = await fetch('/admin/api/users');
            const data = await response.json();

            if (response.ok) {
                this.updateUsersTable(data);
            } else {
                this.showError('加载用户数据失败: ' + data.error);
            }
        } catch (error) {
            this.showError('网络错误: ' + error.message);
        }
    }

    /**
     * 更新用户表格
     * @param {Array} users - 用户数据数组
     */
    updateUsersTable(users) {
        const tbody = document.querySelector('#users-table tbody');
        tbody.innerHTML = '';

        // 获取当前筛选的分组
        const selectedGroup = document.getElementById('user-group-filter')?.value;

        // 筛选用户
        const filteredUsers = users.filter(user => {
            if (!selectedGroup) return true;
            if (selectedGroup === '未分组') {
                return !user.group_id || user.group_id === null || user.group_id === '';
            }
            // 将选中的分组文本转换为group_id进行比较
            const selectedGroupId = this.parseGroupTextToId(selectedGroup);
            return user.group_id === selectedGroupId;
        });

        filteredUsers.forEach(user => {
            const row = document.createElement('tr');
            // 将group_id转换为显示文本
            const userGroup = this.formatGroupIdToText(user.group_id) || '未分组';
            const groupClass = '';

            row.innerHTML = `
                <td>${user.username}</td>
                <td><span class="group-badge ${groupClass}">${userGroup}</span></td>
                <td>${user.group_total_segments || 0}</td>
                <td>${user.completed_annotations}</td>
                <td>${user.completion_rate}%</td>
                <td>${user.avg_play_count}</td>
                <td>
                    <button class="btn btn-primary action-btn" onclick="adminDashboard.showUserDetails('${user.username}')">详情</button>
                    <button class="btn btn-warning action-btn" onclick="adminDashboard.showUserGroupModal('${user.username}', ${user.group_id})">分组</button>
                    ${user.group_id ? `<button class="btn btn-info action-btn" onclick="adminDashboard.showUserSpeakerPermissions('${user.username}')">spk权限</button>` : ''}
                    <button class="btn btn-danger action-btn" onclick="adminDashboard.confirmResetUser('${user.username}')">重置</button>
                    <button class="btn btn-danger action-btn" onclick="adminDashboard.confirmDeleteUser('${user.username}')" style="background-color: #dc3545; margin-left: 5px;">删除</button>
                </td>
            `;
            tbody.appendChild(row);
        });
    }

    /**
     * 显示用户详情
     * @param {string} username - 用户名
     */
    async showUserDetails(username) {
        try {
            const response = await fetch(`/admin/api/users/${username}/details`);
            const data = await response.json();

            if (response.ok) {
                this.displayUserDetails(data);
            } else {
                this.showError('加载用户详情失败: ' + data.error);
            }
        } catch (error) {
            this.showError('网络错误: ' + error.message);
        }
    }

    /**
     * 显示用户详情模态框
     * @param {Object} userDetails - 用户详情数据
     */
    displayUserDetails(userDetails) {
        // 保存用户详情数据供导出使用
        this.currentUserDetails = userDetails;

        document.getElementById('modal-username').textContent = `用户详情 - ${userDetails.username}`;

        const content = document.getElementById('user-detail-content');
        content.innerHTML = `
            <div class="user-summary">
                <h4>基本信息</h4>
                <div class="stats-grid">
                    <div class="stat-item">
                        <span class="status-label">总标注数:</span>
                        <span class="status-value">${userDetails.total_annotations}</span>
                    </div>
                    <div class="stat-item">
                        <span class="status-label">完成数:</span>
                        <span class="status-value">${userDetails.completed_annotations}</span>
                    </div>
                    <div class="stat-item">
                        <span class="status-label">完成率:</span>
                        <span class="status-value">${userDetails.completion_rate}%</span>
                    </div>

                    <div class="stat-item">
                        <span class="status-label">总时长:</span>
                        <span class="status-value">${userDetails.total_duration}秒</span>
                    </div>
                    <div class="stat-item">
                        <span class="status-label">平均播放次数:</span>
                        <span class="status-value">${userDetails.avg_play_count}</span>
                    </div>
                </div>
            </div>
            
            <div class="speakers-stats">
                <h4>按说话人统计</h4>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>说话人</th>
                            <th>标注数</th>
                            <th>完成数</th>
                            <th>总文件数</th>
                            <th>完成率</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${userDetails.speakers_stats.map(speaker => `
                            <tr>
                                <td>${speaker.speaker}</td>
                                <td>${speaker.annotations_count}</td>
                                <td>${speaker.completed_count}</td>
                                <td>${speaker.total_files || 'N/A'}</td>
                                <td>${speaker.completion_rate}%</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
            
            <div class="recent-annotations">
                <h4>最近标注</h4>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>音频文件</th>
                            <th>说话人</th>
                            <th>VA完成</th>
                            <th>离散完成</th>
                            <th>时间</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${userDetails.recent_annotations.map(annotation => `
                            <tr>
                                <td>${annotation.audio_file}</td>
                                <td>${annotation.speaker}</td>
                                <td>${annotation.va_complete ? '✅' : '❌'}</td>
                                <td>${annotation.discrete_complete ? '✅' : '❌'}</td>
                                <td>${annotation.timestamp}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;

        document.getElementById('user-detail-modal').style.display = 'block';
    }

    /**
     * 加载说话人数据
     */
    async loadSpeakersData(groupId = null) {
        try {
            // 取消之前的请求
            if (this.speakersRequest) {
                this.speakersRequest.abort();
            }

            let url = '/admin/api/speakers';
            if (groupId) {
                url += `?group_id=${groupId}`;
            }

            console.log(`加载说话人数据: ${url}`);

            // 创建新的AbortController
            const controller = new AbortController();
            this.speakersRequest = controller;

            const response = await fetch(url, { signal: controller.signal });
            const data = await response.json();

            if (response.ok) {
                console.log(`收到说话人数据，数量: ${data.length}`, data.map(s => s.speaker));
                this.updateSpeakersTable(data);
            } else {
                this.showError('加载说话人数据失败: ' + data.error);
            }
        } catch (error) {
            if (error.name === 'AbortError') {
                console.log('说话人数据请求被取消');
                return;
            }
            this.showError('网络错误: ' + error.message);
        } finally {
            this.speakersRequest = null;
        }
    }

    /**
     * 加载分组列表
     */
    async loadGroupsList() {
        try {
            const response = await fetch('/admin/api/groups');
            const data = await response.json();

            if (response.ok) {
                this.updateGroupsSelect(data.groups || []);
            } else {
                this.showError('加载分组列表失败: ' + data.error);
            }
        } catch (error) {
            this.showError('网络错误: ' + error.message);
        }
    }

    /**
     * 更新分组选择下拉框
     * @param {Array} groups - 分组数据数组
     */
    updateGroupsSelect(groups) {
        const select = document.getElementById('group-filter');
        if (!select) return;

        // 清除现有选项（保留"所有分组"选项）
        while (select.children.length > 1) {
            select.removeChild(select.lastChild);
        }

        groups.forEach(group => {
            const option = document.createElement('option');
            option.value = group.id;
            option.textContent = `分组 ${group.id} (${group.status})`;
            select.appendChild(option);
        });
    }

    /**
     * 处理分组选择变化
     * @param {string} groupId - 选中的分组ID
     */
    async onGroupFilterChange(groupId) {
        const groupSummary = document.getElementById('group-summary');

        if (groupId) {
            // 显示分组详细信息
            if (groupSummary) groupSummary.style.display = 'block';
            await this.loadGroupDetailedStatistics(groupId);
            await this.loadSpeakersData(groupId);
        } else {
            // 隐藏分组详细信息，显示所有说话人
            if (groupSummary) groupSummary.style.display = 'none';
            await this.loadSpeakersData();
        }
    }

    /**
     * 加载分组详细统计信息
     * @param {string} groupId - 分组ID
     */
    async loadGroupDetailedStatistics(groupId) {
        try {
            const response = await fetch(`/admin/api/groups/${groupId}/statistics`);
            const data = await response.json();

            if (response.ok) {
                this.updateGroupSummary(data);
            } else {
                this.showError('加载分组详细统计失败: ' + data.error);
            }
        } catch (error) {
            this.showError('网络错误: ' + error.message);
        }
    }

    /**
     * 更新分组摘要信息
     * @param {Object} groupStats - 分组统计数据
     */
    updateGroupSummary(groupStats) {
        console.log('收到的分组统计数据:', groupStats); // 调试日志

        // 从返回的数据结构中提取信息
        const groupInfo = groupStats.group_info || groupStats;
        const summary = groupStats.summary || {};
        const assignments = groupStats.assignments || [];
        const speakers = groupStats.speakers || [];

        // 更新基本信息
        const basicInfo = document.getElementById('group-basic-info');
        if (basicInfo) {
            basicInfo.innerHTML = `
                <p><strong>分组ID:</strong> ${groupInfo.group_id}</p>
                <p><strong>状态:</strong> ${groupInfo.status}</p>
                <p><strong>总时长:</strong> ${(groupInfo.total_duration / 3600).toFixed(2)} 小时</p>
                <p><strong>总片段数:</strong> ${groupInfo.total_segments}</p>
                <p><strong>说话人数:</strong> ${speakers.length}</p>
            `;
        }

        // 更新用户分配信息
        const userInfo = document.getElementById('group-user-info');
        if (userInfo) {
            userInfo.innerHTML = `
                <p><strong>总分配用户:</strong> ${summary.total_users || 0}</p>
                <p><strong>完成用户:</strong> ${summary.completed_users || 0}</p>
                <p><strong>进行中用户:</strong> ${summary.in_progress_users || 0}</p>
                <p><strong>用户完成率:</strong> ${summary.total_users > 0 ? ((summary.completed_users / summary.total_users) * 100).toFixed(1) : 0}%</p>
            `;
        }

        // 更新进度信息
        const progressInfo = document.getElementById('group-progress-info');
        if (progressInfo) {
            const overallCompletionRate = summary.overall_completion_rate || 0;
            const totalAssignedSegments = summary.total_assigned_segments || 0;
            const totalCompletedSegments = summary.total_completed_segments || 0;

            progressInfo.innerHTML = `
                <p><strong>整体完成率:</strong> ${overallCompletionRate}%</p>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: ${overallCompletionRate}%"></div>
                </div>
                <p><strong>总段数:</strong> ${groupInfo.total_segments}</p>
                <p><strong>已分配段数:</strong> ${totalAssignedSegments}</p>
                <p><strong>已完成段数:</strong> ${totalCompletedSegments}</p>
                <p><strong>未分配段数:</strong> ${groupInfo.total_segments - totalAssignedSegments}</p>
            `;
        }

        // 如果有说话人信息，显示说话人列表
        if (speakers && speakers.length > 0 && basicInfo) {
            const speakersList = speakers.map(speaker =>
                `${speaker.speaker_id} (${(speaker.duration / 60).toFixed(1)}分钟, ${speaker.segment_count}片段)`
            ).join(', ');
            basicInfo.innerHTML += `<p><strong>包含说话人:</strong> ${speakersList}</p>`;
        }
    }

    /**
     * 更新说话人表格
     * @param {Array} speakers - 说话人数据数组
     */
    updateSpeakersTable(speakers) {
        console.log('更新说话人表格，数据:', speakers.map(s => s.speaker));

        const tbody = document.querySelector('#speakers-table tbody');
        if (!tbody) {
            console.error('找不到说话人表格tbody元素');
            return;
        }

        tbody.innerHTML = '';

        speakers.forEach(speaker => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${speaker.speaker}</td>
                <td>${speaker.total_files}</td>
                <td>${speaker.completed_files}</td>
                <td>${speaker.completion_rate}%</td>
            `;
            tbody.appendChild(row);
        });

        console.log(`表格更新完成，共${speakers.length}行`);
    }

    /**
     * 加载质量数据
     * @param {number|null} groupId - 分组ID，null表示加载全局数据
     */
    async loadQualityData(groupId = null) {
        try {
            const url = groupId ? `/admin/api/quality?group_id=${groupId}` : '/admin/api/quality';
            const response = await fetch(url);
            const data = await response.json();

            if (response.ok) {
                this.updateQualityCharts(data.data, groupId);
            } else {
                this.showError('加载质量数据失败: ' + data.error);
            }
        } catch (error) {
            this.showError('网络错误: ' + error.message);
        }
    }

    /**
     * 更新质量图表
     * @param {Object} data - 质量数据
     * @param {number|null} groupId - 分组ID
     */
    updateQualityCharts(data, groupId = null) {
        if (groupId) {
            // 显示分组数据图表
            document.getElementById('group-quality-charts').style.display = 'block';
            document.getElementById('global-quality-charts').style.display = 'none';
            this.updateGroupQualityCharts(data);
        } else {
            // 显示全局数据图表
            document.getElementById('group-quality-charts').style.display = 'none';
            document.getElementById('global-quality-charts').style.display = 'block';
            this.updateGlobalQualityCharts(data);
        }
    }

    /**
     * 更新分组质量图表（直方图）
     * @param {Object} data - 分组质量数据
     */
    updateGroupQualityCharts(data) {
        const colors = ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40', '#C9CBCF'];

        // A值分布直方图
        if (data.a_value_distribution) {
            const aValueCtx = document.getElementById('a-value-chart').getContext('2d');
            if (this.charts.aValue) {
                this.charts.aValue.destroy();
            }

            // 处理A值分布数据结构
            const aValueData = this.processValueDistribution(data.a_value_distribution, [
                '1.0', '1.5', '2.0', '2.5', '3.0', '3.5', '4.0', '4.5'
            ]);

            this.charts.aValue = new Chart(aValueCtx, {
                type: 'bar',
                data: {
                    labels: aValueData.labels,
                    datasets: aValueData.datasets
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                precision: 0,
                                maxTicksLimit: 10
                            }
                        }
                    },
                    plugins: {
                        title: {
                            display: true,
                            text: 'A值分布（按用户）'
                        },
                        legend: {
                            display: true,
                            position: 'top'
                        }
                    }
                }
            });
        }

        // V值分布直方图
        if (data.v_value_distribution) {
            const vValueCtx = document.getElementById('v-value-chart').getContext('2d');
            if (this.charts.vValue) {
                this.charts.vValue.destroy();
            }

            // 处理V值分布数据结构
            const vValueData = this.processValueDistribution(data.v_value_distribution, [
                '-2.0', '-1.5', '-1.0', '-0.5', '0.0', '0.5', '1.0', '1.5'
            ]);

            this.charts.vValue = new Chart(vValueCtx, {
                type: 'bar',
                data: {
                    labels: vValueData.labels,
                    datasets: vValueData.datasets
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                precision: 0,
                                maxTicksLimit: 10
                            }
                        }
                    },
                    plugins: {
                        title: {
                            display: true,
                            text: 'V值分布（按用户）'
                        },
                        legend: {
                            display: true,
                            position: 'top'
                        }
                    }
                }
            });
        }

        // 离散情感分布直方图（按用户）
        if (data.discrete_emotion_distribution) {
            const discreteEmotionUserCtx = document.getElementById('discrete-emotion-user-chart').getContext('2d');
            if (this.charts.discreteEmotionUser) {
                this.charts.discreteEmotionUser.destroy();
            }

            // 处理离散情感分布数据
            const discreteData = this.processDiscreteEmotionDistribution(data.discrete_emotion_distribution);

            this.charts.discreteEmotionUser = new Chart(discreteEmotionUserCtx, {
                type: 'bar',
                data: {
                    labels: discreteData.labels,
                    datasets: discreteData.datasets
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                precision: 0,
                                maxTicksLimit: 10
                            }
                        }
                    },
                    plugins: {
                        title: {
                            display: true,
                            text: '离散情感分布（按用户）'
                        },
                        legend: {
                            display: true,
                            position: 'top'
                        }
                    }
                }
            });
        }
    }

    /**
     * 更新全局质量图表
     * @param {Object} data - 全局质量数据
     */
    updateGlobalQualityCharts(data) {
        // 全局A值分布直方图（按用户分组）
        if (data.a_value_distribution) {
            const globalAValueCtx = document.getElementById('global-a-value-chart').getContext('2d');
            if (this.charts.globalAValue) {
                this.charts.globalAValue.destroy();
            }

            const aValueData = this.processValueDistribution(data.a_value_distribution, [
                '1.0', '1.5', '2.0', '2.5', '3.0', '3.5', '4.0', '4.5'
            ]);

            this.charts.globalAValue = new Chart(globalAValueCtx, {
                type: 'bar',
                data: {
                    labels: aValueData.labels,
                    datasets: aValueData.datasets
                },
                options: {
                    responsive: true,
                    plugins: {
                        title: {
                            display: true,
                            text: 'A值分布（按标注人）'
                        },
                        legend: {
                            display: true,
                            position: 'top'
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                precision: 0,
                                maxTicksLimit: 10
                            }
                        }
                    }
                }
            });
        }

        // 全局V值分布直方图（按用户分组）
        if (data.v_value_distribution) {
            const globalVValueCtx = document.getElementById('global-v-value-chart').getContext('2d');
            if (this.charts.globalVValue) {
                this.charts.globalVValue.destroy();
            }

            const vValueData = this.processValueDistribution(data.v_value_distribution, [
                '-2.0', '-1.5', '-1.0', '-0.5', '0.0', '0.5', '1.0', '1.5'
            ]);

            this.charts.globalVValue = new Chart(globalVValueCtx, {
                type: 'bar',
                data: {
                    labels: vValueData.labels,
                    datasets: vValueData.datasets
                },
                options: {
                    responsive: true,
                    plugins: {
                        title: {
                            display: true,
                            text: 'V值分布（按标注人）'
                        },
                        legend: {
                            display: true,
                            position: 'top'
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                precision: 0,
                                maxTicksLimit: 10
                            }
                        }
                    }
                }
            });
        }

        // 离散情感分布（按用户分组）
        if (data.discrete_emotion_distribution) {
            const discreteEmotionCtx = document.getElementById('discrete-emotion-chart').getContext('2d');
            if (this.charts.discreteEmotion) {
                this.charts.discreteEmotion.destroy();
            }

            const discreteData = this.processDiscreteEmotionDistribution(data.discrete_emotion_distribution);

            this.charts.discreteEmotion = new Chart(discreteEmotionCtx, {
                type: 'bar',
                data: {
                    labels: discreteData.labels,
                    datasets: discreteData.datasets
                },
                options: {
                    responsive: true,
                    plugins: {
                        title: {
                            display: true,
                            text: '离散情感分布（按标注人）'
                        },
                        legend: {
                            display: true,
                            position: 'top'
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                precision: 0,
                                maxTicksLimit: 10
                            }
                        }
                    }
                }
            });
        }
    }

    /**
     * 加载质量分析分组列表
     */
    async loadQualityGroupsList() {
        try {
            const response = await fetch('/admin/api/groups');
            const data = await response.json();

            if (response.ok) {
                this.updateQualityGroupFilter(data.groups);
            } else {
                console.error('加载分组列表失败:', data.error);
            }
        } catch (error) {
            console.error('网络错误:', error.message);
        }
    }

    /**
     * 更新质量分析分组过滤器
     * @param {Array} groups - 分组列表
     */
    updateQualityGroupFilter(groups) {
        const select = document.getElementById('quality-group-filter');
        if (!select) return;

        // 清空现有选项（保留"所有数据"选项）
        select.innerHTML = '<option value="">所有数据</option>';

        // 添加分组选项
        groups.forEach(group => {
            const option = document.createElement('option');
            option.value = group.id;
            option.textContent = group.name;
            select.appendChild(option);
        });
    }

    /**
     * 处理质量分析分组过滤器变化
     * @param {string} groupId - 选中的分组ID
     */
    onQualityGroupFilterChange(groupId) {
        const selectedGroupId = groupId ? parseInt(groupId) : null;
        this.loadQualityData(selectedGroupId);
    }

    /**
     * 导出数据
     */
    async exportData() {
        const format = document.getElementById('export-format').value;
        const username = document.getElementById('export-username').value;
        const speaker = document.getElementById('export-speaker').value;

        const params = new URLSearchParams({ format });
        if (username) params.append('username', username);
        if (speaker) params.append('speaker', speaker);

        try {
            const response = await fetch(`/admin/api/export?${params}`);
            const data = await response.json();

            if (response.ok) {
                this.showSuccess(`导出成功！文件: ${data.filename}，记录数: ${data.record_count}`);
            } else {
                this.showError('导出失败: ' + data.error);
            }
        } catch (error) {
            this.showError('网络错误: ' + error.message);
        }
    }

    /**
     * 直接下载数据
     */
    async downloadData() {
        const format = document.getElementById('export-format').value;
        const username = document.getElementById('export-username').value;
        const speaker = document.getElementById('export-speaker').value;

        const params = new URLSearchParams({ format });
        if (username) params.append('username', username);
        if (speaker) params.append('speaker', speaker);

        try {
            // 创建一个隐藏的链接来触发下载
            const downloadUrl = `/admin/api/export/download?${params}`;
            const link = document.createElement('a');
            link.href = downloadUrl;
            link.style.display = 'none';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);

            this.showSuccess('文件下载已开始');
        } catch (error) {
            this.showError('下载失败: ' + error.message);
        }
    }

    /**
     * 备份数据库
     */
    async backupDatabase() {
        try {
            const response = await fetch('/admin/api/backup', { method: 'POST' });
            const data = await response.json();

            if (response.ok) {
                this.showSuccess(`备份成功！文件: ${data.backup_filename}`);
            } else {
                this.showError('备份失败: ' + data.error);
            }
        } catch (error) {
            this.showError('网络错误: ' + error.message);
        }
    }

    /**
     * 确认重置用户
     * @param {string} username - 用户名
     */
    confirmResetUser(username) {
        document.getElementById('confirm-message').textContent = `确定要重置用户 "${username}" 的所有标注数据吗？此操作不可恢复！`;

        document.getElementById('confirm-yes').onclick = () => {
            this.resetUser(username);
            document.getElementById('confirm-modal').style.display = 'none';
        };

        document.getElementById('confirm-no').onclick = () => {
            document.getElementById('confirm-modal').style.display = 'none';
        };

        document.getElementById('confirm-modal').style.display = 'block';
    }

    /**
     * 重置用户数据
     * @param {string} username - 用户名
     */
    async resetUser(username) {
        try {
            const response = await fetch(`/admin/api/users/${username}/reset`, { method: 'POST' });
            const data = await response.json();

            if (response.ok) {
                this.showSuccess(`重置成功！删除了 ${data.deleted_records} 条记录`);
                this.loadUsersData(); // 刷新用户列表
            } else {
                this.showError('重置失败: ' + data.error);
            }
        } catch (error) {
            this.showError('网络错误: ' + error.message);
        }
    }

    /**
     * 确认删除用户
     * @param {string} username - 用户名
     */
    confirmDeleteUser(username) {
        document.getElementById('confirm-message').textContent = `确定要删除用户 "${username}" 及其所有数据吗？此操作不可恢复！`;

        document.getElementById('confirm-yes').onclick = () => {
            this.deleteUser(username);
            document.getElementById('confirm-modal').style.display = 'none';
        };

        document.getElementById('confirm-no').onclick = () => {
            document.getElementById('confirm-modal').style.display = 'none';
        };

        document.getElementById('confirm-modal').style.display = 'block';
    }

    /**
     * 删除用户数据
     * @param {string} username - 用户名
     */
    async deleteUser(username) {
        try {
            const response = await fetch(`/admin/api/users/${username}`, { method: 'DELETE' });
            const data = await response.json();

            if (response.ok) {
                this.showSuccess(`删除成功！用户 ${username} 及其所有数据已被删除`);
                this.loadUsersData(); // 刷新用户列表
            } else {
                this.showError('删除失败: ' + data.error);
            }
        } catch (error) {
            this.showError('网络错误: ' + error.message);
        }
    }

    /**
     * 加载系统状态
     */
    async loadSystemStatus() {
        try {
            const response = await fetch('/admin/api/system/status');
            const data = await response.json();

            if (response.ok) {
                this.updateSystemStatus(data);
            } else {
                this.showError('加载系统状态失败: ' + data.error);
            }
        } catch (error) {
            this.showError('网络错误: ' + error.message);
        }
    }

    /**
     * 更新系统状态显示
     * @param {Object} data - 系统状态数据
     */
    updateSystemStatus(data) {
        // 数据库状态
        const dbStatus = document.getElementById('database-status');
        dbStatus.innerHTML = `
            <div class="status-item">
                <span class="status-label">数据库存在:</span>
                <span class="status-value ${data.database.exists ? 'status-good' : 'status-error'}">
                    ${data.database.exists ? '✅ 是' : '❌ 否'}
                </span>
            </div>
            <div class="status-item">
                <span class="status-label">数据库可访问:</span>
                <span class="status-value ${data.database.accessible ? 'status-good' : 'status-error'}">
                    ${data.database.accessible ? '✅ 是' : '❌ 否'}
                </span>
            </div>
            <div class="status-item">
                <span class="status-label">数据库大小:</span>
                <span class="status-value">${data.database.size_mb} MB</span>
            </div>
            <div class="status-item">
                <span class="status-label">总记录数:</span>
                <span class="status-value">${data.database.total_records}</span>
            </div>
        `;

        // 音频文件夹状态
        const audioStatus = document.getElementById('audio-folder-status');
        audioStatus.innerHTML = `
            <div class="status-item">
                <span class="status-label">文件夹存在:</span>
                <span class="status-value ${data.audio_folder.exists ? 'status-good' : 'status-error'}">
                    ${data.audio_folder.exists ? '✅ 是' : '❌ 否'}
                </span>
            </div>
            <div class="status-item">
                <span class="status-label">路径:</span>
                <span class="status-value">${data.audio_folder.path}</span>
            </div>
        `;

        // 磁盘空间状态
        const diskStatus = document.getElementById('disk-space-status');
        const usageClass = data.disk_space.usage_percent > 90 ? 'status-error' :
            data.disk_space.usage_percent > 80 ? 'status-warning' : 'status-good';

        diskStatus.innerHTML = `
            <div class="status-item">
                <span class="status-label">总空间:</span>
                <span class="status-value">${data.disk_space.total_gb} GB</span>
            </div>
            <div class="status-item">
                <span class="status-label">已使用:</span>
                <span class="status-value">${data.disk_space.used_gb} GB</span>
            </div>
            <div class="status-item">
                <span class="status-label">可用空间:</span>
                <span class="status-value">${data.disk_space.free_gb} GB</span>
            </div>
            <div class="status-item">
                <span class="status-label">使用率:</span>
                <span class="status-value ${usageClass}">${data.disk_space.usage_percent}%</span>
            </div>
        `;
    }

    /**
     * 登出
     */
    async logout() {
        try {
            console.log('开始执行登出操作');
            const response = await fetch('/admin/logout', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                credentials: 'same-origin'
            });

            console.log('登出响应状态:', response.status);

            if (response.ok) {
                const data = await response.json();
                console.log('登出响应数据:', data);
                // 清除本地存储的管理员信息
                sessionStorage.clear();
                localStorage.clear();
                // 跳转到登录页面
                window.location.href = '/admin/login';
            } else {
                const errorData = await response.json();
                console.error('登出失败:', errorData);
                this.showError('登出失败: ' + (errorData.error || errorData.message || '未知错误'));
            }
        } catch (error) {
            console.error('登出异常:', error);
            // 即使出现网络错误，也尝试清除本地数据并跳转
            sessionStorage.clear();
            localStorage.clear();
            this.showError('网络错误，正在跳转到登录页面...');
            setTimeout(() => {
                window.location.href = '/admin/login';
            }, 1000);
        }
    }

    /**
     * 显示成功消息
     * @param {string} message - 消息内容
     */
    showSuccess(message) {
        // 创建或获取消息显示元素
        let resultDiv = document.getElementById('message-result');
        if (!resultDiv) {
            resultDiv = document.createElement('div');
            resultDiv.id = 'message-result';
            resultDiv.className = 'result-message';
            resultDiv.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 15px 20px;
                border-radius: 5px;
                color: white;
                font-weight: bold;
                z-index: 10000;
                max-width: 400px;
                word-wrap: break-word;
            `;
            document.body.appendChild(resultDiv);
        }

        resultDiv.className = 'result-message success';
        resultDiv.style.backgroundColor = '#28a745';
        resultDiv.textContent = message;
        resultDiv.style.display = 'block';

        setTimeout(() => {
            resultDiv.style.display = 'none';
        }, 5000);
    }

    /**
     * 显示错误消息
     * @param {string} message - 错误消息
     */
    showError(message) {
        // 创建或获取消息显示元素
        let resultDiv = document.getElementById('message-result');
        if (!resultDiv) {
            resultDiv = document.createElement('div');
            resultDiv.id = 'message-result';
            resultDiv.className = 'result-message';
            resultDiv.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 15px 20px;
                border-radius: 5px;
                color: white;
                font-weight: bold;
                z-index: 10000;
                max-width: 400px;
                word-wrap: break-word;
            `;
            document.body.appendChild(resultDiv);
        }

        resultDiv.className = 'result-message error';
        resultDiv.style.backgroundColor = '#dc3545';
        resultDiv.textContent = message;
        resultDiv.style.display = 'block';

        setTimeout(() => {
            resultDiv.style.display = 'none';
        }, 5000);
    }

    /**
     * 加载一致性分析数据
     */
    async loadConsistencyData() {
        try {
            // 加载第一次一致性测试用户列表
            const firstUsersResponse = await fetch('/admin/api/consistency/users');
            const firstUsersData = await firstUsersResponse.json();

            if (firstUsersResponse.ok) {
                this.updateFirstConsistencyUserSelect(firstUsersData.users);
            } else {
                // 处理第一次一致性用户列表加载错误
                if (firstUsersData.error && firstUsersData.error.includes('SQLite3 模块不可用')) {
                    this.showError(`数据库连接失败: ${firstUsersData.error}\n${firstUsersData.details || ''}\n${firstUsersData.solution || ''}`);
                } else {
                    this.showError('加载第一次一致性用户列表失败: ' + (firstUsersData.error || '未知错误'));
                }
            }

            // 加载第二次一致性测试用户列表
            const secondUsersResponse = await fetch('/admin/api/second-consistency/users');
            const secondUsersData = await secondUsersResponse.json();

            if (secondUsersResponse.ok) {
                this.updateSecondConsistencyUserSelect(secondUsersData.users);
            } else {
                // 处理第二次一致性用户列表加载错误
                if (secondUsersData.error && secondUsersData.error.includes('SQLite3 模块不可用')) {
                    this.showError(`数据库连接失败: ${secondUsersData.error}\n${secondUsersData.details || ''}\n${secondUsersData.solution || ''}`);
                } else {
                    this.showError('加载第二次一致性用户列表失败: ' + (secondUsersData.error || '未知错误'));
                }
            }
        } catch (error) {
            this.showError('加载一致性数据失败: ' + error.message);
        }
    }



    /**
     * 更新第一次一致性测试用户选择下拉框
     * @param {Array} users - 用户列表
     */
    updateFirstConsistencyUserSelect(users) {
        const firstSelect = document.getElementById('first-consistency-user-select');
        if (firstSelect) {
            firstSelect.innerHTML = '<option value="">-- 请选择用户 --</option>';
            users.forEach(user => {
                const option = document.createElement('option');
                option.value = user;
                option.textContent = user;
                firstSelect.appendChild(option);
            });
        }
    }

    /**
     * 更新第二次一致性测试用户选择下拉框
     * @param {Array} users - 用户列表
     */
    updateSecondConsistencyUserSelect(users) {
        const secondSelect = document.getElementById('second-consistency-user-select');
        if (secondSelect) {
            secondSelect.innerHTML = '<option value="">-- 请选择用户 --</option>';
            users.forEach(user => {
                const option = document.createElement('option');
                option.value = user;
                option.textContent = user;
                secondSelect.appendChild(option);
            });
        }
    }

    /**
     * 计算用户第一次一致性
     */
    async calculateFirstConsistency() {
        console.log('calculateFirstConsistency 方法被调用');
        const username = document.getElementById('first-consistency-user-select').value;
        console.log('选中的用户名:', username);

        if (!username) {
            console.log('未选择用户，显示错误信息');
            this.showError('请先选择用户');
            return;
        }

        try {
            console.log('开始发送请求到:', `/admin/api/consistency/calculate/${username}`);
            const response = await fetch(`/admin/api/consistency/calculate/${username}`);
            console.log('响应状态:', response.status);
            const data = await response.json();
            console.log('响应数据:', data);

            if (response.ok) {
                if (data.success && data.consistency_analysis) {
                    // 转换数据格式以匹配前端期望的结构
                    const consistencyData = {
                        username: data.username,
                        total_samples: data.consistency_analysis.total_samples,
                        overall_consistency: data.consistency_analysis.overall_consistency, // 保持原始数值
                        v_consistency: data.consistency_analysis.v_consistency, // 保持原始数值
                        a_consistency: data.consistency_analysis.a_consistency, // 保持原始数值
                        discrete_consistency: data.consistency_analysis.discrete_consistency, // 保持原始数值
                        detailed_results: data.consistency_analysis.detailed_results
                    };
                    this.displayConsistencyReport(consistencyData, '第一次一致性');
                } else {
                    this.showError('计算第一次一致性失败: ' + (data.error || '未知错误'));
                }
            } else {
                // 处理详细的错误信息
                if (data.error && data.error.includes('SQLite3 模块不可用')) {
                    this.showError(`数据库连接失败: ${data.error}\n${data.details || ''}\n${data.solution || ''}`);
                } else {
                    this.showError('计算第一次一致性失败: ' + (data.error || '未知错误'));
                }
            }
        } catch (error) {
            console.error('网络错误:', error);
            this.showError('网络错误: ' + error.message);
        }
    }

    /**
     * 计算用户第二次一致性
     */
    async calculateSecondConsistency() {
        console.log('calculateSecondConsistency 方法被调用');
        const username = document.getElementById('second-consistency-user-select').value;
        console.log('选中的用户名:', username);

        if (!username) {
            console.log('未选择用户，显示错误信息');
            this.showError('请先选择用户');
            return;
        }

        try {
            console.log('开始发送请求到:', `/admin/api/second-consistency/calculate/${username}`);
            const response = await fetch(`/admin/api/second-consistency/calculate/${username}`);
            console.log('响应状态:', response.status);
            const data = await response.json();
            console.log('响应数据:', data);

            if (response.ok) {
                if (data.success && data.consistency_analysis) {
                    // 转换数据格式以匹配前端期望的结构
                    const consistencyData = {
                        username: data.username,
                        total_samples: data.consistency_analysis.total_samples,
                        overall_consistency: data.consistency_analysis.overall_consistency, // 保持原始数值
                        v_consistency: data.consistency_analysis.v_consistency, // 保持原始数值
                        a_consistency: data.consistency_analysis.a_consistency, // 保持原始数值
                        discrete_consistency: data.consistency_analysis.discrete_consistency, // 保持原始数值
                        detailed_results: data.consistency_analysis.detailed_results
                    };
                    this.displaySecondConsistencyReport(consistencyData, '第二次一致性');
                } else {
                    this.showError('计算第二次一致性失败: ' + (data.error || '未知错误'));
                }
            } else {
                // 处理详细的错误信息
                if (data.error && data.error.includes('SQLite3 模块不可用')) {
                    this.showError(`数据库连接失败: ${data.error}\n${data.details || ''}\n${data.solution || ''}`);
                } else {
                    this.showError('计算第二次一致性失败: ' + (data.error || '未知错误'));
                }
            }
        } catch (error) {
            console.error('网络错误:', error);
            this.showError('网络错误: ' + error.message);
        }
    }

    /**
     * 显示一致性报告
     * @param {Object} data - 一致性数据
     * @param {string} testType - 测试类型
     */
    displayConsistencyReport(data, testType = '一致性') {
        const reportDiv = document.getElementById('consistency-results');

        // 安全地获取数值并转换为百分比
        const overall_consistency_percent = (data.overall_consistency * 100).toFixed(2);
        const v_consistency_percent = (data.v_consistency * 100).toFixed(2);
        const a_consistency_percent = (data.a_consistency * 100).toFixed(2);
        const discrete_consistency_percent = (data.discrete_consistency * 100).toFixed(2);

        reportDiv.innerHTML = `
            <h4>用户 ${data.username} 的${testType}分析报告</h4>
            <div class="consistency-summary">
                <p><strong>总样本数:</strong> ${data.total_samples}</p>
                <p><strong>总体一致性:</strong> ${overall_consistency_percent}%</p>
            </div>
            
            <div class="consistency-details">
                <h5>各维度一致性:</h5>
                <table class="consistency-table">
                    <thead>
                        <tr>
                            <th>维度</th>
                            <th>一致性</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>V值 (效价)</td>
                            <td>${v_consistency_percent}%</td>
                        </tr>
                        <tr>
                            <td>A值 (唤醒度)</td>
                            <td>${a_consistency_percent}%</td>
                        </tr>
                        <tr>
                            <td>离散情感</td>
                            <td>${discrete_consistency_percent}%</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        `;

        // 存储详细结果用于导出
        this.currentConsistencyData = data;

        reportDiv.style.display = 'block';
    }

    /**
     * 显示第二次一致性报告
     * @param {Object} data - 一致性数据
     * @param {string} testType - 测试类型
     */
    displaySecondConsistencyReport(data, testType = '第二次一致性') {
        const reportDiv = document.getElementById('consistency-results');

        // 将一致性数据转换为百分比格式，与第一次一致性测试保持一致
        const v_consistency_percent = (data.v_consistency * 100).toFixed(2);
        const a_consistency_percent = (data.a_consistency * 100).toFixed(2);
        const discrete_consistency_percent = (data.discrete_consistency * 100).toFixed(2);
        const overall_consistency_percent = (data.overall_consistency * 100).toFixed(2);

        reportDiv.innerHTML = `
            <h4>用户 ${data.username} 的${testType}分析报告</h4>
            <div class="consistency-summary">
                <p><strong>总样本数:</strong> ${data.total_samples}</p>
                <p><strong>总体一致性:</strong> ${overall_consistency_percent}%</p>
            </div>
            
            <div class="consistency-details">
                <h5>各维度一致性:</h5>
                <table class="consistency-table">
                    <thead>
                        <tr>
                            <th>维度</th>
                            <th>一致性</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>V值 (效价)</td>
                            <td>${v_consistency_percent}%</td>
                        </tr>
                        <tr>
                            <td>A值 (唤醒度)</td>
                            <td>${a_consistency_percent}%</td>
                        </tr>
                        <tr>
                            <td>离散情感</td>
                            <td>${discrete_consistency_percent}%</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        `;

        // 存储详细结果用于导出
        this.currentSecondConsistencyData = data;

        reportDiv.style.display = 'block';
    }

    /**
     * 导出一致性报告
     */
    exportConsistencyReport() {
        if (!this.currentConsistencyData) {
            this.showError('请先计算一致性分析');
            return;
        }

        const data = this.currentConsistencyData;
        let csvContent = "音频文件,V值分数,A值分数,离散情感分数,用户V值,用户A值,用户离散情感,标准V值,标准A值,标准离散情感\n";

        data.detailed_results.forEach(result => {
            csvContent += [
                result.audio_file,
                result.v_score,
                result.a_score,
                result.discrete_score,
                result.user_v !== null && result.user_v !== undefined ? result.user_v : '',
                result.user_a !== null && result.user_a !== undefined ? result.user_a : '',
                result.user_discrete || '',
                result.standard_v !== null && result.standard_v !== undefined ? result.standard_v : '',
                result.standard_a !== null && result.standard_a !== undefined ? result.standard_a : '',
                result.standard_discrete || ''
            ].join(',') + '\n';
        });

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', `consistency_report_${data.username}_${new Date().toISOString().split('T')[0]}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);

        this.showSuccess('一致性报告已导出');
    }

    /**
     * 生成详细一致性报告
     */
    generateDetailedConsistencyReport() {
        if (!this.currentConsistencyData) {
            this.showError('请先计算一致性分析');
            return;
        }

        const data = this.currentConsistencyData;
        const reportDiv = document.getElementById('detailed-consistency-report');

        let reportHtml = `
            <div class="detailed-report-content">
                <h4>用户 ${data.username} 的详细一致性报告</h4>
                <div class="report-summary">
                    <p><strong>报告生成时间:</strong> ${new Date().toLocaleString()}</p>
                    <p><strong>总样本数:</strong> ${data.total_samples}</p>
                    <p><strong>总体一致性:</strong> ${data.overall_consistency.toFixed(2)}%</p>
                </div>
                
                <div class="detailed-results">
                    <h5>详细结果列表</h5>
                    <table class="detailed-results-table">
                        <thead>
                            <tr>
                                <th>音频文件</th>
                                <th>V值一致</th>
                                <th>A值一致</th>
                                <th>离散情感一致</th>
                                <th>用户标注</th>
                                <th>标准答案</th>
                            </tr>
                        </thead>
                        <tbody>
        `;

        data.detailed_results.forEach(result => {
            reportHtml += `
                <tr class="${result.v_consistent && result.a_consistent && result.discrete_consistent ? 'consistent-row' : 'inconsistent-row'}">
                    <td>${result.audio_file}</td>
                    <td class="${result.v_consistent ? 'consistent' : 'inconsistent'}">${result.v_consistent ? '✓' : '✗'}</td>
                    <td class="${result.a_consistent ? 'consistent' : 'inconsistent'}">${result.a_consistent ? '✓' : '✗'}</td>
                    <td class="${result.discrete_consistent ? 'consistent' : 'inconsistent'}">${result.discrete_consistent ? '✓' : '✗'}</td>
                    <td>
                        V: ${result.user_v !== null && result.user_v !== undefined ? result.user_v : 'N/A'}<br>
                        A: ${result.user_a !== null && result.user_a !== undefined ? result.user_a : 'N/A'}<br>
                        离散: ${result.user_discrete || 'N/A'}
                    </td>
                    <td>
                        V: ${result.standard_v !== null && result.standard_v !== undefined ? result.standard_v : 'N/A'}<br>
                        A: ${result.standard_a !== null && result.standard_a !== undefined ? result.standard_a : 'N/A'}<br>
                        离散: ${result.standard_discrete || 'N/A'}
                    </td>
                </tr>
            `;
        });

        reportHtml += `
                        </tbody>
                    </table>
                </div>
                
                <div class="export-options">
                    <button class="btn btn-primary" onclick="adminDashboard.exportConsistencyAsCSV()">导出为CSV</button>
                    <button class="btn btn-primary" onclick="adminDashboard.exportConsistencyAsJSON()">导出为JSON</button>
                </div>
            </div>
        `;

        reportDiv.innerHTML = reportHtml;
        reportDiv.style.display = 'block';

        this.showSuccess('详细报告已生成');
    }

    /**
     * 显示导出选项
     */
    showExportOptions() {
        if (!this.currentConsistencyData) {
            this.showError('请先计算一致性分析');
            return;
        }

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'block';
        modal.innerHTML = `
            <div class="modal-content">
                <span class="close">&times;</span>
                <h3>选择导出格式</h3>
                <div class="export-options">
                    <button class="btn btn-primary" onclick="adminDashboard.exportConsistencyAsCSV(); this.closest('.modal').remove();">导出为CSV</button>
                    <button class="btn btn-primary" onclick="adminDashboard.exportConsistencyAsJSON(); this.closest('.modal').remove();">导出为JSON</button>
                </div>
            </div>
        `;

        document.body.appendChild(modal);

        // 关闭模态框
        modal.querySelector('.close').addEventListener('click', () => {
            modal.remove();
        });

        // 点击背景关闭
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });
    }

    /**
     * 导出一致性数据为CSV格式
     */
    exportConsistencyAsCSV() {
        if (!this.currentConsistencyData) {
            this.showError('请先计算一致性分析');
            return;
        }

        const data = this.currentConsistencyData;
        let csvContent = "音频文件,V值一致,A值一致,离散情感一致,用户V值,用户A值,用户离散情感,标准V值,标准A值,标准离散情感\n";

        data.detailed_results.forEach(result => {
            csvContent += [
                result.audio_file,
                result.v_consistent ? '是' : '否',
                result.a_consistent ? '是' : '否',
                result.discrete_consistent ? '是' : '否',
                result.user_v !== null && result.user_v !== undefined ? result.user_v : '',
                result.user_a !== null && result.user_a !== undefined ? result.user_a : '',
                result.user_discrete || '',
                result.standard_v !== null && result.standard_v !== undefined ? result.standard_v : '',
                result.standard_a !== null && result.standard_a !== undefined ? result.standard_a : '',
                result.standard_discrete || ''
            ].join(',') + '\n';
        });

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', `consistency_report_${data.username}_${new Date().toISOString().split('T')[0]}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);

        this.showSuccess('CSV报告已导出');
    }

    /**
     * 导出一致性数据为JSON格式
     */
    exportConsistencyAsJSON() {
        if (!this.currentConsistencyData) {
            this.showError('请先计算一致性分析');
            return;
        }

        const data = this.currentConsistencyData;
        const exportData = {
            username: data.username,
            export_time: new Date().toISOString(),
            total_samples: data.total_samples,
            overall_consistency: data.overall_consistency,
            v_accuracy: data.v_accuracy,
            a_accuracy: data.a_accuracy,
            discrete_accuracy: data.discrete_accuracy,
            detailed_results: data.detailed_results
        };

        const jsonContent = JSON.stringify(exportData, null, 2);
        const blob = new Blob([jsonContent], { type: 'application/json;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', `consistency_report_${data.username}_${new Date().toISOString().split('T')[0]}.json`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);

        this.showSuccess('JSON报告已导出');
    }

    /**
     * 导出整个consistency_test_results表的数据为xlsx格式
     */
    async exportAllConsistencyResults() {
        try {
            this.showSuccess('正在导出全部一致性测试结果，请稍候...');

            const response = await fetch('/admin/api/export/consistency-results');

            if (response.ok) {
                // 获取文件名
                const contentDisposition = response.headers.get('Content-Disposition');
                let filename = 'consistency_test_results.xlsx';
                if (contentDisposition) {
                    const filenameMatch = contentDisposition.match(/filename="?([^"]+)"?/);
                    if (filenameMatch) {
                        filename = filenameMatch[1];
                    }
                }

                // 创建下载链接
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.download = filename;
                link.style.display = 'none';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                window.URL.revokeObjectURL(url);

                this.showSuccess('全部一致性测试结果已成功导出为Excel文件');
            } else {
                const errorData = await response.json();
                this.showError('导出失败: ' + (errorData.error || '未知错误'));
            }
        } catch (error) {
            this.showError('导出失败: ' + error.message);
        }
    }

    /**
     * 生成详细第二次一致性报告
     */
    generateDetailedSecondConsistencyReport() {
        if (!this.currentSecondConsistencyData) {
            this.showError('请先计算第二次一致性分析');
            return;
        }

        const data = this.currentSecondConsistencyData;
        const reportDiv = document.getElementById('detailed-second-consistency-report');

        let reportHtml = `
            <div class="detailed-report-content">
                <h4>用户 ${data.username} 的详细第二次一致性报告</h4>
                <div class="report-summary">
                    <p><strong>报告生成时间:</strong> ${new Date().toLocaleString()}</p>
                    <p><strong>总样本数:</strong> ${data.total_samples}</p>
                    <p><strong>总体一致性:</strong> ${(data.overall_consistency * 100).toFixed(2)}%</p>
                </div>
                
                <div class="detailed-results">
                    <h5>详细结果列表</h5>
                    <table class="detailed-results-table">
                        <thead>
                            <tr>
                                <th>音频文件</th>
                                <th>V值一致</th>
                                <th>A值一致</th>
                                <th>离散情感一致</th>
                                <th>用户标注</th>
                                <th>标准答案</th>
                            </tr>
                        </thead>
                        <tbody>
        `;

        data.detailed_results.forEach(result => {
            reportHtml += `
                <tr class="${result.v_consistent && result.a_consistent && result.discrete_consistent ? 'consistent-row' : 'inconsistent-row'}">
                    <td>${result.audio_file}</td>
                    <td class="${result.v_consistent ? 'consistent' : 'inconsistent'}">${result.v_consistent ? '✓' : '✗'}</td>
                    <td class="${result.a_consistent ? 'consistent' : 'inconsistent'}">${result.a_consistent ? '✓' : '✗'}</td>
                    <td class="${result.discrete_consistent ? 'consistent' : 'inconsistent'}">${result.discrete_consistent ? '✓' : '✗'}</td>
                    <td>
                        V: ${result.user_v !== null && result.user_v !== undefined ? result.user_v : 'N/A'}<br>
                        A: ${result.user_a !== null && result.user_a !== undefined ? result.user_a : 'N/A'}<br>
                        离散: ${result.user_discrete || 'N/A'}
                    </td>
                    <td>
                        V: ${result.standard_v !== null && result.standard_v !== undefined ? result.standard_v : 'N/A'}<br>
                        A: ${result.standard_a !== null && result.standard_a !== undefined ? result.standard_a : 'N/A'}<br>
                        离散: ${result.standard_discrete || 'N/A'}
                    </td>
                </tr>
            `;
        });

        reportHtml += `
                        </tbody>
                    </table>
                </div>
                
                <div class="export-options">
                    <button class="btn btn-primary" onclick="adminDashboard.exportSecondConsistencyAsCSV()">导出为CSV</button>
                    <button class="btn btn-primary" onclick="adminDashboard.exportSecondConsistencyAsJSON()">导出为JSON</button>
                </div>
            </div>
        `;

        reportDiv.innerHTML = reportHtml;
        reportDiv.style.display = 'block';

        this.showSuccess('第二次一致性详细报告已生成');
    }

    /**
     * 生成第二次一致性详细报告
     */
    generateDetailedSecondConsistencyReport() {
        if (!this.currentSecondConsistencyData) {
            this.showError('请先计算第二次一致性分析');
            return;
        }

        const data = this.currentSecondConsistencyData;
        const reportDiv = document.getElementById('detailed-second-consistency-report');

        let reportHtml = `
            <div class="detailed-report-content">
                <h4>用户 ${data.username} 的详细第二次一致性报告</h4>
                <div class="report-summary">
                    <p><strong>报告生成时间:</strong> ${new Date().toLocaleString()}</p>
                    <p><strong>总样本数:</strong> ${data.total_samples}</p>
                    <p><strong>总体一致性:</strong> ${(data.overall_consistency * 100).toFixed(2)}%</p>
                </div>
                
                <div class="detailed-results">
                    <h5>详细结果列表</h5>
                    <table class="detailed-results-table">
                        <thead>
                            <tr>
                                <th>音频文件</th>
                                <th>V值一致</th>
                                <th>A值一致</th>
                                <th>离散情感一致</th>
                                <th>用户标注</th>
                                <th>标准答案</th>
                            </tr>
                        </thead>
                        <tbody>
        `;

        data.detailed_results.forEach(result => {
            reportHtml += `
                <tr class="${result.v_consistent && result.a_consistent && result.discrete_consistent ? 'consistent-row' : 'inconsistent-row'}">
                    <td>${result.audio_file}</td>
                    <td class="${result.v_consistent ? 'consistent' : 'inconsistent'}">${result.v_consistent ? '✓' : '✗'}</td>
                    <td class="${result.a_consistent ? 'consistent' : 'inconsistent'}">${result.a_consistent ? '✓' : '✗'}</td>
                    <td class="${result.discrete_consistent ? 'consistent' : 'inconsistent'}">${result.discrete_consistent ? '✓' : '✗'}</td>
                    <td>
                        V: ${result.user_v !== null && result.user_v !== undefined ? result.user_v : 'N/A'}<br>
                        A: ${result.user_a !== null && result.user_a !== undefined ? result.user_a : 'N/A'}<br>
                        离散: ${result.user_discrete || 'N/A'}
                    </td>
                    <td>
                        V: ${result.standard_v !== null && result.standard_v !== undefined ? result.standard_v : 'N/A'}<br>
                        A: ${result.standard_a !== null && result.standard_a !== undefined ? result.standard_a : 'N/A'}<br>
                        离散: ${result.standard_discrete || 'N/A'}
                    </td>
                </tr>
            `;
        });

        reportHtml += `
                        </tbody>
                    </table>
                </div>
                
                <div class="export-options">
                    <button class="btn btn-primary" onclick="adminDashboard.exportSecondConsistencyAsCSV()">导出为CSV</button>
                    <button class="btn btn-primary" onclick="adminDashboard.exportSecondConsistencyAsJSON()">导出为JSON</button>
                </div>
            </div>
        `;

        reportDiv.innerHTML = reportHtml;
        reportDiv.style.display = 'block';

        this.showSuccess('第二次一致性详细报告已生成');
    }

    /**
     * 显示第二次一致性导出选项
     */
    showSecondExportOptions() {
        if (!this.currentSecondConsistencyData) {
            this.showError('请先计算第二次一致性分析');
            return;
        }

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'block';
        modal.innerHTML = `
            <div class="modal-content">
                <span class="close">&times;</span>
                <h3>选择导出格式</h3>
                <div class="export-options">
                    <button class="btn btn-primary" onclick="adminDashboard.exportSecondConsistencyAsCSV(); this.closest('.modal').remove();">导出为CSV</button>
                    <button class="btn btn-primary" onclick="adminDashboard.exportSecondConsistencyAsJSON(); this.closest('.modal').remove();">导出为JSON</button>
                </div>
            </div>
        `;

        document.body.appendChild(modal);

        // 关闭模态框
        modal.querySelector('.close').addEventListener('click', () => {
            modal.remove();
        });

        // 点击背景关闭
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });
    }

    /**
     * 导出第二次一致性数据为CSV格式
     */
    exportSecondConsistencyAsCSV() {
        if (!this.currentSecondConsistencyData) {
            this.showError('请先计算第二次一致性分析');
            return;
        }

        const data = this.currentSecondConsistencyData;
        let csvContent = "音频文件,V值一致,A值一致,离散情感一致,用户V值,用户A值,用户离散情感,标准V值,标准A值,标准离散情感\n";

        data.detailed_results.forEach(result => {
            csvContent += [
                result.audio_file,
                result.v_consistent ? '是' : '否',
                result.a_consistent ? '是' : '否',
                result.discrete_consistent ? '是' : '否',
                result.user_v !== null && result.user_v !== undefined ? result.user_v : '',
                result.user_a !== null && result.user_a !== undefined ? result.user_a : '',
                result.user_discrete || '',
                result.standard_v !== null && result.standard_v !== undefined ? result.standard_v : '',
                result.standard_a !== null && result.standard_a !== undefined ? result.standard_a : '',
                result.standard_discrete || ''
            ].join(',') + '\n';
        });

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', `second_consistency_report_${data.username}_${new Date().toISOString().split('T')[0]}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);

        this.showSuccess('第二次一致性CSV报告已导出');
    }

    /**
     * 导出第二次一致性数据为JSON格式
     */
    exportSecondConsistencyAsJSON() {
        if (!this.currentSecondConsistencyData) {
            this.showError('请先计算第二次一致性分析');
            return;
        }

        const data = this.currentSecondConsistencyData;
        const exportData = {
            username: data.username,
            export_time: new Date().toISOString(),
            total_samples: data.total_samples,
            overall_consistency: data.overall_consistency,
            v_consistency: data.v_consistency,
            a_consistency: data.a_consistency,
            discrete_consistency: data.discrete_consistency,
            detailed_results: data.detailed_results
        };

        const jsonContent = JSON.stringify(exportData, null, 2);
        const blob = new Blob([jsonContent], { type: 'application/json;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', `second_consistency_report_${data.username}_${new Date().toISOString().split('T')[0]}.json`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);

        this.showSuccess('第二次一致性JSON报告已导出');
    }

    /**
     * 导出整个第二次一致性测试结果为xlsx格式
     */
    async exportAllSecondConsistencyResults() {
        try {
            this.showSuccess('正在导出全部第二次一致性测试结果，请稍候...');

            const response = await fetch('/admin/api/export/second-consistency-results');

            if (response.ok) {
                // 获取文件名
                const contentDisposition = response.headers.get('Content-Disposition');
                let filename = 'second_consistency_test_results.xlsx';
                if (contentDisposition) {
                    const filenameMatch = contentDisposition.match(/filename="?([^"]+)"?/);
                    if (filenameMatch) {
                        filename = filenameMatch[1];
                    }
                }

                // 创建下载链接
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.download = filename;
                link.style.display = 'none';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                window.URL.revokeObjectURL(url);

                this.showSuccess('全部第二次一致性测试结果已成功导出为Excel文件');
            } else {
                const errorData = await response.json();
                this.showError('导出失败: ' + (errorData.error || '未知错误'));
            }
        } catch (error) {
            this.showError('导出失败: ' + error.message);
        }
    }

    /**
     * 加载测试设置数据
     */
    async loadTestSettingsData() {
        try {
            const response = await fetch('/admin/api/users/test-settings');
            const data = await response.json();

            if (response.ok) {
                this.updateTestSettingsTable(data.users);
            } else {
                this.showError('加载测试设置数据失败: ' + data.error);
            }
        } catch (error) {
            this.showError('网络错误: ' + error.message);
        }
    }

    /**
     * 更新测试设置表格
     * @param {Array} users - 用户数据数组
     */
    updateTestSettingsTable(users) {
        const tbody = document.getElementById('test-settings-tbody');
        tbody.innerHTML = '';

        users.forEach(user => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${user.wechat_name}</td>
                <td>${user.phone_number}</td>
                <td>${new Date(user.created_at).toLocaleDateString()}</td>
                <td>
                    <label class="switch">
                        <input type="checkbox" ${user.skip_test ? 'checked' : ''} 
                               onchange="adminDashboard.updateTestSetting('${user.wechat_name}', 'skip_test', this.checked)">
                        <span class="slider"></span>
                    </label>
                </td>
                <td>
                    <label class="switch">
                        <input type="checkbox" ${user.skip_consistency_test ? 'checked' : ''} 
                               onchange="adminDashboard.updateTestSetting('${user.wechat_name}', 'skip_consistency_test', this.checked)">
                        <span class="slider"></span>
                    </label>
                </td>
                <td>
                    <button class="btn btn-sm btn-secondary" 
                            onclick="adminDashboard.resetUserTestSettings('${user.wechat_name}')">
                        重置
                    </button>
                </td>
            `;
            tbody.appendChild(row);
        });
    }

    /**
     * 更新用户测试设置
     * @param {string} username - 用户名
     * @param {string} setting - 设置类型
     * @param {boolean} value - 设置值
     */
    async updateTestSetting(username, setting, value) {
        try {
            const requestData = {
                username: username
            };
            requestData[setting] = value;

            const response = await fetch('/admin/api/users/test-settings', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(requestData)
            });

            const data = await response.json();

            if (response.ok) {
                this.showSuccess(data.message);
            } else {
                this.showError('更新失败: ' + data.message);
                // 恢复开关状态
                this.loadTestSettingsData();
            }
        } catch (error) {
            this.showError('网络错误: ' + error.message);
            // 恢复开关状态
            this.loadTestSettingsData();
        }
    }

    /**
     * 重置用户测试设置
     * @param {string} username - 用户名
     */
    async resetUserTestSettings(username) {
        if (!confirm(`确定要重置用户 ${username} 的测试设置吗？这将要求用户重新进行测试和一致性检验。`)) {
            return;
        }

        try {
            const response = await fetch('/admin/api/users/test-settings', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    username: username,
                    skip_test: false,
                    skip_consistency_test: false
                })
            });

            const data = await response.json();

            if (response.ok) {
                this.showSuccess('用户测试设置已重置');
                this.loadTestSettingsData();
            } else {
                this.showError('重置失败: ' + data.message);
            }
        } catch (error) {
            this.showError('网络错误: ' + error.message);
        }
    }

    /**
     * 加载管理员数据
     */
    async loadAdminsData() {
        console.log('loadAdminsData called');
        try {
            const response = await fetch('/admin/api/admins');
            console.log('API response status:', response.status);
            const data = await response.json();
            console.log('API response data:', data);

            if (response.ok) {
                this.updateAdminsTable(data.admins);
                this.updateAdminPermissions(data.current_admin);
            } else {
                console.error('API error:', data.error);
                this.showError('加载管理员数据失败: ' + data.error);
            }
        } catch (error) {
            console.error('Network error:', error);
            this.showError('网络错误: ' + error.message);
        }
    }

    /**
     * 更新管理员表格
     * @param {Array} admins - 管理员列表
     */
    updateAdminsTable(admins) {
        const tbody = document.querySelector('#admins-table tbody');
        tbody.innerHTML = '';

        admins.forEach(admin => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${admin.id}</td>
                <td>${admin.username}</td>
                <td>
                    <span class="role-badge ${admin.role}">
                        ${admin.role === 'super_admin' ? '超级管理员' : '普通管理员'}
                    </span>
                </td>
                <td>${admin.description || '-'}</td>
                <td>
                    <span class="status-badge ${admin.is_active ? 'active' : 'inactive'}">
                        ${admin.is_active ? '激活' : '禁用'}
                    </span>
                </td>
                <td>${new Date(admin.created_at).toLocaleString()}</td>
                <td>
                    ${admin.role !== 'super_admin' ? `
                        <button class="btn btn-sm btn-warning" onclick="adminDashboard.toggleAdminStatus(${admin.id}, ${!admin.is_active})">
                            ${admin.is_active ? '禁用' : '激活'}
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="adminDashboard.deleteAdmin(${admin.id}, '${admin.username}')">
                            删除
                        </button>
                    ` : '<span class="text-muted">-</span>'}
                </td>
            `;
            tbody.appendChild(row);
        });
    }

    /**
     * 更新管理员权限显示
     * @param {Object} currentAdmin - 当前管理员信息
     */
    updateAdminPermissions(currentAdmin) {
        console.log('updateAdminPermissions called with:', currentAdmin);
        const createBtn = document.getElementById('create-admin-btn');
        if (!createBtn) {
            console.error('create-admin-btn element not found');
            return;
        }

        if (currentAdmin && currentAdmin.role === 'super_admin') {
            console.log('Showing create admin button for super admin');
            createBtn.style.display = 'inline-block';
        } else {
            console.log('Hiding create admin button, role:', currentAdmin ? currentAdmin.role : 'no admin data');
            createBtn.style.display = 'none';
        }
    }

    /**
     * 显示创建管理员模态框
     */
    showCreateAdminModal() {
        document.getElementById('create-admin-modal').style.display = 'block';
        document.getElementById('create-admin-form').reset();
    }

    /**
     * 创建管理员
     */
    async createAdmin() {
        const form = document.getElementById('create-admin-form');
        const formData = new FormData(form);

        const adminData = {
            username: formData.get('username'),
            password: formData.get('password'),
            description: formData.get('description')
        };

        try {
            const response = await fetch('/admin/api/admins', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(adminData)
            });

            const data = await response.json();

            if (response.ok) {
                this.showSuccess(data.message);
                document.getElementById('create-admin-modal').style.display = 'none';
                this.loadAdminsData();
            } else {
                this.showError('创建失败: ' + data.message);
            }
        } catch (error) {
            this.showError('网络错误: ' + error.message);
        }
    }

    /**
     * 显示修改密码模态框
     */
    showChangePasswordModal() {
        document.getElementById('change-password-modal').style.display = 'block';
        document.getElementById('change-password-form').reset();
    }

    /**
     * 修改管理员密码
     */
    async changePassword() {
        console.log('changePassword方法被调用');
        const form = document.getElementById('change-password-form');
        if (!form) {
            console.error('找不到change-password-form表单');
            this.showError('表单未找到，请刷新页面重试');
            return;
        }

        const formData = new FormData(form);

        const newPassword = formData.get('new_password');
        const confirmPassword = formData.get('confirm_password');

        console.log('密码验证中...');
        if (newPassword !== confirmPassword) {
            this.showError('新密码和确认密码不匹配');
            return;
        }

        const passwordData = {
            old_password: formData.get('old_password'),
            new_password: newPassword
        };

        try {
            console.log('发送密码修改请求...', passwordData);
            const response = await fetch('/admin/api/admins/change-password', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(passwordData)
            });

            console.log('收到响应，状态码:', response.status);
            const data = await response.json();
            console.log('响应数据:', data);

            if (response.ok) {
                this.showSuccess(data.message);
                document.getElementById('change-password-modal').style.display = 'none';
                form.reset(); // 重置表单
            } else {
                this.showError('修改失败: ' + data.message);
            }
        } catch (error) {
            console.error('网络错误:', error);
            this.showError('网络错误: ' + error.message);
        }
    }

    /**
     * 切换管理员状态
     * @param {number} adminId - 管理员ID
     * @param {boolean} isActive - 新状态
     */
    async toggleAdminStatus(adminId, isActive) {
        try {
            const response = await fetch(`/admin/api/admins/${adminId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ is_active: isActive })
            });

            const data = await response.json();

            if (response.ok) {
                this.showSuccess(data.message);
                this.loadAdminsData();
            } else {
                this.showError('更新失败: ' + data.message);
            }
        } catch (error) {
            this.showError('网络错误: ' + error.message);
        }
    }

    /**
     * 删除管理员
     * @param {number} adminId - 管理员ID
     * @param {string} username - 管理员用户名
     */
    async deleteAdmin(adminId, username) {
        if (!confirm(`确定要删除管理员 "${username}" 吗？此操作不可撤销。`)) {
            return;
        }

        try {
            const response = await fetch(`/admin/api/admins/${adminId}`, {
                method: 'DELETE'
            });

            const data = await response.json();

            if (response.ok) {
                this.showSuccess(data.message);
                this.loadAdminsData();
            } else {
                this.showError('删除失败: ' + data.message);
            }
        } catch (error) {
            this.showError('网络错误: ' + error.message);
        }
    }

    /**
     * 处理A值或V值分布数据
     * @param {Object} distributionData - 分布数据对象
     * @param {Array} ranges - 值范围数组
     * @returns {Object} 处理后的图表数据
     */
    processValueDistribution(distributionData, ranges) {
        const colors = ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40', '#C9CBCF'];
        const users = Object.keys(distributionData);

        const datasets = users.map((username, index) => {
            const userData = distributionData[username];
            const data = ranges.map(range => userData[range] || 0);

            return {
                label: username,
                data: data,
                backgroundColor: colors[index % colors.length],
                borderColor: colors[index % colors.length],
                borderWidth: 1
            };
        });

        return {
            labels: ranges,
            datasets: datasets
        };
    }

    /**
     * 处理离散情感分布数据
     * @param {Object} distributionData - 分布数据对象
     * @returns {Object} 处理后的图表数据
     */
    processDiscreteEmotionDistribution(distributionData) {
        const colors = ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40', '#C9CBCF'];
        const users = Object.keys(distributionData);

        // 获取所有情感类型
        const allEmotions = new Set();
        users.forEach(username => {
            Object.keys(distributionData[username]).forEach(emotion => {
                allEmotions.add(emotion);
            });
        });
        const emotions = Array.from(allEmotions).sort();

        const datasets = users.map((username, index) => {
            const userData = distributionData[username];
            const data = emotions.map(emotion => userData[emotion] || 0);

            return {
                label: username,
                data: data,
                backgroundColor: colors[index % colors.length],
                borderColor: colors[index % colors.length],
                borderWidth: 1
            };
        });

        return {
            labels: emotions,
            datasets: datasets
        };
    }

    /**
     * 导出用户详情数据为CSV文件
     */
    exportUserDetailsToCSV() {
        if (!this.currentUserDetails) {
            this.showError('没有可导出的用户详情数据');
            return;
        }

        const userDetails = this.currentUserDetails;
        const csvData = [];

        // 添加基本信息
        csvData.push(['用户名', userDetails.username]);
        csvData.push(['总标注数', userDetails.total_annotations]);
        csvData.push(['完成数', userDetails.completed_annotations]);
        csvData.push(['完成率', userDetails.completion_rate + '%']);
        csvData.push(['总时长(秒)', userDetails.total_duration]);
        csvData.push(['平均播放次数', userDetails.avg_play_count]);
        csvData.push([]);

        // 添加说话人统计
        csvData.push(['说话人统计']);
        csvData.push(['说话人', '标注数', '完成数', '完成率']);
        userDetails.speakers_stats.forEach(speaker => {
            csvData.push([
                speaker.speaker,
                speaker.annotations_count,
                speaker.completed_count,
                speaker.completion_rate + '%'
            ]);
        });
        csvData.push([]);

        // 添加最近标注
        csvData.push(['最近标注']);
        csvData.push(['音频文件', '说话人', 'VA完成', '离散完成', '时间']);
        userDetails.recent_annotations.forEach(annotation => {
            csvData.push([
                annotation.audio_file,
                annotation.speaker,
                annotation.va_complete ? '是' : '否',
                annotation.discrete_complete ? '是' : '否',
                annotation.timestamp
            ]);
        });

        // 转换为CSV格式
        const csvContent = csvData.map(row =>
            row.map(field => {
                // 处理包含逗号或引号的字段
                if (typeof field === 'string' && (field.includes(',') || field.includes('"') || field.includes('\n'))) {
                    return '"' + field.replace(/"/g, '""') + '"';
                }
                return field;
            }).join(',')
        ).join('\n');

        // 创建下载链接
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', `用户详情_${userDetails.username}_${new Date().toISOString().slice(0, 10)}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        this.showSuccess('用户详情CSV文件已导出');
    }

    /**
     * 显示用户分组模态框
     * @param {string} username - 用户名
     * @param {string} currentGroup - 当前分组
     */
    showUserGroupModal(username, currentGroupId) {
        document.getElementById('group-username').value = username;

        // 将group_id转换为选择框需要的格式
        let selectValue = '';
        if (currentGroupId && currentGroupId !== null) {
            selectValue = `group${currentGroupId}`;
        }

        document.getElementById('user-group-select').value = selectValue;
        document.getElementById('user-group-modal').style.display = 'block';
    }

    /**
     * 更新用户分组（管理员手动分配）
     */
    async updateUserGroup() {
        try {
            const formData = new FormData(document.getElementById('user-group-form'));
            const username = formData.get('username');
            const userGroup = formData.get('user_group');

            // 如果选择了"移除分组"，将值设为null
            const groupValue = userGroup === 'null' ? null : userGroup;

            // 显示加载状态
            const submitBtn = document.querySelector('#user-group-form button[type="submit"]');
            const originalText = submitBtn.textContent;
            submitBtn.textContent = '处理中...';
            submitBtn.disabled = true;

            const response = await fetch(`/admin/api/users/${username}/group`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    user_group: groupValue
                })
            });

            const data = await response.json();

            if (response.ok && data.success) {
                this.showSuccess(data.message || '用户分组更新成功');
                closeModal('user-group-modal');
                this.loadUsersData(); // 刷新用户列表
            } else {
                // 显示详细的错误信息
                const errorMsg = data.error || '更新用户分组失败';
                this.showError(errorMsg);

                // 移除分组人数限制提示
                // if (errorMsg.includes('已满员')) {
                //     this.showError('提示：每个分组最多只能分配3个用户。请选择其他分组或先移除该分组中的其他用户。');
                // }
            }
        } catch (error) {
            this.showError('网络错误: ' + error.message);
        } finally {
            // 恢复按钮状态
            const submitBtn = document.querySelector('#user-group-form button[type="submit"]');
            if (submitBtn) {
                submitBtn.textContent = '保存';
                submitBtn.disabled = false;
            }
        }
    }

    /**
     * 导出图表为图片
     * @param {string} canvasId - 图表canvas元素的ID
     * @param {string} filename - 导出文件名
     */
    exportChartAsImage(canvasId, filename) {
        try {
            const canvas = document.getElementById(canvasId);
            if (!canvas) {
                this.showError('未找到图表元素');
                return;
            }

            // 创建一个新的canvas来绘制白色背景
            const exportCanvas = document.createElement('canvas');
            const exportCtx = exportCanvas.getContext('2d');
            
            // 设置导出canvas的尺寸
            exportCanvas.width = canvas.width;
            exportCanvas.height = canvas.height;
            
            // 绘制白色背景
            exportCtx.fillStyle = '#ffffff';
            exportCtx.fillRect(0, 0, exportCanvas.width, exportCanvas.height);
            
            // 将原图表绘制到新canvas上
            exportCtx.drawImage(canvas, 0, 0);
            
            // 转换为图片并下载
            exportCanvas.toBlob((blob) => {
                const url = URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.download = `${filename}_${new Date().toISOString().slice(0, 10)}.png`;
                link.style.visibility = 'hidden';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                URL.revokeObjectURL(url);
                
                this.showSuccess(`${filename}已导出`);
            }, 'image/png');
            
        } catch (error) {
            console.error('导出图表失败:', error);
            this.showError('导出图表失败: ' + error.message);
        }
    }

    /**
     * 显示用户spk标注权限设置模态框
     * @param {string} username - 用户名
     */
    async showUserSpeakerPermissions(username) {
        try {
            const response = await fetch(`/admin/api/users/${username}/speaker-permissions`);
            const data = await response.json();

            if (response.ok && data.success) {
                this.displayUserSpeakerPermissions(data);
            } else {
                this.showError('加载用户权限设置失败: ' + (data.message || '未知错误'));
            }
        } catch (error) {
            this.showError('网络错误: ' + error.message);
        }
    }

    /**
     * 显示用户spk标注权限设置界面
     * @param {Object} data - 权限设置数据
     */
    displayUserSpeakerPermissions(data) {
        document.getElementById('permissions-username').textContent = data.username;
        document.getElementById('permissions-group-id').textContent = `分组 ${data.group_id}`;
        
        const container = document.getElementById('speaker-permissions-list');
        container.innerHTML = '';
        
        data.speaker_permissions.forEach(perm => {
            const permissionItem = document.createElement('div');
            permissionItem.className = 'permission-item';
            permissionItem.innerHTML = `
                <label class="permission-label">
                    <input type="checkbox" 
                           data-speaker="${perm.speaker_id}" 
                           ${perm.annotation_enabled ? 'checked' : ''}>
                    <span class="speaker-name">${perm.speaker_id}</span>
                    <span class="permission-status">${perm.annotation_enabled ? '启用标注' : '禁用标注'}</span>
                </label>
            `;
            
            // 添加复选框变化事件
            const checkbox = permissionItem.querySelector('input[type="checkbox"]');
            const statusSpan = permissionItem.querySelector('.permission-status');
            
            checkbox.addEventListener('change', function() {
                statusSpan.textContent = this.checked ? '启用标注' : '禁用标注';
                statusSpan.className = 'permission-status ' + (this.checked ? 'enabled' : 'disabled');
            });
            
            container.appendChild(permissionItem);
        });
        
        // 存储当前用户名供保存时使用
        this.currentPermissionsUsername = data.username;
        
        document.getElementById('speaker-permissions-modal').style.display = 'block';
    }

    /**
     * 保存用户spk标注权限设置
     */
    async saveUserSpeakerPermissions() {
        try {
            const checkboxes = document.querySelectorAll('#speaker-permissions-list input[type="checkbox"]');
            const speakerPermissions = [];
            
            checkboxes.forEach(checkbox => {
                speakerPermissions.push({
                    speaker_id: checkbox.dataset.speaker,
                    annotation_enabled: checkbox.checked
                });
            });
            
            const response = await fetch(`/admin/api/users/${this.currentPermissionsUsername}/speaker-permissions`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    speaker_permissions: speakerPermissions
                })
            });
            
            const data = await response.json();
            
            if (response.ok && data.success) {
                this.showSuccess(data.message || '权限设置保存成功');
                closeModal('speaker-permissions-modal');
            } else {
                this.showError('保存权限设置失败: ' + (data.message || '未知错误'));
            }
        } catch (error) {
            this.showError('网络错误: ' + error.message);
        }
    }
}

// 全局函数，用于模态框关闭
function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// 初始化管理员仪表板
let adminDashboard;
document.addEventListener('DOMContentLoaded', () => {
    adminDashboard = new AdminDashboard();
});