/**
 * 优化版本的main.js - 解决保存卡顿问题
 * 主要优化：减少checkSecondConsistencyTest的调用频率
 */

// 添加一致性测试检查的优化逻辑
class ConsistencyTestOptimizer {
    constructor() {
        this.lastCheckTime = 0;
        this.checkInterval = 30000; // 30秒检查一次
        this.saveCount = 0;
        this.checkEveryNSaves = 10; // 每10次保存检查一次
        this.lastCheckResult = null;
        this.cacheExpiry = 60000; // 缓存1分钟
    }

    /**
     * 判断是否需要进行一致性测试检查
     * @returns {boolean}
     */
    shouldCheck() {
        const now = Date.now();
        this.saveCount++;
        
        // 方案1：基于时间间隔
        const timeBasedCheck = (now - this.lastCheckTime) > this.checkInterval;
        
        // 方案2：基于保存次数
        const countBasedCheck = (this.saveCount % this.checkEveryNSaves) === 0;
        
        // 方案3：缓存结果检查
        const cacheExpired = !this.lastCheckResult || 
                            (now - this.lastCheckResult.timestamp) > this.cacheExpiry;
        
        return (timeBasedCheck || countBasedCheck) && cacheExpired;
    }

    /**
     * 更新检查时间和缓存结果
     * @param {Object} result - 检查结果
     */
    updateCheckResult(result) {
        this.lastCheckTime = Date.now();
        this.lastCheckResult = {
            ...result,
            timestamp: Date.now()
        };
    }

    /**
     * 获取缓存的检查结果
     * @returns {Object|null}
     */
    getCachedResult() {
        if (this.lastCheckResult && 
            (Date.now() - this.lastCheckResult.timestamp) < this.cacheExpiry) {
            return this.lastCheckResult;
        }
        return null;
    }
}

// 在MainApp类中添加优化器
class MainAppOptimized extends MainApp {
    constructor() {
        super();
        this.consistencyOptimizer = new ConsistencyTestOptimizer();
    }

    /**
     * 优化版本的保存VA标注方法
     */
    async handleSaveVa() {
        const currentAudio = this.audioListManager.getCurrentAudio();
        if (!currentAudio) return;
        
        const annotation = this.emotionAnnotator.getCurrentAnnotation();
        const labelData = {
            speaker: this.audioListManager.currentSpeaker,
            audio_file: currentAudio.file_name,
            username: this.userManager.getCurrentUsername(),
            ...annotation
        };
        
        const saveButton = document.getElementById('save-va-button');
        saveButton.disabled = true;
        saveButton.textContent = '保存中...';
        
        try {
            const result = await DataService.saveLabel(labelData);
            if (result.success) {
                const completeness = this.emotionAnnotator.getAnnotationCompleteness();
                this.audioListManager.updateAudioLabelStatus(
                    this.audioListManager.currentAudioIndex, 
                    true, 
                    completeness
                );
                this.emotionAnnotator.setModified(false);
                this.updateSaveButtonStatus(true);
                
                // 优化：只在必要时检查第二次一致性测试
                await this.checkSecondConsistencyTestOptimized();
            } else {
                throw new Error(result.error || '保存失败');
            }
        } catch (error) {
            console.error('保存VA标注失败:', error);
            alert('保存VA标注失败，请重试');
            saveButton.textContent = '保存VA(W)';
            saveButton.disabled = false;
        }
        
        this.keyboardHandler.resetFocus();
    }

    /**
     * 优化版本的保存离散情感标注方法
     */
    async handleSaveDiscrete() {
        const currentAudio = this.audioListManager.getCurrentAudio();
        if (!currentAudio) return;
        
        const annotation = this.emotionAnnotator.getCurrentAnnotation();
        const labelData = {
            speaker: this.audioListManager.currentSpeaker,
            audio_file: currentAudio.file_name,
            username: this.userManager.getCurrentUsername(),
            ...annotation
        };
        
        const saveButton = document.getElementById('save-discrete-button');
        saveButton.disabled = true;
        saveButton.textContent = '保存中...';
        
        try {
            const result = await DataService.saveLabel(labelData);
            if (result.success) {
                const completeness = this.emotionAnnotator.getAnnotationCompleteness();
                this.audioListManager.updateAudioLabelStatus(
                    this.audioListManager.currentAudioIndex, 
                    true, 
                    completeness
                );
                this.emotionAnnotator.setModified(false);
                this.updateSaveButtonStatus(true);
                
                // 优化：只在必要时检查第二次一致性测试
                await this.checkSecondConsistencyTestOptimized();
            } else {
                throw new Error(result.error || '保存失败');
            }
        } catch (error) {
            console.error('保存离散情感标注失败:', error);
            alert('保存离散情感标注失败，请重试');
            saveButton.textContent = '保存离散(W)';
            saveButton.disabled = false;
        }
        
        this.keyboardHandler.resetFocus();
    }

    /**
     * 优化版本的第二次一致性测试检查
     * 减少不必要的网络请求和数据库查询
     */
    async checkSecondConsistencyTestOptimized() {
        try {
            // 首先检查是否需要进行检查
            if (!this.consistencyOptimizer.shouldCheck()) {
                // 如果有缓存结果且用户需要测试，直接使用缓存结果
                const cachedResult = this.consistencyOptimizer.getCachedResult();
                if (cachedResult && cachedResult.data && cachedResult.data.needs_second_test) {
                    this.showSecondConsistencyTestPrompt(cachedResult.data.annotated_count);
                }
                return;
            }

            const username = this.userManager.getCurrentUsername();
            const response = await fetch(`/api/check-second-consistency-test/${username}`);
            const result = await response.json();
            
            // 更新检查结果缓存
            this.consistencyOptimizer.updateCheckResult(result);
            
            if (result.success && result.data.needs_second_test) {
                // 显示提示弹窗
                this.showSecondConsistencyTestPrompt(result.data.annotated_count);
            }
        } catch (error) {
            console.error('检查第二次一致性测试失败:', error);
            // 错误时不影响正常保存流程
        }
    }

    /**
     * 手动触发一致性测试检查（用于特殊情况）
     */
    async forceCheckSecondConsistencyTest() {
        // 重置优化器状态，强制进行检查
        this.consistencyOptimizer.lastCheckTime = 0;
        this.consistencyOptimizer.lastCheckResult = null;
        await this.checkSecondConsistencyTestOptimized();
    }

    /**
     * 获取优化器统计信息（用于调试）
     */
    getOptimizerStats() {
        return {
            saveCount: this.consistencyOptimizer.saveCount,
            lastCheckTime: new Date(this.consistencyOptimizer.lastCheckTime).toLocaleString(),
            hasCachedResult: !!this.consistencyOptimizer.lastCheckResult,
            cacheAge: this.consistencyOptimizer.lastCheckResult ? 
                     Date.now() - this.consistencyOptimizer.lastCheckResult.timestamp : 0
        };
    }
}

// 导出优化版本的类
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { MainAppOptimized, ConsistencyTestOptimizer };
}