/**
 * 登录页面JavaScript逻辑
 */

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', function() {
    initLoginForm();
    initCaptcha();
});

/**
 * 初始化登录表单
 */
function initLoginForm() {
    const form = document.querySelector('form');
    const submitBtn = document.querySelector('.btn');
    
    if (form) {
        form.addEventListener('submit', handleLogin);
    }
}

/**
 * 验证码相关变量
 */
let currentCaptcha = '';

/**
 * 初始化验证码
 */
function initCaptcha() {
    const canvas = document.getElementById('captchaCanvas');
    if (canvas) {
        generateCaptcha();
        canvas.addEventListener('click', generateCaptcha);
    }
}

/**
 * 生成验证码
 */
function generateCaptcha() {
    // 调用后端接口获取验证码
    fetch('/api/captcha', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            currentCaptcha = data.captcha;
            drawCaptcha(currentCaptcha);
        } else {
            console.error('获取验证码失败:', data.message);
            showError('获取验证码失败，请刷新页面重试');
        }
    })
    .catch(error => {
        console.error('验证码请求失败:', error);
        showError('网络错误，请检查网络连接后重试');
    });
}

/**
 * 在画布上绘制验证码
 */
function drawCaptcha(captcha) {
    const canvas = document.getElementById('captchaCanvas');
    const ctx = canvas.getContext('2d');
    
    // 清空画布
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // 设置背景
    ctx.fillStyle = '#f0f0f0';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // 绘制干扰线
    for (let i = 0; i < 3; i++) {
        ctx.strokeStyle = getRandomColor();
        ctx.beginPath();
        ctx.moveTo(Math.random() * canvas.width, Math.random() * canvas.height);
        ctx.lineTo(Math.random() * canvas.width, Math.random() * canvas.height);
        ctx.stroke();
    }
    
    // 绘制验证码文字
    ctx.font = '20px Arial';
    ctx.textBaseline = 'middle';
    
    for (let i = 0; i < captcha.length; i++) {
        ctx.fillStyle = getRandomColor();
        const x = 20 + i * 20;
        const y = canvas.height / 2;
        const angle = (Math.random() - 0.5) * 0.5;
        
        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(angle);
        ctx.fillText(captcha[i], 0, 0);
        ctx.restore();
    }
    
    // 绘制干扰点
    for (let i = 0; i < 20; i++) {
        ctx.fillStyle = getRandomColor();
        ctx.beginPath();
        ctx.arc(Math.random() * canvas.width, Math.random() * canvas.height, 1, 0, 2 * Math.PI);
        ctx.fill();
    }
}

/**
 * 获取随机颜色
 */
function getRandomColor() {
    const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD', '#98D8C8'];
    return colors[Math.floor(Math.random() * colors.length)];
}

/**
 * 验证验证码（已移除前端验证，改为后端验证）
 */
function validateCaptcha(inputCaptcha) {
    // 验证码验证现在完全由后端处理，前端不再进行验证
    return true;
}

/**
 * 处理登录表单提交
 * @param {Event} event - 表单提交事件
 */
function handleLogin(event) {
    event.preventDefault();
    
    const wechatName = document.getElementById('text1').value.trim();
    const phoneNumber = document.getElementById('myInput').value.trim();
    const captchaInput = document.getElementById('captchaInput').value.trim();
    const submitBtn = document.querySelector('.btn');
    
    // 验证输入
    if (!wechatName) {
        showError('请输入微信昵称');
        return;
    }
    
    if (!phoneNumber) {
        showError('请输入手机号');
        return;
    }
    
    if (!captchaInput) {
        showError('请输入验证码');
        return;
    }
    
    // 验证手机号格式
    if (!isValidPhoneNumber(phoneNumber)) {
        showError('请输入正确的手机号格式');
        return;
    }
    
    // 验证码验证由后端处理，前端不再进行验证
    
    // 禁用提交按钮，防止重复提交
    submitBtn.disabled = true;
    submitBtn.textContent = '登录中...';
    
    // 发送登录请求
    fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            text1: wechatName,
            password: phoneNumber,
            captcha: captchaInput
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // 登录成功，显示成功消息
            showSuccess(data.message);
            
            // 保存用户名到localStorage，供主页面使用
            localStorage.setItem('emotion_labeling_username', data.username);
            
            // 添加调试信息
            console.log('登录响应数据:', data);
            console.log('skip_test:', data.skip_test, '类型:', typeof data.skip_test);
            console.log('skip_consistency_test:', data.skip_consistency_test, '类型:', typeof data.skip_consistency_test);
            
            // 根据音量测试和其他测试设置决定跳转页面
            setTimeout(() => {
                if (!data.volume_test_completed) {
                    console.log('重定向到音量测试页面');
                    // 用户未完成音量测试，优先进行音量测试
                    window.location.href = '/volume-test';
                } else {
                    console.log('重定向到音量测试确认页面');
                    // 用户已完成音量测试，跳转到确认页面
                    window.location.href = '/volume-test-confirmation';
                }
            }, 1000);
        } else {
            showError(data.message || '登录失败，请重试');
            generateCaptcha(); // 登录失败时刷新验证码
            document.getElementById('captchaInput').value = '';
        }
    })
    .catch(error => {
        console.error('登录请求失败:', error);
        showError('网络错误，请检查网络连接后重试');
        generateCaptcha(); // 网络错误时也刷新验证码
        document.getElementById('captchaInput').value = '';
    })
    .finally(() => {
        // 恢复提交按钮状态
        submitBtn.disabled = false;
        submitBtn.textContent = '登录';
    });
}

/**
 * 验证手机号格式
 * @param {string} phoneNumber - 手机号
 * @returns {boolean} 是否为有效手机号
 */
function isValidPhoneNumber(phoneNumber) {
    // 简单的手机号验证：11位数字，以1开头
    const phoneRegex = /^1[3-9]\d{9}$/;
    return phoneRegex.test(phoneNumber);
}

/**
 * 显示错误信息
 * @param {string} message - 错误信息
 */
function showError(message) {
    removeExistingMessages();
    
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.style.cssText = `
        color: #ff4444;
        background-color: #ffe6e6;
        border: 1px solid #ff4444;
        padding: 10px;
        margin: 10px 0;
        border-radius: 4px;
        text-align: center;
        font-size: 14px;
    `;
    errorDiv.textContent = message;
    
    const form = document.querySelector('form');
    form.insertBefore(errorDiv, form.firstChild);
    
    // 3秒后自动移除错误信息
    setTimeout(() => {
        if (errorDiv.parentNode) {
            errorDiv.parentNode.removeChild(errorDiv);
        }
    }, 3000);
}

/**
 * 显示成功信息
 * @param {string} message - 成功信息
 */
function showSuccess(message) {
    removeExistingMessages();
    
    const successDiv = document.createElement('div');
    successDiv.className = 'success-message';
    successDiv.style.cssText = `
        color: #00aa00;
        background-color: #e6ffe6;
        border: 1px solid #00aa00;
        padding: 10px;
        margin: 10px 0;
        border-radius: 4px;
        text-align: center;
        font-size: 14px;
    `;
    successDiv.textContent = message;
    
    const form = document.querySelector('form');
    form.insertBefore(successDiv, form.firstChild);
}

/**
 * 移除现有的消息提示
 */
function removeExistingMessages() {
    const existingMessages = document.querySelectorAll('.error-message, .success-message');
    existingMessages.forEach(msg => {
        if (msg.parentNode) {
            msg.parentNode.removeChild(msg);
        }
    });
}

