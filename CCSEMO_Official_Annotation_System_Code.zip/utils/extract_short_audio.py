#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
音频文件筛选工具
从emotion_annotation目录中移动小于等于3秒的音频文件
按照spk目录结构保存到data目录中
"""

import os
import shutil
import argparse
from pathlib import Path
from typing import List, Tuple
import logging

# 导入项目中的音频工具
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.audio_utils import get_audio_duration

class ShortAudioExtractor:
    """短音频文件提取器"""
    
    def __init__(self, source_dir: str, target_dir: str, max_duration: float = 3.0):
        """
        初始化提取器
        
        Args:
            source_dir: 源目录路径 (emotion_annotation)
            target_dir: 目标目录路径 (data)
            max_duration: 最大音频时长（秒）
        """
        self.source_dir = Path(source_dir)
        self.target_dir = Path(target_dir)
        self.max_duration = max_duration
        
        # 设置日志
        self.logger = logging.getLogger(__name__)
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)
        
        # 统计信息
        self.total_files = 0
        self.short_files = 0
        self.processed_dirs = 0
        
    def get_audio_files(self, directory: Path) -> List[Path]:
        """获取目录中的所有音频文件"""
        audio_extensions = {'.wav', '.mp3', '.flac', '.m4a', '.aac'}
        audio_files = []
        
        for file_path in directory.iterdir():
            if file_path.is_file() and file_path.suffix.lower() in audio_extensions:
                audio_files.append(file_path)
                
        return audio_files
    
    def check_audio_duration(self, file_path: Path) -> Tuple[bool, float]:
        """
        检查音频文件时长
        
        Returns:
            (is_short, duration): 是否小于等于阈值，音频时长
        """
        duration = get_audio_duration(str(file_path))
        is_short = duration <= self.max_duration
        
        return is_short, duration
    
    def move_short_audio(self, source_file: Path, target_file: Path) -> bool:
        """移动短音频文件到目标位置"""
        try:
            # 确保目标目录存在
            target_file.parent.mkdir(parents=True, exist_ok=True)
            
            # 移动文件
            shutil.move(str(source_file), str(target_file))
            self.logger.info(f"已移动: {source_file.name} -> {target_file}")
            return True
            
        except Exception as e:
            self.logger.error(f"移动文件失败 {source_file}: {e}")
            return False
    
    def process_spk_directory(self, spk_dir: Path) -> int:
        """处理单个spk目录"""
        self.logger.info(f"处理目录: {spk_dir.name}")
        
        # 获取音频文件
        audio_files = self.get_audio_files(spk_dir)
        self.total_files += len(audio_files)
        
        if not audio_files:
            self.logger.warning(f"目录 {spk_dir.name} 中没有找到音频文件")
            return 0
        
        short_count = 0
        
        for audio_file in audio_files:
            # 检查音频时长
            is_short, duration = self.check_audio_duration(audio_file)
            
            if is_short:
                # 构建目标路径
                target_path = self.target_dir / spk_dir.name / audio_file.name
                
                # 移动文件
                if self.move_short_audio(audio_file, target_path):
                    short_count += 1
                    self.logger.debug(f"短音频文件: {audio_file.name} ({duration:.2f}s)")
            else:
                self.logger.debug(f"跳过长音频文件: {audio_file.name} ({duration:.2f}s)")
        
        self.short_files += short_count
        self.logger.info(f"目录 {spk_dir.name}: 共 {len(audio_files)} 个文件，其中 {short_count} 个短音频文件")
        
        return short_count
    
    def extract_short_audio(self) -> dict:
        """移动所有短音频文件"""
        self.logger.info(f"开始移动短音频文件 (≤{self.max_duration}秒)")
        self.logger.info(f"源目录: {self.source_dir}")
        self.logger.info(f"目标目录: {self.target_dir}")
        
        # 检查源目录是否存在
        if not self.source_dir.exists():
            raise FileNotFoundError(f"源目录不存在: {self.source_dir}")
        
        # 获取所有spk目录
        spk_dirs = [d for d in self.source_dir.iterdir() if d.is_dir() and d.name.startswith('spk')]
        
        if not spk_dirs:
            raise ValueError(f"在 {self.source_dir} 中没有找到spk目录")
        
        self.logger.info(f"找到 {len(spk_dirs)} 个spk目录")
        
        # 处理每个spk目录
        for spk_dir in sorted(spk_dirs):
            try:
                self.process_spk_directory(spk_dir)
                self.processed_dirs += 1
            except Exception as e:
                self.logger.error(f"处理目录 {spk_dir.name} 时出错: {e}")
        
        # 生成统计报告
        stats = {
            'total_directories': len(spk_dirs),
            'processed_directories': self.processed_dirs,
            'total_audio_files': self.total_files,
            'short_audio_files': self.short_files,
            'max_duration': self.max_duration
        }
        
        self.logger.info("移动完成！")
        self.logger.info(f"统计信息: {stats}")
        
        return stats


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='移动短音频文件工具')
    parser.add_argument('--source', '-s', 
                       default='data/emotion_annotation',
                       help='源目录路径 (默认: data/emotion_annotation)')
    parser.add_argument('--target', '-t',
                       default='data/short_audio',
                       help='目标目录路径 (默认: data/short_audio)')
    parser.add_argument('--max-duration', '-d',
                       type=float, default=3.0,
                       help='最大音频时长（秒）(默认: 3.0)')
    parser.add_argument('--verbose', '-v',
                       action='store_true',
                       help='显示详细日志')
    
    args = parser.parse_args()
    
    # 设置日志级别
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    try:
        # 创建提取器
        extractor = ShortAudioExtractor(
            source_dir=args.source,
            target_dir=args.target,
            max_duration=args.max_duration
        )
        
        # 执行提取
        stats = extractor.extract_short_audio()
        
        # 打印最终统计
        print("\n" + "="*50)
        print("移动完成！统计信息:")
        print(f"处理目录数: {stats['processed_directories']}/{stats['total_directories']}")
        print(f"总音频文件数: {stats['total_audio_files']}")
        print(f"短音频文件数: {stats['short_audio_files']}")
        print(f"短音频文件占比: {stats['short_audio_files']/stats['total_audio_files']*100:.1f}%" if stats['total_audio_files'] > 0 else "0%")
        print(f"最大时长阈值: {stats['max_duration']}秒")
        print("="*50)
        
    except Exception as e:
        print(f"错误: {e}")
        return 1
    
    return 0


if __name__ == '__main__':
    exit(main())
