#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
音频数据统计工具
统计emotion_annotation目录中的音频文件时长和数量
按照说话人进行分组统计，输出格式与分组.txt一致
"""

import os
import argparse
import logging
from pathlib import Path
from typing import Dict, List, Tuple
from collections import defaultdict
import re

# 导入项目中的音频工具
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.audio_utils import get_audio_duration

class AudioStatistics:
    """音频数据统计器"""
    
    def __init__(self, source_dir: str, output_file: str = None, group_config: str = None):
        """
        初始化统计器
        
        Args:
            source_dir: 源目录路径 (emotion_annotation)
            output_file: 输出文件路径 (可选)
            group_config: 分组配置文件路径 (可选)
        """
        self.source_dir = Path(source_dir)
        self.output_file = output_file
        self.group_config = group_config
        
        # 设置日志
        self.logger = logging.getLogger(__name__)
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)
        
        # 统计数据
        self.speaker_stats = {}  # {speaker_id: {'duration': float, 'count': int, 'files': list}}
        self.groups = defaultdict(list)  # 分组信息
        
    def extract_speaker_id(self, dirname: str) -> str:
        """从目录名提取说话人ID"""
        # 匹配格式如: spk199-3-1 -> spk199
        match = re.match(r'(spk\d+)', dirname)
        if match:
            return match.group(1)
        return dirname
    
    def get_audio_files(self, directory: Path) -> List[Path]:
        """获取目录中的所有音频文件"""
        audio_extensions = {'.wav', '.mp3', '.flac', '.m4a', '.aac'}
        audio_files = []
        
        if not directory.exists():
            return audio_files
            
        for file_path in directory.iterdir():
            if file_path.is_file() and file_path.suffix.lower() in audio_extensions:
                audio_files.append(file_path)
                
        return audio_files
    
    def process_speaker_directory(self, spk_dir: Path) -> Tuple[float, int]:
        """处理单个说话人目录"""
        self.logger.info(f"处理目录: {spk_dir.name}")
        
        # 获取音频文件
        audio_files = self.get_audio_files(spk_dir)
        
        if not audio_files:
            self.logger.warning(f"目录 {spk_dir.name} 中没有找到音频文件")
            return 0.0, 0
        
        total_duration = 0.0
        valid_files = []
        
        for audio_file in audio_files:
            duration = get_audio_duration(str(audio_file))
            if duration > 0:
                total_duration += duration
                valid_files.append(audio_file.name)
            else:
                self.logger.warning(f"无法获取音频时长: {audio_file.name}")
        
        file_count = len(valid_files)
        self.logger.debug(f"目录 {spk_dir.name}: {file_count} 个文件，总时长 {total_duration:.2f} 秒")
        
        return total_duration, file_count
    
    def load_group_config(self) -> Dict[str, List[str]]:
        """加载分组配置"""
        groups = {}
        
        if not self.group_config or not Path(self.group_config).exists():
            self.logger.info("未指定分组配置文件，将按说话人ID自动分组")
            return groups
        
        try:
            with open(self.group_config, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # 解析分组配置
            current_group = None
            for line in content.split('\n'):
                line = line.strip()
                if line.startswith('=== 第') and line.endswith('组 ==='):
                    # 提取组号
                    match = re.search(r'第\s*(\d+)\s*组', line)
                    if match:
                        current_group = int(match.group(1))
                        groups[current_group] = []
                elif line and current_group is not None and ':' in line:
                    # 提取说话人ID
                    match = re.match(r'(spk\d+):', line)
                    if match:
                        speaker_id = match.group(1)
                        groups[current_group].append(speaker_id)
            
            self.logger.info(f"加载分组配置: 共 {len(groups)} 个组")
            return groups
            
        except Exception as e:
            self.logger.error(f"加载分组配置失败: {e}")
            return {}
    
    def auto_group_speakers(self, speakers: List[str]) -> Dict[int, List[str]]:
        """自动分组说话人（spk300+均匀分配到三个组）"""
        # 分离现有说话人（spk2-spk207）和新增说话人（spk300+）
        existing_speakers = []
        new_speakers = []
        
        for speaker in speakers:
            # 提取说话人ID数字
            match = re.match(r'spk(\d+)', speaker)
            if match:
                speaker_num = int(match.group(1))
                if speaker_num >= 300:
                    new_speakers.append(speaker)
                else:
                    existing_speakers.append(speaker)
        
        # 基础分组（从分组.txt中硬编码）
        groups = {
            1: ['spk81', 'spk189', 'spk168', 'spk100', 'spk202', 'spk65', 'spk76', 'spk191', 
                'spk166', 'spk70', 'spk207', 'spk16', 'spk67', 'spk160', 'spk206', 'spk17'],
            2: ['spk77', 'spk142', 'spk99', 'spk161', 'spk199', 'spk28', 'spk157', 'spk158', 
                'spk195', 'spk84', 'spk51', 'spk149', 'spk106', 'spk101', 'spk2', 'spk11'],
            3: ['spk184', 'spk156', 'spk119', 'spk36', 'spk19', 'spk50', 'spk74', 'spk144', 
                'spk181', 'spk182', 'spk90', 'spk155', 'spk204', 'spk177', 'spk40', 'spk75', 'spk97']
        }
        
        # 将新增说话人（spk300+）均匀分配到三个组
        new_speakers.sort()  # 按说话人ID排序
        for i, speaker in enumerate(new_speakers):
            group_num = (i % 3) + 1  # 轮流分配到1、2、3组
            groups[group_num].append(speaker)
            self.logger.debug(f"将 {speaker} 分配到第 {group_num} 组")
        
        # 添加实际存在的其他说话人到对应组
        for speaker in existing_speakers:
            found = False
            for group_num, group_speakers in groups.items():
                if speaker in group_speakers:
                    found = True
                    break
            if not found:
                # 如果说话人不在预定义组中，按规则分配
                match = re.match(r'spk(\d+)', speaker)
                if match:
                    speaker_num = int(match.group(1))
                    group_num = ((speaker_num - 1) % 3) + 1
                    groups[group_num].append(speaker)
        
        # 只保留实际存在的说话人
        final_groups = {}
        for group_num, group_speakers in groups.items():
            final_groups[group_num] = [s for s in group_speakers if s in speakers]
        
        return final_groups
    
    def collect_statistics(self) -> Dict:
        """收集音频统计信息"""
        self.logger.info(f"开始统计音频数据")
        self.logger.info(f"源目录: {self.source_dir}")
        
        # 检查源目录是否存在
        if not self.source_dir.exists():
            raise FileNotFoundError(f"源目录不存在: {self.source_dir}")
        
        # 获取所有spk目录
        spk_dirs = [d for d in self.source_dir.iterdir() if d.is_dir() and d.name.startswith('spk')]
        
        if not spk_dirs:
            raise ValueError(f"在 {self.source_dir} 中没有找到spk目录")
        
        self.logger.info(f"找到 {len(spk_dirs)} 个spk目录")
        
        # 统计每个说话人的数据
        for spk_dir in sorted(spk_dirs):
            try:
                speaker_id = self.extract_speaker_id(spk_dir.name)
                duration, count = self.process_speaker_directory(spk_dir)
                
                if speaker_id not in self.speaker_stats:
                    self.speaker_stats[speaker_id] = {'duration': 0.0, 'count': 0, 'sessions': []}
                
                self.speaker_stats[speaker_id]['duration'] += duration
                self.speaker_stats[speaker_id]['count'] += count
                self.speaker_stats[speaker_id]['sessions'].append({
                    'dir_name': spk_dir.name,
                    'duration': duration,
                    'count': count
                })
                
            except Exception as e:
                self.logger.error(f"处理目录 {spk_dir.name} 时出错: {e}")
        
        # 加载或生成分组
        groups = self.load_group_config()
        if not groups:
            # 自动分组
            speaker_ids = list(self.speaker_stats.keys())
            groups = self.auto_group_speakers(speaker_ids)
        
        # 计算统计信息
        total_stats = {
            'total_speakers': len(self.speaker_stats),
            'total_files': sum(stats['count'] for stats in self.speaker_stats.values()),
            'total_duration': sum(stats['duration'] for stats in self.speaker_stats.values()),
            'groups': groups,
            'speaker_stats': self.speaker_stats
        }
        
        self.logger.info("统计完成！")
        return total_stats
    
    def format_output(self, stats: Dict) -> str:
        """格式化输出"""
        lines = []
        
        # 按组输出
        for group_num in sorted(stats['groups'].keys()):
            speakers = stats['groups'][group_num]
            lines.append(f"=== 第 {group_num} 组 ===")
            
            group_total_duration = 0.0
            group_total_count = 0
            
            # 按时长排序（降序）
            speaker_data = []
            for speaker_id in speakers:
                if speaker_id in stats['speaker_stats']:
                    speaker_stats = stats['speaker_stats'][speaker_id]
                    speaker_data.append((speaker_id, speaker_stats['duration'], speaker_stats['count']))
            
            speaker_data.sort(key=lambda x: x[1], reverse=True)
            
            for speaker_id, duration, count in speaker_data:
                lines.append(f"{speaker_id}: 总时长 {duration:.2f} 秒，段数 {count}")
                group_total_duration += duration
                group_total_count += count
            
            lines.append(f"总时长：{group_total_duration:.1f} 秒")
            lines.append(f"总段数: {group_total_count}")
            lines.append("")
        
        # 总体统计
        total_hours = stats['total_duration'] / 3600
        lines.append(f"总计: {stats['total_speakers']} 个说话人")
        lines.append(f"总文件数: {stats['total_files']}")
        lines.append(f"总时长: {stats['total_duration']:.2f} 秒 ({total_hours:.2f} 小时)")
        
        return '\n'.join(lines)
    
    def save_output(self, content: str):
        """保存输出到文件"""
        if self.output_file:
            try:
                output_path = Path(self.output_file)
                output_path.parent.mkdir(parents=True, exist_ok=True)
                
                with open(output_path, 'w', encoding='utf-8') as f:
                    f.write(content)
                
                self.logger.info(f"统计结果已保存到: {output_path}")
            except Exception as e:
                self.logger.error(f"保存文件失败: {e}")
    
    def generate_statistics(self) -> str:
        """生成完整统计报告"""
        stats = self.collect_statistics()
        content = self.format_output(stats)
        
        if self.output_file:
            self.save_output(content)
        
        return content


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='音频数据统计工具')
    parser.add_argument('--source', '-s', 
                       default='data/emotion_annotation',
                       help='源目录路径 (默认: data/emotion_annotation)')
    parser.add_argument('--output', '-o',
                       help='输出文件路径 (可选)')
    parser.add_argument('--group-config', '-g',
                       help='分组配置文件路径 (可选，如data/分组.txt)')
    parser.add_argument('--verbose', '-v',
                       action='store_true',
                       help='显示详细日志')
    
    args = parser.parse_args()
    
    # 设置日志级别
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    try:
        # 创建统计器
        statistics = AudioStatistics(
            source_dir=args.source,
            output_file=args.output,
            group_config=args.group_config
        )
        
        # 生成统计报告
        content = statistics.generate_statistics()
        
        # 输出到控制台
        print("\n" + "="*60)
        print("音频数据统计报告")
        print("="*60)
        print(content)
        print("="*60)
        
    except Exception as e:
        print(f"错误: {e}")
        return 1
    
    return 0


if __name__ == '__main__':
    exit(main())

