#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
数据库分组信息更新工具
根据分组统计文件更新数据库中的speaker_groups和group_status表
"""

import os
import sqlite3
import re
import argparse
import logging
from pathlib import Path
from typing import Dict, List, Tuple
import sys

# 添加父目录到 Python 路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import Config

class DatabaseGroupUpdater:
    """数据库分组更新器"""
    
    def __init__(self, db_path: str = None):
        """
        初始化数据库分组更新器
        
        Args:
            db_path: 数据库文件路径，如果为None则使用默认路径
        """
        if db_path is None:
            self.db_path = os.path.join(Config.DATABASE_FOLDER, 'unified_emotion_system.db')
        else:
            self.db_path = db_path
            
        # 设置日志
        self.logger = logging.getLogger(__name__)
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)
        
        # 分组数据
        self.groups_data = {}  # {group_id: {'speakers': [], 'total_duration': float, 'total_segments': int}}
        
    def parse_group_file(self, group_file_path: str) -> Dict:
        """
        解析分组统计文件
        
        Args:
            group_file_path: 分组统计文件路径
            
        Returns:
            dict: 解析后的分组数据
        """
        self.logger.info(f"解析分组文件: {group_file_path}")
        
        if not os.path.exists(group_file_path):
            raise FileNotFoundError(f"分组文件不存在: {group_file_path}")
        
        groups_data = {}
        current_group = None
        
        with open(group_file_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        for line in lines:
            line = line.strip()
            
            # 解析组标题
            group_match = re.match(r'=== 第\s*(\d+)\s*组 ===', line)
            if group_match:
                current_group = int(group_match.group(1))
                groups_data[current_group] = {
                    'speakers': [],
                    'total_duration': 0.0,
                    'total_segments': 0
                }
                continue
            
            # 解析说话人信息
            if current_group and ':' in line and '总时长' in line and '段数' in line:
                speaker_match = re.match(r'(spk\d+):\s*总时长\s*([\d.]+)\s*秒，段数\s*(\d+)', line)
                if speaker_match:
                    speaker_id = speaker_match.group(1)
                    duration = float(speaker_match.group(2))
                    segment_count = int(speaker_match.group(3))
                    
                    groups_data[current_group]['speakers'].append({
                        'speaker_id': speaker_id,
                        'duration': duration,
                        'segment_count': segment_count
                    })
                    continue
            
            # 解析组总计信息
            if current_group and line.startswith('总时长：'):
                duration_match = re.match(r'总时长：([\d.]+)\s*秒', line)
                if duration_match:
                    groups_data[current_group]['total_duration'] = float(duration_match.group(1))
                    continue
            
            if current_group and line.startswith('总段数:'):
                segments_match = re.match(r'总段数:\s*(\d+)', line)
                if segments_match:
                    groups_data[current_group]['total_segments'] = int(segments_match.group(1))
                    continue
        
        self.groups_data = groups_data
        self.logger.info(f"成功解析 {len(groups_data)} 个分组，共 {sum(len(g['speakers']) for g in groups_data.values())} 个说话人")
        
        return groups_data
    
    def check_database_connection(self) -> bool:
        """检查数据库连接"""
        try:
            if not os.path.exists(self.db_path):
                self.logger.error(f"数据库文件不存在: {self.db_path}")
                return False
                
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # 检查必要的表是否存在
            required_tables = ['speaker_groups', 'group_status']
            for table in required_tables:
                cursor.execute("""
                    SELECT name FROM sqlite_master 
                    WHERE type='table' AND name=?
                """, (table,))
                
                if not cursor.fetchone():
                    self.logger.error(f"表 {table} 不存在")
                    conn.close()
                    return False
            
            conn.close()
            self.logger.info("数据库连接检查通过")
            return True
            
        except Exception as e:
            self.logger.error(f"数据库连接检查失败: {e}")
            return False
    
    def backup_database(self) -> str:
        """备份数据库"""
        from datetime import datetime
        
        backup_dir = os.path.join(os.path.dirname(self.db_path), 'backups')
        os.makedirs(backup_dir, exist_ok=True)
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_path = os.path.join(backup_dir, f'unified_emotion_system_backup_{timestamp}.db')
        
        try:
            import shutil
            shutil.copy2(self.db_path, backup_path)
            self.logger.info(f"数据库备份完成: {backup_path}")
            return backup_path
        except Exception as e:
            self.logger.error(f"数据库备份失败: {e}")
            raise
    
    def clear_existing_group_data(self, conn: sqlite3.Connection) -> None:
        """清空现有的分组数据"""
        cursor = conn.cursor()
        
        try:
            # 清空speaker_groups表
            cursor.execute("DELETE FROM speaker_groups")
            self.logger.info(f"清空speaker_groups表，删除了 {cursor.rowcount} 条记录")
            
            # 清空group_status表
            cursor.execute("DELETE FROM group_status")
            self.logger.info(f"清空group_status表，删除了 {cursor.rowcount} 条记录")
            
            conn.commit()
            
        except Exception as e:
            self.logger.error(f"清空现有数据失败: {e}")
            conn.rollback()
            raise
    
    def update_speaker_groups_table(self, conn: sqlite3.Connection) -> None:
        """更新speaker_groups表"""
        cursor = conn.cursor()
        
        try:
            for group_id, group_data in self.groups_data.items():
                for speaker_info in group_data['speakers']:
                    cursor.execute("""
                        INSERT OR REPLACE INTO speaker_groups 
                        (group_id, speaker_id, duration, segment_count, created_at)
                        VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
                    """, (
                        group_id,
                        speaker_info['speaker_id'],
                        speaker_info['duration'],
                        speaker_info['segment_count']
                    ))
            
            conn.commit()
            
            # 统计插入的记录数
            cursor.execute("SELECT COUNT(*) FROM speaker_groups")
            total_records = cursor.fetchone()[0]
            self.logger.info(f"更新speaker_groups表完成，共 {total_records} 条记录")
            
        except Exception as e:
            self.logger.error(f"更新speaker_groups表失败: {e}")
            conn.rollback()
            raise
    
    def update_group_status_table(self, conn: sqlite3.Connection) -> None:
        """更新group_status表"""
        cursor = conn.cursor()
        
        try:
            for group_id, group_data in self.groups_data.items():
                cursor.execute("""
                    INSERT OR REPLACE INTO group_status 
                    (group_id, total_duration, total_segments, assigned_count, completed_count, 
                     status, created_at, updated_at)
                    VALUES (?, ?, ?, 0, 0, 'available', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                """, (
                    group_id,
                    group_data['total_duration'],
                    group_data['total_segments']
                ))
            
            conn.commit()
            
            # 统计插入的记录数
            cursor.execute("SELECT COUNT(*) FROM group_status")
            total_records = cursor.fetchone()[0]
            self.logger.info(f"更新group_status表完成，共 {total_records} 条记录")
            
        except Exception as e:
            self.logger.error(f"更新group_status表失败: {e}")
            conn.rollback()
            raise
    
    def update_database(self, group_file_path: str, backup: bool = True) -> bool:
        """
        更新数据库分组信息
        
        Args:
            group_file_path: 分组统计文件路径
            backup: 是否备份数据库
            
        Returns:
            bool: 更新是否成功
        """
        try:
            # 检查数据库连接
            if not self.check_database_connection():
                return False
            
            # 解析分组文件
            self.parse_group_file(group_file_path)
            
            # 备份数据库
            if backup:
                self.backup_database()
            
            # 连接数据库并更新
            conn = sqlite3.connect(self.db_path)
            
            try:
                # 开始事务
                conn.execute("BEGIN TRANSACTION")
                
                # 清空现有数据
                self.clear_existing_group_data(conn)
                
                # 更新speaker_groups表
                self.update_speaker_groups_table(conn)
                
                # 更新group_status表
                self.update_group_status_table(conn)
                
                # 提交事务
                conn.commit()
                self.logger.info("数据库分组信息更新完成")
                
                return True
                
            except Exception as e:
                # 回滚事务
                conn.rollback()
                self.logger.error(f"数据库更新失败，已回滚: {e}")
                return False
                
            finally:
                conn.close()
                
        except Exception as e:
            self.logger.error(f"更新数据库时出错: {e}")
            return False
    
    def verify_update(self) -> Dict:
        """验证更新结果"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # 检查speaker_groups表
            cursor.execute("SELECT COUNT(*) FROM speaker_groups")
            speaker_groups_count = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(DISTINCT group_id) FROM speaker_groups")
            groups_count = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(DISTINCT speaker_id) FROM speaker_groups")
            speakers_count = cursor.fetchone()[0]
            
            # 检查group_status表
            cursor.execute("SELECT COUNT(*) FROM group_status")
            group_status_count = cursor.fetchone()[0]
            
            cursor.execute("SELECT SUM(total_duration), SUM(total_segments) FROM group_status")
            total_stats = cursor.fetchone()
            
            # 获取各组详细信息
            cursor.execute("""
                SELECT gs.group_id, gs.total_duration, gs.total_segments,
                       COUNT(sg.speaker_id) as speaker_count
                FROM group_status gs
                LEFT JOIN speaker_groups sg ON gs.group_id = sg.group_id
                GROUP BY gs.group_id
                ORDER BY gs.group_id
            """)
            group_details = cursor.fetchall()
            
            conn.close()
            
            verification_result = {
                'speaker_groups_count': speaker_groups_count,
                'groups_count': groups_count,
                'speakers_count': speakers_count,
                'group_status_count': group_status_count,
                'total_duration': total_stats[0] if total_stats[0] else 0,
                'total_segments': total_stats[1] if total_stats[1] else 0,
                'group_details': group_details
            }
            
            self.logger.info("验证结果:")
            self.logger.info(f"  - speaker_groups表记录数: {speaker_groups_count}")
            self.logger.info(f"  - 分组数: {groups_count}")
            self.logger.info(f"  - 说话人数: {speakers_count}")
            self.logger.info(f"  - group_status表记录数: {group_status_count}")
            self.logger.info(f"  - 总时长: {total_stats[0]:.2f}秒")
            self.logger.info(f"  - 总段数: {total_stats[1]}")
            
            for group_id, duration, segments, speaker_count in group_details:
                self.logger.info(f"  - 第{group_id}组: {speaker_count}个说话人, {duration:.1f}秒, {segments}段")
            
            return verification_result
            
        except Exception as e:
            self.logger.error(f"验证更新结果时出错: {e}")
            return {}


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='数据库分组信息更新工具')
    parser.add_argument('group_file', 
                       help='分组统计文件路径')
    parser.add_argument('--db-path', 
                       help='数据库文件路径 (可选)')
    parser.add_argument('--no-backup', 
                       action='store_true',
                       help='不备份数据库')
    parser.add_argument('--verbose', '-v',
                       action='store_true',
                       help='显示详细日志')
    
    args = parser.parse_args()
    
    # 设置日志级别
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    try:
        # 创建更新器
        updater = DatabaseGroupUpdater(db_path=args.db_path)
        
        # 执行更新
        success = updater.update_database(
            group_file_path=args.group_file,
            backup=not args.no_backup
        )
        
        if success:
            # 验证更新结果
            print("\n" + "="*60)
            print("数据库分组信息更新成功！")
            print("="*60)
            
            verification = updater.verify_update()
            if verification:
                print(f"✅ 更新完成统计:")
                print(f"   📊 共处理 {verification['groups_count']} 个分组")
                print(f"   👥 包含 {verification['speakers_count']} 个说话人")
                print(f"   📁 总计 {verification['speaker_groups_count']} 条说话人记录")
                print(f"   ⏱️  总时长 {verification['total_duration']:.2f} 秒 ({verification['total_duration']/3600:.2f} 小时)")
                print(f"   🎵 总段数 {verification['total_segments']} 段")
            
            print("="*60)
            return 0
        else:
            print("❌ 数据库更新失败")
            return 1
        
    except Exception as e:
        print(f"错误: {e}")
        return 1


if __name__ == '__main__':
    exit(main())
