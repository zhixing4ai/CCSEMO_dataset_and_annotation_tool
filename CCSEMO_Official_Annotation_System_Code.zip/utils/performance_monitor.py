# -*- coding: utf-8 -*-
"""
性能监控和诊断工具
用于监控系统性能，识别瓶颈，提供优化建议
"""

import time
import psutil
import sqlite3
import threading
import logging
from typing import Dict, List, Optional, Callable, Any
from collections import defaultdict, deque
from datetime import datetime, timedelta
import json
import functools

logger = logging.getLogger(__name__)

class PerformanceMonitor:
    """
    性能监控器
    """
    
    def __init__(self, max_history: int = 1000):
        self.max_history = max_history
        self.metrics = defaultdict(deque)
        self.slow_operations = deque(maxlen=100)
        self.db_queries = deque(maxlen=500)
        self.api_requests = deque(maxlen=500)
        self.lock = threading.Lock()
        self.start_time = time.time()
        
        # 性能阈值
        self.thresholds = {
            'slow_query_time': 1.0,  # 慢查询阈值（秒）
            'slow_api_time': 2.0,    # 慢API阈值（秒）
            'high_memory_usage': 80,  # 高内存使用率（%）
            'high_cpu_usage': 80,    # 高CPU使用率（%）
        }
    
    def record_metric(self, name: str, value: float, timestamp: Optional[float] = None):
        """
        记录性能指标
        
        Args:
            name: 指标名称
            value: 指标值
            timestamp: 时间戳，默认为当前时间
        """
        if timestamp is None:
            timestamp = time.time()
        
        with self.lock:
            self.metrics[name].append((timestamp, value))
            if len(self.metrics[name]) > self.max_history:
                self.metrics[name].popleft()
    
    def record_db_query(self, query: str, duration: float, params: Optional[tuple] = None):
        """
        记录数据库查询
        
        Args:
            query: SQL查询语句
            duration: 执行时间
            params: 查询参数
        """
        timestamp = time.time()
        query_info = {
            'timestamp': timestamp,
            'query': query,
            'duration': duration,
            'params': params,
            'is_slow': duration > self.thresholds['slow_query_time']
        }
        
        with self.lock:
            self.db_queries.append(query_info)
            
            if query_info['is_slow']:
                self.slow_operations.append({
                    'type': 'db_query',
                    'timestamp': timestamp,
                    'duration': duration,
                    'details': query_info
                })
    
    def record_api_request(self, endpoint: str, method: str, duration: float, status_code: int):
        """
        记录API请求
        
        Args:
            endpoint: API端点
            method: HTTP方法
            duration: 响应时间
            status_code: 状态码
        """
        timestamp = time.time()
        request_info = {
            'timestamp': timestamp,
            'endpoint': endpoint,
            'method': method,
            'duration': duration,
            'status_code': status_code,
            'is_slow': duration > self.thresholds['slow_api_time']
        }
        
        with self.lock:
            self.api_requests.append(request_info)
            
            if request_info['is_slow']:
                self.slow_operations.append({
                    'type': 'api_request',
                    'timestamp': timestamp,
                    'duration': duration,
                    'details': request_info
                })
    
    def get_system_metrics(self) -> Dict[str, Any]:
        """
        获取系统性能指标
        
        Returns:
            Dict[str, Any]: 系统指标
        """
        try:
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            
            return {
                'cpu_usage': cpu_percent,
                'memory_usage': memory.percent,
                'memory_available': memory.available,
                'memory_total': memory.total,
                'disk_usage': disk.percent,
                'disk_free': disk.free,
                'disk_total': disk.total,
                'timestamp': time.time()
            }
        except Exception as e:
            logger.error(f"获取系统指标失败: {e}")
            return {}
    
    def get_performance_summary(self, time_window: int = 300) -> Dict[str, Any]:
        """
        获取性能摘要
        
        Args:
            time_window: 时间窗口（秒）
            
        Returns:
            Dict[str, Any]: 性能摘要
        """
        current_time = time.time()
        cutoff_time = current_time - time_window
        
        with self.lock:
            # 分析数据库查询
            recent_queries = [q for q in self.db_queries if q['timestamp'] > cutoff_time]
            slow_queries = [q for q in recent_queries if q['is_slow']]
            
            # 分析API请求
            recent_requests = [r for r in self.api_requests if r['timestamp'] > cutoff_time]
            slow_requests = [r for r in recent_requests if r['is_slow']]
            
            # 计算统计信息
            query_stats = self._calculate_stats([q['duration'] for q in recent_queries])
            request_stats = self._calculate_stats([r['duration'] for r in recent_requests])
        
        system_metrics = self.get_system_metrics()
        
        return {
            'time_window': time_window,
            'timestamp': current_time,
            'system': system_metrics,
            'database': {
                'total_queries': len(recent_queries),
                'slow_queries': len(slow_queries),
                'slow_query_rate': len(slow_queries) / max(len(recent_queries), 1),
                'query_stats': query_stats
            },
            'api': {
                'total_requests': len(recent_requests),
                'slow_requests': len(slow_requests),
                'slow_request_rate': len(slow_requests) / max(len(recent_requests), 1),
                'request_stats': request_stats
            },
            'alerts': self._generate_alerts(system_metrics, slow_queries, slow_requests)
        }
    
    def _calculate_stats(self, values: List[float]) -> Dict[str, float]:
        """
        计算统计信息
        
        Args:
            values: 数值列表
            
        Returns:
            Dict[str, float]: 统计信息
        """
        if not values:
            return {'count': 0, 'avg': 0, 'min': 0, 'max': 0, 'p95': 0}
        
        values_sorted = sorted(values)
        count = len(values)
        
        return {
            'count': count,
            'avg': sum(values) / count,
            'min': min(values),
            'max': max(values),
            'p95': values_sorted[int(count * 0.95)] if count > 0 else 0
        }
    
    def _generate_alerts(self, system_metrics: Dict, slow_queries: List, slow_requests: List) -> List[Dict]:
        """
        生成性能警报
        
        Args:
            system_metrics: 系统指标
            slow_queries: 慢查询列表
            slow_requests: 慢请求列表
            
        Returns:
            List[Dict]: 警报列表
        """
        alerts = []
        
        # 系统资源警报
        if system_metrics.get('cpu_usage', 0) > self.thresholds['high_cpu_usage']:
            alerts.append({
                'type': 'high_cpu_usage',
                'severity': 'warning',
                'message': f"CPU使用率过高: {system_metrics['cpu_usage']:.1f}%",
                'value': system_metrics['cpu_usage']
            })
        
        if system_metrics.get('memory_usage', 0) > self.thresholds['high_memory_usage']:
            alerts.append({
                'type': 'high_memory_usage',
                'severity': 'warning',
                'message': f"内存使用率过高: {system_metrics['memory_usage']:.1f}%",
                'value': system_metrics['memory_usage']
            })
        
        # 数据库性能警报
        if len(slow_queries) > 5:
            alerts.append({
                'type': 'frequent_slow_queries',
                'severity': 'error',
                'message': f"检测到频繁的慢查询: {len(slow_queries)}个",
                'value': len(slow_queries)
            })
        
        # API性能警报
        if len(slow_requests) > 3:
            alerts.append({
                'type': 'frequent_slow_requests',
                'severity': 'error',
                'message': f"检测到频繁的慢请求: {len(slow_requests)}个",
                'value': len(slow_requests)
            })
        
        return alerts
    
    def get_optimization_suggestions(self) -> List[Dict[str, str]]:
        """
        获取优化建议
        
        Returns:
            List[Dict[str, str]]: 优化建议列表
        """
        suggestions = []
        summary = self.get_performance_summary()
        
        # 数据库优化建议
        if summary['database']['slow_query_rate'] > 0.1:
            suggestions.append({
                'category': 'database',
                'priority': 'high',
                'title': '优化数据库查询',
                'description': '检测到较多慢查询，建议启用批量更新和缓存机制',
                'action': '使用DatabaseServiceOptimized替换现有的DatabaseService'
            })
        
        # 前端优化建议
        if summary['api']['slow_request_rate'] > 0.05:
            suggestions.append({
                'category': 'frontend',
                'priority': 'medium',
                'title': '减少一致性测试检查频率',
                'description': '频繁的一致性测试检查导致API响应缓慢',
                'action': '使用MainAppOptimized中的优化策略，减少检查频率'
            })
        
        # 系统资源优化建议
        if summary['system']['memory_usage'] > 80:
            suggestions.append({
                'category': 'system',
                'priority': 'medium',
                'title': '优化内存使用',
                'description': '系统内存使用率较高，可能影响性能',
                'action': '启用缓存清理机制，调整缓存大小配置'
            })
        
        if summary['system']['cpu_usage'] > 80:
            suggestions.append({
                'category': 'system',
                'priority': 'high',
                'title': '优化CPU使用',
                'description': 'CPU使用率过高，建议优化计算密集型操作',
                'action': '启用异步处理，使用批量操作减少计算负载'
            })
        
        return suggestions
    
    def export_report(self, filepath: str):
        """
        导出性能报告
        
        Args:
            filepath: 报告文件路径
        """
        report = {
            'generated_at': datetime.now().isoformat(),
            'monitor_uptime': time.time() - self.start_time,
            'summary': self.get_performance_summary(),
            'suggestions': self.get_optimization_suggestions(),
            'slow_operations': list(self.slow_operations),
            'thresholds': self.thresholds
        }
        
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(report, f, indent=2, ensure_ascii=False)
            logger.info(f"性能报告已导出到: {filepath}")
        except Exception as e:
            logger.error(f"导出性能报告失败: {e}")

def performance_timer(monitor: PerformanceMonitor, operation_type: str = 'operation'):
    """
    性能计时装饰器
    
    Args:
        monitor: 性能监控器实例
        operation_type: 操作类型
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            start_time = time.time()
            try:
                result = func(*args, **kwargs)
                duration = time.time() - start_time
                monitor.record_metric(f"{operation_type}_{func.__name__}_duration", duration)
                return result
            except Exception as e:
                duration = time.time() - start_time
                monitor.record_metric(f"{operation_type}_{func.__name__}_error_duration", duration)
                raise
        return wrapper
    return decorator

def db_query_timer(monitor: PerformanceMonitor):
    """
    数据库查询计时装饰器
    
    Args:
        monitor: 性能监控器实例
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            start_time = time.time()
            try:
                result = func(*args, **kwargs)
                duration = time.time() - start_time
                
                # 尝试从参数中提取查询信息
                query = "unknown"
                if args and isinstance(args[0], str):
                    query = args[0][:100]  # 截取前100个字符
                
                monitor.record_db_query(query, duration, args[1:] if len(args) > 1 else None)
                return result
            except Exception as e:
                duration = time.time() - start_time
                monitor.record_db_query("error_query", duration)
                raise
        return wrapper
    return decorator

# 全局性能监控器实例
global_monitor = PerformanceMonitor()