#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
文件夹清理工具
删除不带-1-1后缀的spk目录，保留带-1-1后缀的目录
用于清理normal1_segments目录中的重复文件夹
"""

import os
import shutil
import argparse
import logging
from pathlib import Path
from typing import List, Tuple
import re

class FolderCleanup:
    """文件夹清理器"""
    
    def __init__(self, target_dir: str, dry_run: bool = True):
        """
        初始化清理器
        
        Args:
            target_dir: 目标目录路径
            dry_run: 是否为试运行模式（不实际删除）
        """
        self.target_dir = Path(target_dir)
        self.dry_run = dry_run
        
        # 设置日志
        self.logger = logging.getLogger(__name__)
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)
        
        # 统计信息
        self.folders_to_delete = []
        self.folders_to_keep = []
        
    def identify_folders(self) -> Tuple[List[Path], List[Path]]:
        """识别需要删除和保留的文件夹"""
        self.logger.info(f"扫描目录: {self.target_dir}")
        
        if not self.target_dir.exists():
            raise FileNotFoundError(f"目标目录不存在: {self.target_dir}")
        
        to_delete = []
        to_keep = []
        
        # 遍历目录中的所有文件夹
        for item in self.target_dir.iterdir():
            if item.is_dir():
                dir_name = item.name
                
                # 检查是否是spk目录
                if re.match(r'^spk\d+$', dir_name):
                    # 不带后缀的spk目录，需要删除
                    to_delete.append(item)
                    self.logger.debug(f"标记删除: {dir_name}")
                elif re.match(r'^spk\d+-\d+-\d+$', dir_name):
                    # 带后缀的spk目录，需要保留
                    to_keep.append(item)
                    self.logger.debug(f"标记保留: {dir_name}")
                else:
                    # 其他目录，保留
                    to_keep.append(item)
                    self.logger.debug(f"其他目录保留: {dir_name}")
        
        self.folders_to_delete = to_delete
        self.folders_to_keep = to_keep
        
        return to_delete, to_keep
    
    def verify_safety(self) -> bool:
        """验证删除操作的安全性"""
        self.logger.info("验证删除操作的安全性...")
        
        # 确保对于每个要删除的spkXXX目录，都有对应的spkXXX-1-1目录
        delete_speakers = set()
        keep_speakers = set()
        
        for folder in self.folders_to_delete:
            match = re.match(r'^spk(\d+)$', folder.name)
            if match:
                speaker_id = match.group(1)
                delete_speakers.add(speaker_id)
        
        for folder in self.folders_to_keep:
            match = re.match(r'^spk(\d+)-\d+-\d+$', folder.name)
            if match:
                speaker_id = match.group(1)
                keep_speakers.add(speaker_id)
        
        # 检查是否每个要删除的目录都有对应的保留目录
        orphaned_deletes = delete_speakers - keep_speakers
        if orphaned_deletes:
            self.logger.warning(f"警告：以下说话人只有要删除的目录，没有对应的保留目录: {sorted(orphaned_deletes)}")
            return False
        
        self.logger.info("安全性验证通过")
        return True
    
    def preview_cleanup(self):
        """预览清理操作"""
        to_delete, to_keep = self.identify_folders()
        
        print("\n" + "="*60)
        print("文件夹清理预览")
        print("="*60)
        
        print(f"\n将要删除的文件夹 ({len(to_delete)} 个):")
        for folder in sorted(to_delete):
            print(f"  - {folder.name}")
        
        print(f"\n将要保留的文件夹 ({len(to_keep)} 个):")
        for folder in sorted(to_keep):
            print(f"  - {folder.name}")
        
        # 计算磁盘空间
        total_size = 0
        for folder in to_delete:
            try:
                folder_size = sum(f.stat().st_size for f in folder.rglob('*') if f.is_file())
                total_size += folder_size
            except Exception as e:
                self.logger.warning(f"无法计算文件夹大小 {folder.name}: {e}")
        
        total_size_mb = total_size / (1024 * 1024)
        print(f"\n预计释放磁盘空间: {total_size_mb:.2f} MB")
        
        print("="*60)
    
    def execute_cleanup(self) -> int:
        """执行清理操作"""
        if self.dry_run:
            self.logger.info("试运行模式：不会实际删除文件")
            self.preview_cleanup()
            return 0
        
        to_delete, to_keep = self.identify_folders()
        
        if not self.verify_safety():
            self.logger.error("安全性验证失败，停止删除操作")
            return 1
        
        deleted_count = 0
        failed_count = 0
        
        self.logger.info(f"开始删除 {len(to_delete)} 个文件夹...")
        
        for folder in to_delete:
            try:
                self.logger.info(f"删除文件夹: {folder.name}")
                shutil.rmtree(folder)
                deleted_count += 1
            except Exception as e:
                self.logger.error(f"删除文件夹失败 {folder.name}: {e}")
                failed_count += 1
        
        self.logger.info(f"清理完成！删除成功: {deleted_count}, 删除失败: {failed_count}")
        return 0 if failed_count == 0 else 1
    
    def interactive_cleanup(self) -> int:
        """交互式清理"""
        self.preview_cleanup()
        
        if not self.verify_safety():
            print("\n❌ 安全性验证失败！")
            return 1
        
        print("\n⚠️  警告：此操作将永久删除上述文件夹！")
        
        while True:
            response = input("\n是否继续执行删除操作？(yes/no): ").strip().lower()
            if response in ['yes', 'y']:
                self.dry_run = False
                return self.execute_cleanup()
            elif response in ['no', 'n']:
                print("取消删除操作")
                return 0
            else:
                print("请输入 'yes' 或 'no'")


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='文件夹清理工具')
    parser.add_argument('target_dir', 
                       help='目标目录路径')
    parser.add_argument('--dry-run', 
                       action='store_true',
                       help='试运行模式，不实际删除文件')
    parser.add_argument('--force', 
                       action='store_true',
                       help='强制执行，不询问确认')
    parser.add_argument('--verbose', '-v',
                       action='store_true',
                       help='显示详细日志')
    
    args = parser.parse_args()
    
    # 设置日志级别
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    try:
        # 创建清理器
        cleanup = FolderCleanup(
            target_dir=args.target_dir,
            dry_run=args.dry_run
        )
        
        # 执行清理
        if args.force and not args.dry_run:
            return cleanup.execute_cleanup()
        else:
            return cleanup.interactive_cleanup()
        
    except Exception as e:
        print(f"错误: {e}")
        return 1


if __name__ == '__main__':
    exit(main())
