#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
保存性能测试工具
用于测试标注保存操作的性能，识别瓶颈并提供优化建议
"""

import time
import sqlite3
import threading
import statistics
from typing import List, Dict, Any
import json
import os
import sys
from datetime import datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]

if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# 导入项目模块
try:
    from services.database_service import DatabaseService
    from services.label_service import LabelService
except ImportError as e:
    print(f"❌ 导入模块失败: {e}")
    print("请确保在项目根目录运行此脚本")
    exit(1)

class SavePerformanceTester:
    """
    保存性能测试器
    """
    
    def __init__(self):
        self.db_service = DatabaseService()
        self.label_service = LabelService()
        self.test_results = []
        self.test_data = self._generate_test_data()
    
    def _generate_test_data(self) -> List[Dict[str, Any]]:
        """
        生成测试数据
        
        Returns:
            List[Dict[str, Any]]: 测试标注数据列表
        """
        test_data = []
        
        # 生成不同类型的测试数据
        for i in range(50):
            test_data.append({
                'audio_file': f'test_audio_{i:03d}.wav',
                'username': f'test_user_{i % 5}',  # 5个测试用户
                'speaker': 'A' if i % 2 == 0 else 'B',
                'valence': round(-1 + (i % 21) * 0.1, 1),  # -1.0 到 1.0
                'arousal': round(-1 + ((i * 3) % 21) * 0.1, 1),
                'dominance': round(-1 + ((i * 7) % 21) * 0.1, 1),
                'emotion_category': ['anger', 'joy', 'sadness', 'fear', 'neutral'][i % 5],
                'emotion_intensity': (i % 5) + 1
            })
        
        return test_data
    
    def test_single_save_performance(self, label_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        测试单次保存性能
        
        Args:
            label_data: 标注数据
            
        Returns:
            Dict[str, Any]: 测试结果
        """
        start_time = time.time()
        
        try:
            # 执行保存操作 - 传递正确的参数
            speaker = label_data.get('speaker', 'A')
            audio_file_path = label_data.get('audio_file', 'test_audio.wav')
            result = self.label_service.save_label(label_data, speaker, audio_file_path)
            
            end_time = time.time()
            duration = end_time - start_time
            
            # LabelService.save_label 返回布尔值，不是字典
            success = bool(result)
            
            return {
                'success': success,
                'duration': duration,
                'timestamp': start_time,
                'label_data': label_data,
                'error': None if success else 'Save operation returned False'
            }
            
        except Exception as e:
            end_time = time.time()
            duration = end_time - start_time
            
            return {
                'success': False,
                'duration': duration,
                'timestamp': start_time,
                'label_data': label_data,
                'error': str(e)
            }
    
    def test_batch_save_performance(self, batch_size: int = 10) -> List[Dict[str, Any]]:
        """
        测试批量保存性能
        
        Args:
            batch_size: 批量大小
            
        Returns:
            List[Dict[str, Any]]: 批量测试结果
        """
        results = []
        
        print(f"🔄 开始批量保存测试 (批量大小: {batch_size})...")
        
        for i in range(0, len(self.test_data), batch_size):
            batch = self.test_data[i:i + batch_size]
            batch_start = time.time()
            
            batch_results = []
            for label_data in batch:
                result = self.test_single_save_performance(label_data)
                batch_results.append(result)
            
            batch_end = time.time()
            batch_duration = batch_end - batch_start
            
            results.extend(batch_results)
            
            print(f"   批次 {i//batch_size + 1}: {len(batch)} 条记录, 耗时 {batch_duration:.3f}s")
        
        return results
    
    def test_concurrent_save_performance(self, thread_count: int = 3) -> List[Dict[str, Any]]:
        """
        测试并发保存性能
        
        Args:
            thread_count: 线程数量
            
        Returns:
            List[Dict[str, Any]]: 并发测试结果
        """
        results = []
        results_lock = threading.Lock()
        
        def worker_thread(thread_id: int, data_chunk: List[Dict[str, Any]]):
            thread_results = []
            for label_data in data_chunk:
                result = self.test_single_save_performance(label_data)
                result['thread_id'] = thread_id
                thread_results.append(result)
            
            with results_lock:
                results.extend(thread_results)
        
        print(f"🔄 开始并发保存测试 ({thread_count} 个线程)...")
        
        # 分割数据给不同线程
        chunk_size = len(self.test_data) // thread_count
        threads = []
        
        start_time = time.time()
        
        for i in range(thread_count):
            start_idx = i * chunk_size
            end_idx = start_idx + chunk_size if i < thread_count - 1 else len(self.test_data)
            data_chunk = self.test_data[start_idx:end_idx]
            
            thread = threading.Thread(
                target=worker_thread,
                args=(i, data_chunk)
            )
            threads.append(thread)
            thread.start()
        
        # 等待所有线程完成
        for thread in threads:
            thread.join()
        
        end_time = time.time()
        total_duration = end_time - start_time
        
        print(f"   并发测试完成: {len(results)} 条记录, 总耗时 {total_duration:.3f}s")
        
        return results
    
    def analyze_results(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        分析测试结果
        
        Args:
            results: 测试结果列表
            
        Returns:
            Dict[str, Any]: 分析报告
        """
        if not results:
            return {'error': '没有测试结果可分析'}
        
        # 提取成功的测试结果
        successful_results = [r for r in results if r['success']]
        failed_results = [r for r in results if not r['success']]
        
        if not successful_results:
            return {
                'total_tests': len(results),
                'success_count': 0,
                'failure_count': len(failed_results),
                'success_rate': 0.0,
                'errors': [r['error'] for r in failed_results]
            }
        
        # 计算性能统计
        durations = [r['duration'] for r in successful_results]
        
        analysis = {
            'total_tests': len(results),
            'success_count': len(successful_results),
            'failure_count': len(failed_results),
            'success_rate': len(successful_results) / len(results) * 100,
            'performance': {
                'avg_duration': statistics.mean(durations),
                'min_duration': min(durations),
                'max_duration': max(durations),
                'median_duration': statistics.median(durations),
                'std_deviation': statistics.stdev(durations) if len(durations) > 1 else 0,
                'p95_duration': sorted(durations)[int(len(durations) * 0.95)] if len(durations) > 1 else durations[0]
            }
        }
        
        # 识别慢操作
        slow_threshold = analysis['performance']['avg_duration'] * 2
        slow_operations = [r for r in successful_results if r['duration'] > slow_threshold]
        
        if slow_operations:
            analysis['slow_operations'] = {
                'count': len(slow_operations),
                'threshold': slow_threshold,
                'examples': slow_operations[:5]  # 前5个慢操作示例
            }
        
        # 错误分析
        if failed_results:
            error_types = {}
            for result in failed_results:
                error = result['error']
                error_types[error] = error_types.get(error, 0) + 1
            
            analysis['error_analysis'] = {
                'error_types': error_types,
                'most_common_error': max(error_types.items(), key=lambda x: x[1])
            }
        
        return analysis
    
    def generate_recommendations(self, analysis: Dict[str, Any]) -> List[str]:
        """
        基于分析结果生成优化建议
        
        Args:
            analysis: 分析结果
            
        Returns:
            List[str]: 优化建议列表
        """
        recommendations = []
        
        if 'performance' not in analysis:
            return ['无法生成建议：缺少性能数据']
        
        perf = analysis['performance']
        
        # 基于平均响应时间的建议
        if perf['avg_duration'] > 1.0:
            recommendations.append(
                f"⚠️  平均保存时间过长 ({perf['avg_duration']:.3f}s)，建议启用批量处理优化"
            )
        
        if perf['avg_duration'] > 0.5:
            recommendations.append(
                "💡 建议使用 DatabaseServiceOptimized 替换现有的 DatabaseService"
            )
        
        # 基于响应时间变化的建议
        if perf['std_deviation'] > perf['avg_duration'] * 0.5:
            recommendations.append(
                "📊 响应时间波动较大，建议检查数据库连接和查询优化"
            )
        
        # 基于P95响应时间的建议
        if perf['p95_duration'] > perf['avg_duration'] * 3:
            recommendations.append(
                "🔍 存在异常慢的操作，建议启用性能监控定位具体原因"
            )
        
        # 基于成功率的建议
        if analysis['success_rate'] < 95:
            recommendations.append(
                f"❌ 保存成功率较低 ({analysis['success_rate']:.1f}%)，需要检查错误原因"
            )
        
        # 基于慢操作的建议
        if 'slow_operations' in analysis:
            slow_count = analysis['slow_operations']['count']
            total_count = analysis['success_count']
            slow_rate = slow_count / total_count * 100
            
            if slow_rate > 10:
                recommendations.append(
                    f"🐌 {slow_rate:.1f}% 的操作响应缓慢，强烈建议部署性能优化方案"
                )
        
        # 通用优化建议
        if perf['avg_duration'] > 0.2:
            recommendations.extend([
                "🚀 建议实施以下优化策略：",
                "   1. 启用前端一致性检查优化 (main_optimized.js)",
                "   2. 启用后端批量处理 (database_service_optimized.py)",
                "   3. 配置性能参数 (performance_config.py)",
                "   4. 启用性能监控 (performance_monitor.py)"
            ])
        
        if not recommendations:
            recommendations.append("✅ 当前性能表现良好，无需特殊优化")
        
        return recommendations
    
    def run_comprehensive_test(self) -> Dict[str, Any]:
        """
        运行综合性能测试
        
        Returns:
            Dict[str, Any]: 完整测试报告
        """
        print("🧪 开始综合性能测试...")
        print("=" * 50)
        
        # 清理之前的测试数据
        self._cleanup_test_data()
        
        # 1. 单次保存测试
        print("\n1️⃣ 单次保存性能测试")
        single_results = []
        for i, label_data in enumerate(self.test_data[:10]):
            result = self.test_single_save_performance(label_data)
            single_results.append(result)
            if (i + 1) % 5 == 0:
                print(f"   完成 {i + 1}/10 次测试")
        
        # 2. 批量保存测试
        print("\n2️⃣ 批量保存性能测试")
        batch_results = self.test_batch_save_performance(batch_size=5)
        
        # 3. 并发保存测试
        print("\n3️⃣ 并发保存性能测试")
        concurrent_results = self.test_concurrent_save_performance(thread_count=2)
        
        # 分析结果
        print("\n📊 分析测试结果...")
        
        single_analysis = self.analyze_results(single_results)
        batch_analysis = self.analyze_results(batch_results)
        concurrent_analysis = self.analyze_results(concurrent_results)
        
        # 生成建议
        recommendations = self.generate_recommendations(batch_analysis)
        
        # 生成完整报告
        report = {
            'test_timestamp': datetime.now().isoformat(),
            'test_environment': {
                'database_path': DatabaseService.get_db_path(),
                'test_data_count': len(self.test_data)
            },
            'results': {
                'single_save': single_analysis,
                'batch_save': batch_analysis,
                'concurrent_save': concurrent_analysis
            },
            'recommendations': recommendations
        }
        
        return report
    
    def _cleanup_test_data(self):
        """
        清理测试数据
        """
        try:
            conn = sqlite3.connect(DatabaseService.get_db_path())
            cursor = conn.cursor()
            
            # 删除测试数据
            cursor.execute("""
                DELETE FROM emotion_labels 
                WHERE audio_file LIKE 'test_audio_%' 
                   OR username LIKE 'test_user_%'
            """)
            
            conn.commit()
            conn.close()
            
            print("🧹 清理测试数据完成")
            
        except Exception as e:
            print(f"⚠️  清理测试数据失败: {e}")
    
    def print_report(self, report: Dict[str, Any]):
        """
        打印测试报告
        
        Args:
            report: 测试报告
        """
        print("\n" + "=" * 60)
        print("                    性能测试报告")
        print("=" * 60)
        
        print(f"\n📅 测试时间: {report['test_timestamp']}")
        print(f"📁 数据库路径: {report['test_environment']['database_path']}")
        print(f"📊 测试数据量: {report['test_environment']['test_data_count']} 条")
        
        # 打印各项测试结果
        for test_type, analysis in report['results'].items():
            print(f"\n🔍 {test_type.replace('_', ' ').title()} 测试结果:")
            
            if 'error' in analysis:
                print(f"   ❌ {analysis['error']}")
                continue
            
            print(f"   总测试数: {analysis['total_tests']}")
            print(f"   成功数: {analysis['success_count']}")
            print(f"   失败数: {analysis['failure_count']}")
            print(f"   成功率: {analysis['success_rate']:.1f}%")
            
            if 'performance' in analysis:
                perf = analysis['performance']
                print(f"   平均响应时间: {perf['avg_duration']:.3f}s")
                print(f"   最快响应时间: {perf['min_duration']:.3f}s")
                print(f"   最慢响应时间: {perf['max_duration']:.3f}s")
                print(f"   P95响应时间: {perf['p95_duration']:.3f}s")
        
        # 打印优化建议
        print("\n💡 优化建议:")
        for recommendation in report['recommendations']:
            print(f"   {recommendation}")
        
        print("\n" + "=" * 60)

def main():
    """
    主函数
    """
    try:
        # 检查数据库连接
        database_path = DatabaseService.get_db_path()
        if not os.path.exists(database_path):
            print(f"❌ 数据库文件不存在: {database_path}")
            return
        
        # 创建测试器并运行测试
        tester = SavePerformanceTester()
        report = tester.run_comprehensive_test()
        
        # 打印报告
        tester.print_report(report)
        
        # 保存报告到文件
        report_file = PROJECT_ROOT / f"performance_test_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
        
        print(f"\n📄 详细报告已保存到: {report_file}")
        
        # 清理测试数据
        tester._cleanup_test_data()
        
    except Exception as e:
        print(f"❌ 测试执行失败: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
