#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
检查数据库中用户名为'Wormee'且spk为'spk65'的记录
"""

import sqlite3
import os
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATABASE_PATH = PROJECT_ROOT / "database" / "unified_emotion_system.db"

def check_user_records():
    """检查Wormee用户的记录"""
    db_path = DATABASE_PATH
    
    if not os.path.exists(db_path):
        print(f"数据库文件不存在: {db_path}")
        return
    
    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row  # 使结果可以通过列名访问
        cursor = conn.cursor()
        
        print("=== Database structure check ===")
        # 检查emotion_labels表结构
        cursor.execute('PRAGMA table_info(emotion_labels);')
        columns = cursor.fetchall()
        print("emotion_labels表字段:")
        for col in columns:
            print(f"  {col[1]} ({col[2]})")
        
        print("\n=== 检查'Wormee'用户的所有记录 ===")
        # 检查Wormee用户的所有记录
        cursor.execute("""
            SELECT speaker, COUNT(*) as count 
            FROM emotion_labels 
            WHERE username = 'Wormee' 
            GROUP BY speaker 
            ORDER BY count DESC
        """)
        gx_records = cursor.fetchall()
        
        if gx_records:
            print(f"找到'Wormee'用户的记录，按speaker分组:")
            total_gx = 0
            for record in gx_records:
                print(f"  speaker: {record['speaker']}, 记录数: {record['count']}")
                total_gx += record['count']
            print(f"'Wormee'用户总记录数: {total_gx}")
        else:
            print("未找到'Wormee'用户的任何记录")
        
        print("\n=== 检查目标speaker的记录 ===")
        # 检查目标speaker的记录
        target_speaker = 'spk65'
        cursor.execute("""
            SELECT speaker, username, COUNT(*) as count 
            FROM emotion_labels 
            WHERE speaker = 'spk65' 
            GROUP BY speaker, username 
            ORDER BY speaker, count DESC
        """)
        speaker_records = cursor.fetchall()
        
        if speaker_records:
            print("找到目标speaker的记录，按speaker和username分组:")
            for record in speaker_records:
                print(f"  speaker: {record['speaker']}, username: {record['username']}, 记录数: {record['count']}")
        else:
            print("未找到目标speaker的任何记录")
        
        print("\n=== 检查目标记录 ===")
        # 检查目标记录：username='Wormee' AND speaker='spk65'
        cursor.execute("""
            SELECT speaker, COUNT(*) as count 
            FROM emotion_labels 
            WHERE username = 'Wormee' AND speaker = 'spk65'
            GROUP BY speaker
            ORDER BY speaker
        """)
        target_records = cursor.fetchall()
        
        total_target_count = 0
        if target_records:
            print(f"username='Wormee'的目标speaker记录:")
            for record in target_records:
                print(f"  speaker {record['speaker']}: {record['count']} 条记录")
                total_target_count += record['count']
            print(f"总计: {total_target_count} 条记录")
        else:
            print(f"username='Wormee'的目标speaker记录数: 0")
        
        if total_target_count > 0:
            # 显示具体记录
            cursor.execute("""
                SELECT id, audio_file, speaker, username, v_value, a_value, 
                       emotion_type, discrete_emotion, patient_status, timestamp
                FROM emotion_labels 
                WHERE username = 'Wormee' AND speaker = 'spk65'
                ORDER BY speaker, timestamp DESC
            """)
            detailed_records = cursor.fetchall()
            print("\n具体记录:")
            for i, record in enumerate(detailed_records, 1):
                print(f"  {i}. ID: {record['id']}, 音频: {record['audio_file']}, "
                      f"Speaker: {record['speaker']}, 时间: {record['timestamp']}")
        
        print("\n=== 检查目标speaker的存在情况 ===")
        # 检查目标speaker是否存在于数据库中
        cursor.execute("""
            SELECT DISTINCT speaker 
            FROM emotion_labels 
            WHERE speaker = 'spk65'
            ORDER BY speaker
        """)
        existing_speakers = cursor.fetchall()
        
        if existing_speakers:
            print("数据库中存在的目标speaker:")
            for speaker in existing_speakers:
                print(f"  {speaker['speaker']}")
        else:
            print("数据库中未找到任何目标speaker")
        
        print("\n=== 检查包含'Wormee'的username ===")
        # 检查是否有包含'Wormee'的username
        cursor.execute("""
            SELECT DISTINCT username 
            FROM emotion_labels 
            WHERE username LIKE '%Wormee%'
            ORDER BY username
        """)
        similar_usernames = cursor.fetchall()
        
        if similar_usernames:
            print("找到包含'Wormee'的username:")
            for username in similar_usernames:
                print(f"  {username['username']}")
        else:
            print("未找到包含'Wormee'的username")
        
        # 如果找到Wormee用户，显示几个示例记录
        if gx_records:
            print("\n=== 'Wormee'用户的示例记录 ===")
            cursor.execute("""
                SELECT id, audio_file, speaker, v_value, a_value, 
                       emotion_type, discrete_emotion, timestamp
                FROM emotion_labels 
                WHERE username = 'Wormee'
                ORDER BY timestamp DESC
                LIMIT 5
            """)
            sample_records = cursor.fetchall()
            for i, record in enumerate(sample_records, 1):
                print(f"  {i}. ID: {record['id']}, 音频: {record['audio_file']}, "
                      f"Speaker: {record['speaker']}, 时间: {record['timestamp']}")
        
        conn.close()
        
    except Exception as e:
        print(f"检查数据库时发生错误: {e}")
        if 'conn' in locals():
            conn.close()

if __name__ == "__main__":
    check_user_records()
