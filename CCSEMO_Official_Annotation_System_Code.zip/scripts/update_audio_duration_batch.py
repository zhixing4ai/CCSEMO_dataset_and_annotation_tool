#!/usr/bin/env python3
"""
批量更新音频时长脚本
用于异步更新数据库中音频时长为0的记录
"""

import os
import sys
import sqlite3
from pathlib import Path

# 添加项目根目录到Python路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from utils.audio_utils import get_audio_duration
from services.audio_service import AudioService
from services.database_service import DatabaseService

def update_missing_audio_durations():
    """
    批量更新缺失的音频时长
    """
    print("开始批量更新音频时长...")
    
    # 获取数据库路径
    database_path = DatabaseService.get_db_path()
    conn = sqlite3.connect(database_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    try:
        # 查找音频时长为0或NULL的记录
        cursor.execute("""
            SELECT DISTINCT audio_file, speaker 
            FROM emotion_labels 
            WHERE audio_duration IS NULL OR audio_duration = 0
        """)
        
        records = cursor.fetchall()
        print(f"找到 {len(records)} 条需要更新音频时长的记录")
        
        updated_count = 0
        for record in records:
            audio_file = record['audio_file']
            speaker = record['speaker']
            
            # 查找音频文件路径
            file_path, actual_speaker = AudioService.find_audio_file(speaker, audio_file)
            
            if file_path and os.path.exists(file_path):
                # 计算音频时长
                duration = get_audio_duration(file_path)
                
                if duration > 0:
                    # 更新数据库中的音频时长
                    cursor.execute("""
                        UPDATE emotion_labels 
                        SET audio_duration = ?
                        WHERE audio_file = ? AND speaker = ? AND (audio_duration IS NULL OR audio_duration = 0)
                    """, (duration, audio_file, speaker))
                    
                    updated_count += cursor.rowcount
                    print(f"更新 {audio_file} ({speaker}) 音频时长: {duration:.2f}秒")
                else:
                    print(f"警告: 无法获取 {audio_file} ({speaker}) 的音频时长")
            else:
                print(f"警告: 找不到音频文件 {audio_file} ({speaker})")
        
        conn.commit()
        print(f"批量更新完成，共更新 {updated_count} 条记录")
        
    except Exception as e:
        print(f"批量更新音频时长失败: {e}")
        conn.rollback()
    finally:
        conn.close()

def update_group_progress():
    """
    批量更新分组进度
    """
    print("开始批量更新分组进度...")
    
    # 获取数据库路径
    database_path = DatabaseService.get_db_path()
    conn = sqlite3.connect(database_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    try:
        # 更新每个用户的标注进度
        cursor.execute("""
            UPDATE group_assignments 
            SET progress_count = (
                SELECT COUNT(*) 
                FROM emotion_labels el 
                WHERE el.username = group_assignments.username
                AND (el.v_value IS NOT NULL OR el.discrete_emotion IS NOT NULL)
            ),
            status = CASE 
                WHEN (
                    SELECT COUNT(*) 
                    FROM emotion_labels el 
                    WHERE el.username = group_assignments.username
                    AND (el.v_value IS NOT NULL OR el.discrete_emotion IS NOT NULL)
                ) >= total_segments THEN 'completed'
                ELSE 'in_progress'
            END
            WHERE EXISTS (
                SELECT 1 FROM emotion_labels el 
                WHERE el.username = group_assignments.username
            )
        """)
        
        updated_count = cursor.rowcount
        conn.commit()
        print(f"批量更新分组进度完成，共更新 {updated_count} 条记录")
        
    except Exception as e:
        print(f"批量更新分组进度失败: {e}")
        conn.rollback()
    finally:
        conn.close()

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="批量更新音频时长和分组进度")
    parser.add_argument("--duration", action="store_true", help="更新音频时长")
    parser.add_argument("--progress", action="store_true", help="更新分组进度")
    parser.add_argument("--all", action="store_true", help="更新所有数据")
    
    args = parser.parse_args()
    
    if args.all or (not args.duration and not args.progress):
        update_missing_audio_durations()
        update_group_progress()
    else:
        if args.duration:
            update_missing_audio_durations()
        if args.progress:
            update_group_progress()
    
    print("批量更新任务完成")