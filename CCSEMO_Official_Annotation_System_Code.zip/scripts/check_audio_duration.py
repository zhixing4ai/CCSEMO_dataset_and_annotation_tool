#!/usr/bin/env python3
"""
检查音频文件时长是否都小于3秒
"""

import os
import wave
import contextlib
from pathlib import Path
import librosa
import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[1]

def get_audio_duration(file_path):
    """
    获取音频文件的时长（秒）
    支持多种音频格式
    """
    try:
        # 使用librosa获取音频时长
        duration = librosa.get_duration(path=file_path)
        return duration
    except Exception as e:
        print(f"无法读取文件 {file_path}: {e}")
        return None

def check_audio_files_in_directory(directory_path, max_duration=3.0):
    """
    检查目录中所有音频文件的时长
    """
    audio_extensions = {'.wav', '.mp3', '.flac', '.m4a', '.aac', '.ogg'}
    long_files = []
    total_files = 0
    processed_files = 0
    
    print(f"正在检查目录: {directory_path}")
    print(f"最大允许时长: {max_duration}秒")
    print("-" * 50)
    
    # 遍历所有子目录
    for root, dirs, files in os.walk(directory_path):
        for file in files:
            file_path = Path(root) / file
            if file_path.suffix.lower() in audio_extensions:
                total_files += 1
                duration = get_audio_duration(str(file_path))
                
                if duration is not None:
                    processed_files += 1
                    if duration > max_duration:
                        long_files.append((str(file_path), duration))
                        print(f"⚠️  文件过长: {file_path} - {duration:.2f}秒")
                    else:
                        print(f"✅ 文件正常: {file_path} - {duration:.2f}秒")
                else:
                    print(f"❌ 无法读取: {file_path}")
    
    print("-" * 50)
    print(f"总计检查文件数: {total_files}")
    print(f"成功处理文件数: {processed_files}")
    print(f"超过{max_duration}秒的文件数: {len(long_files)}")
    
    if long_files:
        print(f"\n超过{max_duration}秒的文件列表:")
        for file_path, duration in long_files:
            print(f"  {file_path} - {duration:.2f}秒")
        return False
    else:
        print(f"\n🎉 所有音频文件都小于{max_duration}秒！")
        return True

if __name__ == "__main__":
    # 检查data目录下的音频文件
    data_dir = PROJECT_ROOT / "data"
    
    if not data_dir.exists():
        print("data目录不存在！")
        exit(1)
    
    # 检查short_audio目录
    short_audio_dir = data_dir / "short_audio"
    if short_audio_dir.exists():
        print("=" * 60)
        print("检查 short_audio 目录")
        print("=" * 60)
        check_audio_files_in_directory(short_audio_dir)
        print()
    
    # 检查extracted_audio目录
    extracted_audio_dir = data_dir / "extracted_audio"
    if extracted_audio_dir.exists():
        print("=" * 60)
        print("检查 extracted_audio 目录")
        print("=" * 60)
        check_audio_files_in_directory(extracted_audio_dir)
        print()
    
    # 检查其他可能包含音频的目录
    other_audio_dirs = [
        "emotion_annotation",
        "已完成标注的数据",
        "consistency_test",
        "second_consistency_test",
        "volume_test",
        "test_examples"
    ]
    
    for dir_name in other_audio_dirs:
        dir_path = data_dir / dir_name
        if dir_path.exists():
            print("=" * 60)
            print(f"检查 {dir_name} 目录")
            print("=" * 60)
            check_audio_files_in_directory(dir_path)
            print()

