#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
调试用户分组功能脚本
用于诊断"数据库更新失败"的具体原因
"""

import os
import sys
import traceback
from datetime import datetime
from pathlib import Path

# 添加项目根目录到Python路径
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from services.admin_service import AdminService
from services.database_service import DatabaseService
from config import Config

def test_database_connection():
    """测试数据库连接"""
    print("=== 测试数据库连接 ===")
    try:
        db_service = DatabaseService()
        
        # 测试统一数据库连接
        print("测试统一数据库连接...")
        with db_service.get_unified_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = cursor.fetchall()
            print(f"统一数据库表数量: {len(tables)}")
            for table in tables:
                print(f"  - {table[0]}")
        
        # 测试用户数据库连接
        print("\n测试用户数据库连接...")
        with db_service.get_users_connection() as users_conn:
            users_cursor = users_conn.cursor()
            users_cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = users_cursor.fetchall()
            print(f"用户数据库表数量: {len(tables)}")
            for table in tables:
                print(f"  - {table[0]}")
        
        print("✓ 数据库连接测试成功")
        return True
        
    except Exception as e:
        print(f"✗ 数据库连接测试失败: {e}")
        traceback.print_exc()
        return False

def test_user_exists():
    """测试用户是否存在"""
    print("\n=== 测试用户数据 ===")
    try:
        db_service = DatabaseService()
        
        with db_service.get_unified_connection() as conn:
            cursor = conn.cursor()
            
            # 查看所有用户
            cursor.execute("SELECT wechat_name, group_id FROM users LIMIT 10")
            users = cursor.fetchall()
            print(f"用户总数（前10个）:")
            for user in users:
                print(f"  - 用户名: {user[0]}, 分组ID: {user[1]}")
            
            if users:
                test_username = users[0][0]
                print(f"\n将使用用户 '{test_username}' 进行测试")
                return test_username
            else:
                print("✗ 没有找到任何用户")
                return None
                
    except Exception as e:
        print(f"✗ 查询用户数据失败: {e}")
        traceback.print_exc()
        return None

def test_group_data():
    """测试分组数据"""
    print("\n=== 测试分组数据 ===")
    try:
        db_service = DatabaseService()
        
        with db_service.get_unified_connection() as conn:
            cursor = conn.cursor()
            
            # 查看分组状态表
            cursor.execute("SELECT group_id, total_segments, assigned_count, status FROM group_status")
            groups = cursor.fetchall()
            print(f"分组状态数据:")
            for group in groups:
                print(f"  - 分组ID: {group[0]}, 总段数: {group[1]}, 已分配: {group[2]}, 状态: {group[3]}")
            
            # 查看分组分配表
            cursor.execute("SELECT group_id, username, status FROM group_assignments LIMIT 10")
            assignments = cursor.fetchall()
            print(f"\n分组分配数据（前10个）:")
            for assignment in assignments:
                print(f"  - 分组ID: {assignment[0]}, 用户: {assignment[1]}, 状态: {assignment[2]}")
                
            return len(groups) > 0
                
    except Exception as e:
        print(f"✗ 查询分组数据失败: {e}")
        traceback.print_exc()
        return False

def test_user_group_update(username, target_group):
    """测试用户分组更新功能"""
    print(f"\n=== 测试用户分组更新: {username} -> {target_group} ===")
    try:
        admin_service = AdminService()
        
        # 获取用户当前分组
        db_service = DatabaseService()
        with db_service.get_unified_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT group_id FROM users WHERE wechat_name = ?", (username,))
            current_group = cursor.fetchone()
            print(f"用户当前分组: {current_group[0] if current_group else None}")
        
        # 测试分组更新（带验证）
        print(f"尝试更新用户分组到: {target_group}")
        success, error_message = admin_service.update_user_group_with_validation(username, target_group)
        
        if success:
            print("✓ 用户分组更新成功")
            
            # 验证更新结果
            with db_service.get_unified_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT group_id FROM users WHERE wechat_name = ?", (username,))
                new_group = cursor.fetchone()
                print(f"更新后分组: {new_group[0] if new_group else None}")
                
                # 检查group_assignments表
                cursor.execute("SELECT group_id, status FROM group_assignments WHERE username = ?", (username,))
                assignment = cursor.fetchone()
                if assignment:
                    print(f"分组分配记录: 分组ID={assignment[0]}, 状态={assignment[1]}")
                else:
                    print("未找到分组分配记录")
            
            return True
        else:
            print(f"✗ 用户分组更新失败: {error_message}")
            
            # 直接测试底层的 update_user_group 方法来获取更详细的错误
            print("\n尝试直接调用 update_user_group 方法...")
            try:
                group_text = None
                if target_group:
                    if target_group.startswith('group') and target_group[5:].isdigit():
                        group_id = int(target_group[5:])
                        group_text = f"第{group_id}组"
                    else:
                        group_text = target_group
                
                direct_success = admin_service.update_user_group(username, group_text)
                print(f"直接调用结果: {direct_success}")
            except Exception as direct_e:
                print(f"直接调用异常: {direct_e}")
                traceback.print_exc()
            
            return False
            
    except Exception as e:
        print(f"✗ 用户分组更新异常: {e}")
        traceback.print_exc()
        return False

def main():
    """主函数"""
    print("开始诊断用户分组功能...")
    print(f"时间: {datetime.now()}")
    print(f"数据库路径: {Config.DATABASE_FOLDER}")
    
    # 1. 测试数据库连接
    if not test_database_connection():
        print("\n数据库连接失败，无法继续测试")
        return
    
    # 2. 测试用户数据
    test_username = test_user_exists()
    if not test_username:
        print("\n没有可用的测试用户，无法继续测试")
        return
    
    # 3. 测试分组数据
    if not test_group_data():
        print("\n分组数据不完整，可能影响分组功能")
    
    # 4. 测试用户分组更新功能
    test_cases = [
        "group1",  # 测试group1格式
        "第1组",   # 测试中文格式
        "group2",  # 测试group2格式
        None       # 测试移除分组
    ]
    
    for target_group in test_cases:
        success = test_user_group_update(test_username, target_group)
        if not success:
            print(f"\n在测试 '{target_group}' 时发现问题")
            break
        print("\n" + "="*50)
    
    print("\n诊断完成")

if __name__ == "__main__":
    main()
