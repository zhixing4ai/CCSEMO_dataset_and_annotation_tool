#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
分析spk300前后数据统计脚本
计算spk300之前的数据和spk300及其之后的数据的段数和时间统计
"""

import os
import re
import sys
import argparse
from typing import Dict, List, Tuple, NamedTuple

class SpeakerData(NamedTuple):
    """说话人数据结构"""
    speaker_id: str
    duration: float
    segments: int
    group: int

class GroupStats(NamedTuple):
    """组统计数据结构"""
    total_duration: float
    total_segments: int
    speaker_count: int

def parse_grouping_file(file_path: str) -> Tuple[List[SpeakerData], Dict[int, GroupStats]]:
    """
    解析分组文件
    
    Args:
        file_path: 分组文件路径
        
    Returns:
        tuple: (说话人数据列表, 组统计字典)
    """
    speakers = []
    group_stats = {}
    current_group = 0
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
            
        # 按组分割内容
        group_sections = re.split(r'=== 第 (\d+) 组 ===', content)
        
        for i in range(1, len(group_sections), 2):
            group_num = int(group_sections[i])
            group_content = group_sections[i + 1]
            
            # 解析说话人数据
            speaker_pattern = r'(spk\d+): 总时长 ([\d.]+) 秒，段数 (\d+)'
            speaker_matches = re.findall(speaker_pattern, group_content)
            
            group_duration = 0
            group_segments = 0
            
            for speaker_id, duration_str, segments_str in speaker_matches:
                duration = float(duration_str)
                segments = int(segments_str)
                
                speakers.append(SpeakerData(
                    speaker_id=speaker_id,
                    duration=duration,
                    segments=segments,
                    group=group_num
                ))
                
                group_duration += duration
                group_segments += segments
            
            group_stats[group_num] = GroupStats(
                total_duration=group_duration,
                total_segments=group_segments,
                speaker_count=len(speaker_matches)
            )
            
    except FileNotFoundError:
        print(f"错误: 找不到文件 {file_path}")
        sys.exit(1)
    except Exception as e:
        print(f"错误: 解析文件时出现问题 - {e}")
        sys.exit(1)
    
    return speakers, group_stats

def analyze_spk300_split(speakers: List[SpeakerData]) -> Tuple[List[SpeakerData], List[SpeakerData]]:
    """
    按spk300分割数据
    
    Args:
        speakers: 说话人数据列表
        
    Returns:
        tuple: (spk300之前的数据, spk300及其之后的数据)
    """
    # 按说话人ID的数字部分排序
    def extract_speaker_num(speaker_id: str) -> int:
        match = re.search(r'spk(\d+)', speaker_id)
        return int(match.group(1)) if match else 0
    
    sorted_speakers = sorted(speakers, key=lambda x: extract_speaker_num(x.speaker_id))
    
    # 找到spk300的位置
    spk300_index = -1
    for i, speaker in enumerate(sorted_speakers):
        if extract_speaker_num(speaker.speaker_id) >= 300:
            spk300_index = i
            break
    
    if spk300_index == -1:
        # 没有找到spk300或更高的编号
        return sorted_speakers, []
    
    before_spk300 = sorted_speakers[:spk300_index]
    spk300_and_after = sorted_speakers[spk300_index:]
    
    return before_spk300, spk300_and_after

def calculate_statistics(speakers: List[SpeakerData]) -> Tuple[float, int, int]:
    """
    计算统计数据
    
    Args:
        speakers: 说话人数据列表
        
    Returns:
        tuple: (总时长, 总段数, 说话人数量)
    """
    if not speakers:
        return 0.0, 0, 0
    
    total_duration = sum(speaker.duration for speaker in speakers)
    total_segments = sum(speaker.segments for speaker in speakers)
    speaker_count = len(speakers)
    
    return total_duration, total_segments, speaker_count

def format_duration(seconds: float) -> str:
    """
    格式化时长显示
    
    Args:
        seconds: 秒数
        
    Returns:
        str: 格式化的时长字符串
    """
    hours = seconds / 3600
    return f"{seconds:.2f} 秒 ({hours:.2f} 小时)"

def print_speaker_list(speakers: List[SpeakerData], title: str):
    """
    打印说话人列表
    
    Args:
        speakers: 说话人数据列表
        title: 标题
    """
    print(f"\n{title}")
    print("=" * 50)
    
    if not speakers:
        print("无数据")
        return
    
    # 按组分组显示
    speakers_by_group = {}
    for speaker in speakers:
        if speaker.group not in speakers_by_group:
            speakers_by_group[speaker.group] = []
        speakers_by_group[speaker.group].append(speaker)
    
    for group_num in sorted(speakers_by_group.keys()):
        group_speakers = speakers_by_group[group_num]
        print(f"\n第 {group_num} 组:")
        
        for speaker in group_speakers:
            print(f"  {speaker.speaker_id}: 总时长 {speaker.duration:.2f} 秒，段数 {speaker.segments}")

def main():
    """主函数"""
    # 获取分组文件路径
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    grouping_file = os.path.join(project_root, 'data', '分组.txt')
    
    print("spk300数据分割分析")
    print("=" * 60)
    
    # 解析分组文件
    print(f"正在解析文件: {grouping_file}")
    speakers, group_stats = parse_grouping_file(grouping_file)
    
    print(f"总共解析到 {len(speakers)} 个说话人")
    
    # 按spk300分割数据
    before_spk300, spk300_and_after = analyze_spk300_split(speakers)
    
    # 计算统计数据
    before_duration, before_segments, before_count = calculate_statistics(before_spk300)
    after_duration, after_segments, after_count = calculate_statistics(spk300_and_after)
    total_duration, total_segments, total_count = calculate_statistics(speakers)
    
    # 输出结果
    print("\n" + "=" * 60)
    print("分析结果")
    print("=" * 60)
    
    print(f"\n【spk300之前的数据】")
    print(f"说话人数量: {before_count}")
    print(f"总时长: {format_duration(before_duration)}")
    print(f"总段数: {before_segments}")
    if before_count > 0:
        print(f"平均时长: {before_duration/before_count:.2f} 秒/人")
        print(f"平均段数: {before_segments/before_count:.2f} 段/人")
    
    print(f"\n【spk300及其之后的数据】")
    print(f"说话人数量: {after_count}")
    print(f"总时长: {format_duration(after_duration)}")
    print(f"总段数: {after_segments}")
    if after_count > 0:
        print(f"平均时长: {after_duration/after_count:.2f} 秒/人")
        print(f"平均段数: {after_segments/after_count:.2f} 段/人")
    
    print(f"\n【总计】")
    print(f"说话人数量: {total_count}")
    print(f"总时长: {format_duration(total_duration)}")
    print(f"总段数: {total_segments}")
    
    # 百分比统计
    print(f"\n【比例分析】")
    if total_duration > 0:
        before_duration_pct = (before_duration / total_duration) * 100
        after_duration_pct = (after_duration / total_duration) * 100
        print(f"spk300之前时长占比: {before_duration_pct:.2f}%")
        print(f"spk300及之后时长占比: {after_duration_pct:.2f}%")
    
    if total_segments > 0:
        before_segments_pct = (before_segments / total_segments) * 100
        after_segments_pct = (after_segments / total_segments) * 100
        print(f"spk300之前段数占比: {before_segments_pct:.2f}%")
        print(f"spk300及之后段数占比: {after_segments_pct:.2f}%")
    
    # 详细列表（可选）
    print_detail = input("\n是否显示详细的说话人列表? (y/N): ").lower().strip()
    if print_detail == 'y':
        print_speaker_list(before_spk300, "spk300之前的说话人")
        print_speaker_list(spk300_and_after, "spk300及其之后的说话人")
    
    # 保存结果到文件
    save_to_file = input("\n是否保存结果到文件? (y/N): ").lower().strip()
    if save_to_file == 'y':
        output_file = os.path.join(project_root, 'data', 'spk300_split_analysis.txt')
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write("spk300数据分割分析结果\n")
            f.write("=" * 60 + "\n")
            f.write(f"分析时间: {os.popen('date').read().strip()}\n")
            f.write(f"源文件: {grouping_file}\n\n")
            
            f.write("【spk300之前的数据】\n")
            f.write(f"说话人数量: {before_count}\n")
            f.write(f"总时长: {format_duration(before_duration)}\n")
            f.write(f"总段数: {before_segments}\n")
            if before_count > 0:
                f.write(f"平均时长: {before_duration/before_count:.2f} 秒/人\n")
                f.write(f"平均段数: {before_segments/before_count:.2f} 段/人\n")
            
            f.write(f"\n【spk300及其之后的数据】\n")
            f.write(f"说话人数量: {after_count}\n")
            f.write(f"总时长: {format_duration(after_duration)}\n")
            f.write(f"总段数: {after_segments}\n")
            if after_count > 0:
                f.write(f"平均时长: {after_duration/after_count:.2f} 秒/人\n")
                f.write(f"平均段数: {after_segments/after_count:.2f} 段/人\n")
            
            f.write(f"\n【总计】\n")
            f.write(f"说话人数量: {total_count}\n")
            f.write(f"总时长: {format_duration(total_duration)}\n")
            f.write(f"总段数: {total_segments}\n")
            
            f.write(f"\n【比例分析】\n")
            if total_duration > 0:
                before_duration_pct = (before_duration / total_duration) * 100
                after_duration_pct = (after_duration / total_duration) * 100
                f.write(f"spk300之前时长占比: {before_duration_pct:.2f}%\n")
                f.write(f"spk300及之后时长占比: {after_duration_pct:.2f}%\n")
            
            if total_segments > 0:
                before_segments_pct = (before_segments / total_segments) * 100
                after_segments_pct = (after_segments / total_segments) * 100
                f.write(f"spk300之前段数占比: {before_segments_pct:.2f}%\n")
                f.write(f"spk300及之后段数占比: {after_segments_pct:.2f}%\n")
        
        print(f"结果已保存到: {output_file}")

if __name__ == "__main__":
    main()
