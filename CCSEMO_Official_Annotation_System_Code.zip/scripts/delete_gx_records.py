#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
安全删除数据库中用户名为'Wormee'且speaker为'spk65'的记录
包含事务处理、错误处理和回滚机制
"""

import sqlite3
import os
import sys
from datetime import datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATABASE_PATH = PROJECT_ROOT / "database" / "unified_emotion_system.db"

def check_user_records():
    """检查并列出所有'Wormee'用户的记录"""
    db_path = DATABASE_PATH
    
    if not os.path.exists(db_path):
        print(f"数据库文件不存在: {db_path}")
        return False
    
    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        print("=== 当前'Wormee'用户记录统计 ===")
        cursor.execute("""
            SELECT speaker, COUNT(*) as count 
            FROM emotion_labels 
            WHERE username = 'Wormee' 
            GROUP BY speaker 
            ORDER BY count DESC
        """)
        records = cursor.fetchall()
        
        if records:
            total = 0
            for record in records:
                print(f"  speaker: {record['speaker']}, 记录数: {record['count']}")
                total += record['count']
            print(f"'Wormee'用户总记录数: {total}")
        else:
            print("未找到'Wormee'用户的任何记录")
        
        conn.close()
        return True
        
    except Exception as e:
        print(f"检查记录时发生错误: {e}")
        if 'conn' in locals():
            conn.close()
        return False

def preview_target_records():
    """预览将要删除的记录"""
    db_path = DATABASE_PATH
    
    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        print("\n=== 预览将要删除的记录 ===")
        cursor.execute("""
            SELECT id, audio_file, speaker, username, v_value, a_value, 
                   emotion_type, discrete_emotion, patient_status, timestamp
            FROM emotion_labels 
            WHERE username = 'Wormee' AND speaker = 'spk65'
            ORDER BY speaker, timestamp
        """)
        
        target_records = cursor.fetchall()
        
        if target_records:
            print(f"找到 {len(target_records)} 条符合删除条件的记录:")
            print("ID\t音频文件\t\t\tSpeaker\t时间")
            print("-" * 80)
            for record in target_records:
                print(f"{record['id']}\t{record['audio_file'][:30]:<30}\t{record['speaker']}\t{record['timestamp']}")
            
            # 按speaker分组统计
            cursor.execute("""
                SELECT speaker, COUNT(*) as count 
                FROM emotion_labels 
                WHERE username = 'Wormee' AND speaker = 'spk65'
                GROUP BY speaker
            """)
            stats = cursor.fetchall()
            print("\n删除统计:")
            for stat in stats:
                print(f"  {stat['speaker']}: {stat['count']} 条记录")
        else:
            print("未找到符合删除条件的记录")
        
        conn.close()
        return len(target_records) if target_records else 0
        
    except Exception as e:
        print(f"预览记录时发生错误: {e}")
        if 'conn' in locals():
            conn.close()
        return 0

def delete_user_records():
    """安全删除记录，使用事务处理"""
    db_path = DATABASE_PATH
    
    try:
        # 使用事务模式连接数据库
        conn = sqlite3.connect(db_path, timeout=30.0)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        print("\n=== 开始删除操作 ===")
        print("使用事务处理确保数据安全...")
        
        # 开始事务
        cursor.execute("BEGIN IMMEDIATE;")
        
        try:
            # 再次确认要删除的记录数量
            cursor.execute("""
                SELECT COUNT(*) as count 
                FROM emotion_labels 
                WHERE username = 'Wormee' AND speaker = 'spk65'
            """)
            count_before = cursor.fetchone()['count']
            
            if count_before == 0:
                print("没有找到符合条件的记录，取消删除操作")
                conn.rollback()
                return False
            
            print(f"准备删除 {count_before} 条记录...")
            
            # 执行删除操作
            cursor.execute("""
                DELETE FROM emotion_labels 
                WHERE username = 'Wormee' AND speaker = 'spk65'
            """)
            
            deleted_count = cursor.rowcount
            print(f"删除了 {deleted_count} 条记录")
            
            # 验证删除结果
            cursor.execute("""
                SELECT COUNT(*) as count 
                FROM emotion_labels 
                WHERE username = 'Wormee' AND speaker = 'spk65'
            """)
            count_after = cursor.fetchone()['count']
            
            if count_after == 0 and deleted_count == count_before:
                # 删除成功，提交事务
                conn.commit()
                print("✅ 删除操作成功完成！")
                print(f"已删除 {deleted_count} 条记录")
                
                # 显示删除后的统计
                print("\n=== 删除后'Wormee'用户记录统计 ===")
                cursor.execute("""
                    SELECT speaker, COUNT(*) as count 
                    FROM emotion_labels 
                    WHERE username = 'Wormee' 
                    GROUP BY speaker 
                    ORDER BY count DESC
                """)
                remaining_records = cursor.fetchall()
                
                if remaining_records:
                    total_remaining = 0
                    for record in remaining_records:
                        print(f"  speaker: {record['speaker']}, 记录数: {record['count']}")
                        total_remaining += record['count']
                    print(f"'Wormee'用户剩余总记录数: {total_remaining}")
                else:
                    print("'Wormee'用户已无任何记录")
                
                return True
            else:
                # 删除结果异常，回滚事务
                conn.rollback()
                print(f"❌ 删除结果异常，已回滚事务")
                print(f"预期删除: {count_before}, 实际删除: {deleted_count}, 剩余: {count_after}")
                return False
                
        except Exception as e:
            # 发生错误，回滚事务
            conn.rollback()
            print(f"❌ 删除过程中发生错误，已回滚事务: {e}")
            return False
            
    except Exception as e:
        print(f"❌ 数据库连接或操作失败: {e}")
        return False
    finally:
        if 'conn' in locals():
            conn.close()

def main():
    """主函数"""
    print("=== 安全删除'Wormee'用户记录脚本 ===")
    print(f"执行时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("目标: 删除username='Wormee'且speaker为'spk65'的记录")
    print("="*60)
    
    # 1. 检查当前记录
    if not check_user_records():
        print("❌ 无法访问数据库，退出")
        return
    
    # 2. 预览要删除的记录
    target_count = preview_target_records()
    
    if target_count == 0:
        print("\n没有找到符合删除条件的记录，操作结束")
        return
    
    # 3. 确认删除
    print(f"\n⚠️  即将删除 {target_count} 条记录")
    print("这个操作不可逆，请确认是否继续")
    
    while True:
        confirm = input("请输入 'YES' 确认删除，或 'NO' 取消操作: ").strip()
        if confirm == 'YES':
            break
        elif confirm == 'NO':
            print("操作已取消")
            return
        else:
            print("请输入 'YES' 或 'NO'")
    
    # 4. 执行删除
    success = delete_user_records()
    
    if success:
        print("\n🎉 删除操作成功完成！")
    else:
        print("\n❌ 删除操作失败或被取消")

if __name__ == "__main__":
    main()
