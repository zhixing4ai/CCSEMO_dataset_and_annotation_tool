#!/usr/bin/env python3
"""
管理员批量更新工具
提供简单的命令行界面来执行批量更新任务
"""

import os
import sys
import subprocess
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
SCRIPTS_DIR = PROJECT_ROOT / "scripts"

if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

def print_banner():
    print("="*60)
    print("          情感标注系统 - 管理员批量更新工具")
    print("="*60)
    print()

def print_menu():
    print("请选择要执行的操作:")
    print("1. 更新音频时长 (修复时长为0的记录)")
    print("2. 更新分组进度 (同步标注进度统计)")
    print("3. 更新所有数据 (音频时长 + 分组进度)")
    print("4. 查看当前数据状态")
    print("5. 性能测试")
    print("0. 退出")
    print()

def run_batch_script(args):
    """
    运行批量更新脚本
    """
    script_path = SCRIPTS_DIR / "update_audio_duration_batch.py"
    
    if not script_path.exists():
        print(f"❌ 错误: 找不到批量更新脚本 {script_path}")
        return False
    
    try:
        cmd = [sys.executable, str(script_path)] + args
        print(f"执行命令: {' '.join(cmd)}")
        print("-" * 40)
        
        result = subprocess.run(cmd, capture_output=True, text=True, cwd=PROJECT_ROOT)
        
        if result.stdout:
            print(result.stdout)
        
        if result.stderr:
            print("错误输出:")
            print(result.stderr)
        
        if result.returncode == 0:
            print("✅ 操作完成")
            return True
        else:
            print(f"❌ 操作失败，退出码: {result.returncode}")
            return False
            
    except Exception as e:
        print(f"❌ 执行失败: {e}")
        return False

def check_data_status():
    """
    检查当前数据状态
    """
    print("正在检查数据状态...")
    print("-" * 40)
    
    try:
        import sqlite3
        from config import Config
        
        database_path = Path(Config.DATABASE_FOLDER) / "unified_emotion_system.db"
        conn = sqlite3.connect(database_path)
        cursor = conn.cursor()
        
        # 检查音频时长为0的记录数量
        cursor.execute("""
            SELECT COUNT(*) FROM emotion_labels 
            WHERE audio_duration IS NULL OR audio_duration = 0
        """)
        zero_duration_count = cursor.fetchone()[0]
        
        # 检查总标注记录数
        cursor.execute("SELECT COUNT(*) FROM emotion_labels")
        total_labels = cursor.fetchone()[0]
        
        # 检查分组分配数量
        cursor.execute("SELECT COUNT(*) FROM group_assignments")
        total_assignments = cursor.fetchone()[0]
        
        # 检查已完成的分组数量
        cursor.execute("SELECT COUNT(*) FROM group_assignments WHERE status = 'completed'")
        completed_assignments = cursor.fetchone()[0]
        
        conn.close()
        
        print(f"📊 数据状态报告:")
        print(f"   总标注记录数: {total_labels}")
        print(f"   音频时长为0的记录: {zero_duration_count}")
        print(f"   音频时长完整率: {((total_labels - zero_duration_count) / total_labels * 100):.1f}%" if total_labels > 0 else "   音频时长完整率: 0%")
        print(f"   总分组分配数: {total_assignments}")
        print(f"   已完成分组数: {completed_assignments}")
        print(f"   分组完成率: {(completed_assignments / total_assignments * 100):.1f}%" if total_assignments > 0 else "   分组完成率: 0%")
        
        if zero_duration_count > 0:
            print(f"\n⚠️  建议执行音频时长更新来修复 {zero_duration_count} 条记录")
        
        return True
        
    except Exception as e:
        print(f"❌ 检查数据状态失败: {e}")
        return False

def run_performance_test():
    """
    运行性能测试
    """
    print("正在运行性能测试...")
    print("-" * 40)
    
    try:
        result = subprocess.run(
            [sys.executable, str(SCRIPTS_DIR / "test_save_performance.py")],
            capture_output=True,
            text=True,
            cwd=PROJECT_ROOT,
        )
        
        if result.stdout:
            print(result.stdout)
        
        if result.stderr:
            print("测试过程中的警告或错误:")
            print(result.stderr)
        
        return result.returncode == 0
        
    except Exception as e:
        print(f"❌ 性能测试失败: {e}")
        return False

def main():
    print_banner()
    
    while True:
        print_menu()
        
        try:
            choice = input("请输入选项 (0-5): ").strip()
            print()
            
            if choice == "0":
                print("👋 再见!")
                break
            elif choice == "1":
                print("🔄 开始更新音频时长...")
                run_batch_script(["--duration"])
            elif choice == "2":
                print("🔄 开始更新分组进度...")
                run_batch_script(["--progress"])
            elif choice == "3":
                print("🔄 开始更新所有数据...")
                run_batch_script(["--all"])
            elif choice == "4":
                check_data_status()
            elif choice == "5":
                run_performance_test()
            else:
                print("❌ 无效选项，请重新选择")
            
            print()
            input("按回车键继续...")
            print()
            
        except KeyboardInterrupt:
            print("\n\n👋 用户中断，退出程序")
            break
        except Exception as e:
            print(f"❌ 发生错误: {e}")
            print()
            input("按回车键继续...")
            print()

if __name__ == "__main__":
    # 确保在正确的目录中运行
    os.chdir(PROJECT_ROOT)
    
    main()
