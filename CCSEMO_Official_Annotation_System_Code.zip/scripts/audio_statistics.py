#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
音频文件统计脚本
统计指定文件夹中的音频文件数量和总时长
"""

import os
import wave
import contextlib
from pathlib import Path
import time
from datetime import timedelta

PROJECT_ROOT = Path(__file__).resolve().parents[1]

def get_wav_duration(wav_file_path):
    """
    获取WAV文件的时长（秒）
    """
    try:
        with contextlib.closing(wave.open(wav_file_path, 'r')) as f:
            frames = f.getnframes()
            rate = f.getframerate()
            duration = frames / float(rate)
            return duration
    except Exception as e:
        print(f"警告: 无法读取文件 {wav_file_path}: {e}")
        return 0

def format_duration(seconds):
    """
    将秒数格式化为可读的时间格式
    """
    td = timedelta(seconds=int(seconds))
    hours, remainder = divmod(td.seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    
    if td.days > 0:
        return f"{td.days}天 {hours}小时 {minutes}分钟 {seconds}秒"
    elif hours > 0:
        return f"{hours}小时 {minutes}分钟 {seconds}秒"
    elif minutes > 0:
        return f"{minutes}分钟 {seconds}秒"
    else:
        return f"{seconds}秒"

def count_audio_files_and_duration(folder_path):
    """
    统计文件夹中的音频文件数量和总时长
    """
    folder_path = Path(folder_path)
    
    if not folder_path.exists():
        print(f"错误: 文件夹 {folder_path} 不存在")
        return 0, 0
    
    print(f"\n正在统计文件夹: {folder_path}")
    print("=" * 60)
    
    total_files = 0
    total_duration = 0
    processed_folders = 0
    
    # 遍历所有子文件夹
    for subfolder in folder_path.iterdir():
        if subfolder.is_dir():
            processed_folders += 1
            folder_files = 0
            folder_duration = 0
            
            # 遍历子文件夹中的所有WAV文件
            for wav_file in subfolder.glob('*.wav'):
                duration = get_wav_duration(wav_file)
                total_files += 1
                total_duration += duration
                folder_files += 1
                folder_duration += duration
            
            if folder_files > 0:
                print(f"{subfolder.name}: {folder_files} 个文件, {format_duration(folder_duration)}")
            
            # 每处理100个文件夹显示一次进度
            if processed_folders % 100 == 0:
                print(f"已处理 {processed_folders} 个文件夹...")
    
    print("\n" + "=" * 60)
    print(f"统计完成!")
    print(f"总文件夹数: {processed_folders}")
    print(f"总音频文件数: {total_files}")
    print(f"总时长: {format_duration(total_duration)}")
    print(f"总时长(秒): {total_duration:.2f}")
    
    return total_files, total_duration

def main():
    """
    主函数
    """
    print("音频文件统计工具")
    print("=" * 60)
    
    # 定义两个文件夹路径
    folder1 = PROJECT_ROOT / "data" / "emotion_annotation"
    folder2 = PROJECT_ROOT / "data" / "emotion_annotation_copy"
    
    start_time = time.time()
    
    # 统计第一个文件夹
    print("\n📁 统计 emotion_annotation 文件夹")
    files1, duration1 = count_audio_files_and_duration(folder1)
    
    # 统计第二个文件夹
    print("\n📁 统计 emotion_annotation_copy 文件夹")
    files2, duration2 = count_audio_files_and_duration(folder2)
    
    # 总结对比
    print("\n" + "=" * 80)
    print("📊 统计结果汇总")
    print("=" * 80)
    print(f"emotion_annotation:      {files1:,} 个文件, {format_duration(duration1)}")
    print(f"emotion_annotation_copy: {files2:,} 个文件, {format_duration(duration2)}")
    print("-" * 80)
    print(f"总计:                   {files1 + files2:,} 个文件, {format_duration(duration1 + duration2)}")
    
    # 差异分析
    if files1 != files2:
        diff_files = abs(files1 - files2)
        diff_duration = abs(duration1 - duration2)
        print(f"\n⚠️  差异分析:")
        print(f"文件数量差异: {diff_files} 个文件")
        print(f"时长差异: {format_duration(diff_duration)}")
        
        if files1 > files2:
            print(f"emotion_annotation 比 emotion_annotation_copy 多 {diff_files} 个文件")
        else:
            print(f"emotion_annotation_copy 比 emotion_annotation 多 {diff_files} 个文件")
    else:
        print(f"\n✅ 两个文件夹的音频文件数量相同")
    
    end_time = time.time()
    print(f"\n⏱️  统计耗时: {end_time - start_time:.2f} 秒")

if __name__ == "__main__":
    main()
