#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
统一数据库管理器
管理合并后的统一数据库的所有操作
"""

import os
import sys
import sqlite3
import json
import time
import random
from datetime import datetime
from typing import List, Dict, Optional, Tuple, Any
from contextlib import contextmanager
from threading import Lock, RLock

# 添加项目根目录到Python路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import Config

class UnifiedDatabaseManager:
    """
    统一数据库管理器
    管理所有数据库操作的统一接口
    """
    
    def __init__(self):
        """初始化统一数据库管理器"""
        self.database_folder = Config.DATABASE_FOLDER
        self.db_path = os.path.join(self.database_folder, 'unified_emotion_system.db')
        
        # 使用RLock支持重入锁
        self.write_lock = RLock()
        self.read_lock = RLock()
        
        # 重试配置
        self.max_retries = 3
        self.retry_delay = 0.1
        
        # 确保数据库文件夹存在
        os.makedirs(self.database_folder, exist_ok=True)
        
        # 初始化数据库
        self.init_database()
    

    def _create_connection(self) -> sqlite3.Connection:
        """创建数据库连接"""
        conn = sqlite3.connect(self.db_path, timeout=30.0, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        # 启用WAL模式以提高并发性
        conn.execute('PRAGMA journal_mode=WAL;')
        conn.execute('PRAGMA synchronous=NORMAL;')
        conn.execute('PRAGMA cache_size=10000;')
        conn.execute('PRAGMA temp_store=memory;')
        conn.execute('PRAGMA mmap_size=268435456;')  # 256MB
        return conn
    
    @contextmanager
    def get_connection(self, timeout=10.0):
        """获取数据库连接（上下文管理器）"""
        # 直接创建新连接，避免连接池共享导致的并发问题
        conn = self._create_connection()
        
        try:
            yield conn
        finally:
            if conn:
                try:
                    conn.close()
                except:
                    pass
    
    def get_connection_legacy(self) -> sqlite3.Connection:
        """获取数据库连接（兼容旧代码）"""
        conn = sqlite3.connect(self.db_path, timeout=30.0)
        conn.row_factory = sqlite3.Row
        conn.execute('PRAGMA journal_mode=WAL;')
        conn.execute('PRAGMA synchronous=NORMAL;')
        return conn
    
    def get_users_connection(self):
        """获取用户数据库连接（统一数据库中的用户表）"""
        return self.get_connection()
    
    def init_database(self):
        """初始化数据库，创建所有必要的表"""
        if not os.path.exists(self.db_path):
            print(f"创建统一数据库: {self.db_path}")
            
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                # 创建所有表
                self._create_all_tables(cursor)
                
                conn.commit()
    
    def _create_all_tables(self, cursor):
        """创建所有数据库表"""
        # 情感标注相关表
        self._create_emotion_labels_tables(cursor)
        
        # 用户相关表
        self._create_users_tables(cursor)
        
        # 管理员相关表
        self._create_admins_tables(cursor)
        
        # 分组分配相关表
        self._create_group_assignment_tables(cursor)
        
        # 创建索引和触发器
        self._create_indexes_and_triggers(cursor)
    
    def _create_emotion_labels_tables(self, cursor):
        """创建情感标注相关表"""
        # 主要标注数据表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS emotion_labels (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                audio_file TEXT NOT NULL,
                speaker TEXT NOT NULL,
                username TEXT NOT NULL,
                v_value REAL,
                a_value REAL,
                emotion_type TEXT,
                discrete_emotion TEXT,
                patient_status TEXT,
                audio_duration REAL DEFAULT 0,
                play_count INTEGER DEFAULT 0,
                va_complete BOOLEAN DEFAULT FALSE,
                discrete_complete BOOLEAN DEFAULT FALSE,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(audio_file, speaker, username)
            )
        ''')
        
        # 一致性测试结果表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS consistency_test_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL,
                audio_file TEXT NOT NULL,
                v_value REAL,
                a_value REAL,
                emotion_type TEXT,
                discrete_emotion TEXT,
                patient_status TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(username, audio_file)
            )
        ''')
        
        # 第二次一致性测试结果表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS second_consistency_test_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL,
                audio_file TEXT NOT NULL,
                v_value REAL,
                a_value REAL,
                emotion_type TEXT,
                discrete_emotion TEXT,
                patient_status TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(username, audio_file)
            )
        ''')
        
        # 标准答案表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS standard_answers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                audio_file TEXT NOT NULL UNIQUE,
                v_value REAL,
                a_value REAL,
                emotion_type TEXT,
                discrete_emotion TEXT,
                patient_status TEXT,
                audio_duration REAL,
                created_by TEXT DEFAULT '系统导入',
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # 第二次一致性测试标准答案表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS second_consistency_standard_answers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                audio_file TEXT NOT NULL UNIQUE,
                v_value REAL,
                a_value REAL,
                emotion_type TEXT,
                discrete_emotion TEXT,
                patient_status TEXT,
                audio_duration REAL,
                username TEXT,
                created_by TEXT DEFAULT '系统导入',
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # 测试答案表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS test_answers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                audio_file TEXT NOT NULL UNIQUE,
                v_value REAL,
                a_value REAL,
                emotion_type TEXT,
                discrete_emotion TEXT,
                patient_status TEXT,
                audio_duration REAL,
                created_by TEXT DEFAULT '测试答案导入',
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # 用户排序表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS user_speaker_orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL,
                speaker_order TEXT NOT NULL,
                group_id INTEGER DEFAULT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(username),
                FOREIGN KEY (group_id) REFERENCES group_status(group_id)
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS user_audio_orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL,
                speaker TEXT NOT NULL,
                audio_order TEXT NOT NULL,
                group_id INTEGER DEFAULT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(username, speaker),
                FOREIGN KEY (group_id) REFERENCES group_status(group_id)
            )
        ''')
    
    def _create_users_tables(self, cursor):
        """创建用户相关表"""
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                wechat_name TEXT NOT NULL UNIQUE,
                phone_number TEXT NOT NULL,
                skip_test BOOLEAN DEFAULT FALSE,
                skip_consistency_test BOOLEAN DEFAULT FALSE,
                volume_setting INTEGER DEFAULT NULL,
                volume_test_completed BOOLEAN DEFAULT FALSE,
                second_consistency_test_completed BOOLEAN DEFAULT FALSE,
                group_id INTEGER DEFAULT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (group_id) REFERENCES group_status(group_id)
            )
        ''')
        
        # 用户spk标注权限设置表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS user_speaker_permissions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL,
                speaker_id TEXT NOT NULL,
                group_id INTEGER NOT NULL,
                annotation_enabled BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(username, speaker_id, group_id),
                FOREIGN KEY (group_id) REFERENCES group_status(group_id)
            )
        ''')
    
    def _create_admins_tables(self, cursor):
        """创建管理员相关表"""
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS admins (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                salt TEXT NOT NULL,
                role TEXT NOT NULL DEFAULT 'admin',
                created_by TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_login TIMESTAMP,
                is_active BOOLEAN DEFAULT TRUE,
                description TEXT,
                failed_login_attempts INTEGER DEFAULT 0,
                locked_until TIMESTAMP NULL,
                password_changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                must_change_password BOOLEAN DEFAULT FALSE,
                force_password_change BOOLEAN DEFAULT FALSE
            )
        ''')
        
        # admin_password_history 和 admin_sessions 表已删除，因为在项目中未被使用
    
    def _create_group_assignment_tables(self, cursor):
        """创建分组分配相关表"""
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS speaker_groups (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                group_id INTEGER NOT NULL,
                speaker_id TEXT NOT NULL,
                duration REAL NOT NULL,
                segment_count INTEGER NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(group_id, speaker_id)
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS group_assignments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                group_id INTEGER NOT NULL,
                username TEXT NOT NULL,
                assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                status TEXT DEFAULT 'assigned',
                progress_count INTEGER DEFAULT 0,
                total_segments INTEGER DEFAULT 0,
                completed_at TIMESTAMP NULL,
                second_consistency_completed BOOLEAN DEFAULT FALSE,
                annotated_count INTEGER DEFAULT 0,
                UNIQUE(group_id, username)
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS group_status (
                group_id INTEGER PRIMARY KEY,
                total_duration REAL NOT NULL,
                total_segments INTEGER NOT NULL,
                assigned_count INTEGER DEFAULT 0,
                completed_count INTEGER DEFAULT 0,
                status TEXT DEFAULT 'available',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS user_annotation_progress (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL,
                group_id INTEGER NOT NULL,
                speaker_id TEXT NOT NULL,
                audio_file TEXT NOT NULL,
                annotation_status TEXT DEFAULT 'pending',
                annotated_at TIMESTAMP NULL,
                va_value REAL NULL,
                a_value REAL NULL,
                emotion TEXT NULL,
                UNIQUE(username, group_id, audio_file)
            )
        ''')
    
    def _create_indexes_and_triggers(self, cursor):
        """创建索引和触发器"""
        # 创建索引
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_audio_speaker_user ON emotion_labels(audio_file, speaker, username)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_username_speaker ON emotion_labels(username, speaker)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_timestamp ON emotion_labels(timestamp)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_standard_audio_file ON standard_answers(audio_file)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_test_audio_file ON test_answers(audio_file)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_user_speaker_orders_username ON user_speaker_orders(username)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_user_speaker_orders_group_id ON user_speaker_orders(group_id)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_user_audio_orders_username_speaker ON user_audio_orders(username, speaker)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_user_audio_orders_group_id ON user_audio_orders(group_id)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_group_assignments_username ON group_assignments(username)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_group_assignments_group_id ON group_assignments(group_id)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_group_assignments_username_group ON group_assignments(username, group_id)')
        
        # 创建触发器
        cursor.execute('''
            CREATE TRIGGER IF NOT EXISTS update_emotion_labels_timestamp 
            AFTER UPDATE ON emotion_labels
            FOR EACH ROW
            BEGIN
                UPDATE emotion_labels SET updated_at = CURRENT_TIMESTAMP 
                WHERE id = NEW.id;
            END
        ''')
        
        cursor.execute('''
            CREATE TRIGGER IF NOT EXISTS update_standard_answers_timestamp 
            AFTER UPDATE ON standard_answers
            BEGIN
                UPDATE standard_answers SET updated_at = CURRENT_TIMESTAMP 
                WHERE id = NEW.id;
            END
        ''')
        
        cursor.execute('''
            CREATE TRIGGER IF NOT EXISTS update_test_answers_timestamp 
            AFTER UPDATE ON test_answers
            BEGIN
                UPDATE test_answers SET updated_at = CURRENT_TIMESTAMP 
                WHERE id = NEW.id;
            END
        ''')
        
        cursor.execute('''
            CREATE TRIGGER IF NOT EXISTS update_user_speaker_orders_timestamp 
            AFTER UPDATE ON user_speaker_orders
            BEGIN
                UPDATE user_speaker_orders SET updated_at = CURRENT_TIMESTAMP 
                WHERE id = NEW.id;
            END
        ''')
        
        cursor.execute('''
            CREATE TRIGGER IF NOT EXISTS update_user_audio_orders_timestamp 
            AFTER UPDATE ON user_audio_orders
            BEGIN
                UPDATE user_audio_orders SET updated_at = CURRENT_TIMESTAMP 
                WHERE id = NEW.id;
            END
        ''')
        
        # 优化的触发器：当emotion_labels表插入新记录时，增量更新group_assignments表的annotated_count
        cursor.execute('''
            CREATE TRIGGER IF NOT EXISTS update_annotated_count_on_insert
            AFTER INSERT ON emotion_labels
            FOR EACH ROW
            WHEN NEW.va_complete = 1 AND NEW.discrete_complete = 1
            BEGIN
                UPDATE group_assignments 
                SET annotated_count = COALESCE(annotated_count, 0) + 1
                WHERE username = NEW.username;
            END
        ''')
        
        # 优化的触发器：当emotion_labels表删除记录时，减量更新group_assignments表的annotated_count
        cursor.execute('''
            CREATE TRIGGER IF NOT EXISTS update_annotated_count_on_delete
            AFTER DELETE ON emotion_labels
            FOR EACH ROW
            WHEN OLD.va_complete = 1 AND OLD.discrete_complete = 1
            BEGIN
                UPDATE group_assignments 
                SET annotated_count = MAX(0, COALESCE(annotated_count, 0) - 1)
                WHERE username = OLD.username;
            END
        ''')
        
        # 优化的触发器：当emotion_labels表更新记录时，根据完成状态变化调整annotated_count
        cursor.execute('''
            CREATE TRIGGER IF NOT EXISTS update_annotated_count_on_update
            AFTER UPDATE ON emotion_labels
            FOR EACH ROW
            WHEN (OLD.va_complete != NEW.va_complete OR OLD.discrete_complete != NEW.discrete_complete)
            BEGIN
                UPDATE group_assignments 
                SET annotated_count = CASE
                    WHEN OLD.va_complete = 1 AND OLD.discrete_complete = 1 AND 
                         (NEW.va_complete != 1 OR NEW.discrete_complete != 1) THEN
                        MAX(0, COALESCE(annotated_count, 0) - 1)
                    WHEN (OLD.va_complete != 1 OR OLD.discrete_complete != 1) AND 
                         NEW.va_complete = 1 AND NEW.discrete_complete = 1 THEN
                        COALESCE(annotated_count, 0) + 1
                    ELSE annotated_count
                END
                WHERE username = NEW.username;
            END
        ''')
    
    # ==================== 情感标注相关方法 ====================
    
    def _execute_with_retry(self, operation, *args, **kwargs):
        """带重试机制的数据库操作执行器"""
        for attempt in range(self.max_retries):
            try:
                return operation(*args, **kwargs)
            except sqlite3.OperationalError as e:
                if "database is locked" in str(e).lower() and attempt < self.max_retries - 1:
                    # 数据库锁定，等待后重试
                    delay = self.retry_delay * (2 ** attempt) + random.uniform(0, 0.1)
                    time.sleep(delay)
                    continue
                else:
                    raise
            except Exception as e:
                if attempt < self.max_retries - 1:
                    delay = self.retry_delay * (2 ** attempt)
                    time.sleep(delay)
                    continue
                else:
                    raise
        
    def save_emotion_label(self, audio_file: str, speaker: str, username: str, 
                          v_value: Optional[float] = None, a_value: Optional[float] = None,
                          emotion_type: Optional[str] = None, discrete_emotion: Optional[str] = None,
                          patient_status: Optional[str] = None, audio_duration: float = 0,
                          play_count: int = 0) -> bool:
        """保存情感标注数据"""
        def _save_operation():
            with self.write_lock:
                with self.get_connection() as conn:
                    cursor = conn.cursor()
                    
                    # 开始事务
                    conn.execute('BEGIN IMMEDIATE;')
                    
                    try:
                        # 检查是否已存在记录
                        cursor.execute('''
                            SELECT id, va_complete, discrete_complete FROM emotion_labels 
                            WHERE audio_file = ? AND speaker = ? AND username = ?
                        ''', (audio_file, speaker, username))
                        
                        existing = cursor.fetchone()
                        
                        # 判断完成状态
                        va_complete = v_value is not None and a_value is not None
                        discrete_complete = discrete_emotion is not None
                        
                        if existing:
                            # 更新现有记录
                            update_fields = []
                            update_values = []
                            
                            if v_value is not None:
                                update_fields.append('v_value = ?')
                                update_values.append(v_value)
                            if a_value is not None:
                                update_fields.append('a_value = ?')
                                update_values.append(a_value)
                            if emotion_type is not None:
                                update_fields.append('emotion_type = ?')
                                update_values.append(emotion_type)
                            if discrete_emotion is not None:
                                update_fields.append('discrete_emotion = ?')
                                update_values.append(discrete_emotion)
                            if patient_status is not None:
                                update_fields.append('patient_status = ?')
                                update_values.append(patient_status)
                            
                            # 只更新音频时长和完成状态，不更新播放次数（播放次数由单独的方法管理）
                            update_fields.extend(['audio_duration = ?', 'va_complete = ?', 'discrete_complete = ?'])
                            update_values.extend([audio_duration, int(va_complete), int(discrete_complete)])
                            update_values.append(existing['id'])
                            
                            update_sql = f"UPDATE emotion_labels SET {', '.join(update_fields)} WHERE id = ?"
                            cursor.execute(update_sql, update_values)
                        else:
                            # 插入新记录
                            cursor.execute('''
                                INSERT INTO emotion_labels (
                                    audio_file, speaker, username, v_value, a_value, emotion_type,
                                    discrete_emotion, patient_status, audio_duration, play_count,
                                    va_complete, discrete_complete
                                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                            ''', (audio_file, speaker, username, v_value, a_value, emotion_type,
                                  discrete_emotion, patient_status, audio_duration, play_count,
                                  int(va_complete), int(discrete_complete)))
                        
                        conn.commit()
                        return True
                        
                    except Exception as e:
                        conn.rollback()
                        raise e
        
        try:
            return self._execute_with_retry(_save_operation)
        except Exception as e:
            print(f"保存情感标注数据失败: {e}")
            return False
    
    def get_emotion_labels(self, username: Optional[str] = None, speaker: Optional[str] = None,
                          audio_file: Optional[str] = None) -> List[Dict]:
        """获取情感标注数据"""
        def _get_operation():
            with self.read_lock:
                with self.get_connection() as conn:
                    cursor = conn.cursor()
                    
                    sql = "SELECT * FROM emotion_labels WHERE 1=1"
                    params = []
                    
                    if username:
                        sql += " AND username = ?"
                        params.append(username)
                    if speaker:
                        sql += " AND speaker = ?"
                        params.append(speaker)
                    if audio_file:
                        sql += " AND audio_file = ?"
                        params.append(audio_file)
                    
                    sql += " ORDER BY timestamp DESC"
                    
                    cursor.execute(sql, params)
                    return [dict(row) for row in cursor.fetchall()]
        
        try:
            return self._execute_with_retry(_get_operation)
        except Exception as e:
            print(f"获取情感标注数据失败: {e}")
            return []
    
    def get_user_annotation_statistics(self, username: str) -> Dict:
        """获取用户标注统计信息"""
        def _get_stats_operation():
            with self.read_lock:
                with self.get_connection() as conn:
                    cursor = conn.cursor()
                    
                    # 获取总标注数和完成数
                    cursor.execute('''
                        SELECT 
                            COUNT(*) as total_annotations,
                            SUM(CASE WHEN va_complete = 1 AND discrete_complete = 1 THEN 1 ELSE 0 END) as completed_annotations,
                            AVG(play_count) as avg_play_count,
                            MAX(timestamp) as last_annotation_time
                        FROM emotion_labels 
                        WHERE username = ?
                    ''', (username,))
                    
                    result = cursor.fetchone()
                    
                    if result:
                        total = result['total_annotations'] or 0
                        completed = result['completed_annotations'] or 0
                        completion_rate = (completed / total * 100) if total > 0 else 0
                        
                        return {
                            'total_annotations': total,
                            'completed_annotations': completed,
                            'completion_rate': round(completion_rate, 2),
                            'avg_play_count': round(result['avg_play_count'] or 0, 2),
                            'last_annotation_time': result['last_annotation_time']
                        }
                    else:
                        return {
                            'total_annotations': 0,
                            'completed_annotations': 0,
                            'completion_rate': 0,
                            'avg_play_count': 0,
                            'last_annotation_time': None
                        }
        
        try:
            return self._execute_with_retry(_get_stats_operation)
        except Exception as e:
            print(f"获取用户标注统计失败: {e}")
            return {}
    
    # ==================== 用户相关方法 ====================
    
    def create_user(self, wechat_name: str, phone_number: str, **kwargs) -> bool:
        """创建用户"""
        def _create_operation():
            with self.write_lock:
                with self.get_connection() as conn:
                    cursor = conn.cursor()
                    
                    conn.execute('BEGIN IMMEDIATE;')
                    try:
                        cursor.execute('''
                            INSERT INTO users (wechat_name, phone_number, skip_test, skip_consistency_test,
                                             volume_setting, volume_test_completed, second_consistency_test_completed,
                                             group_id)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                        ''', (
                            wechat_name, phone_number,
                            kwargs.get('skip_test', False),
                            kwargs.get('skip_consistency_test', False),
                            kwargs.get('volume_setting'),
                            kwargs.get('volume_test_completed', False),
                            kwargs.get('second_consistency_test_completed', False),
                            kwargs.get('group_id')
                        ))
                        
                        conn.commit()
                        return True
                    except Exception as e:
                        conn.rollback()
                        raise e
        
        try:
            return self._execute_with_retry(_create_operation)
        except Exception as e:
            print(f"创建用户失败: {e}")
            return False
    
    def get_user(self, wechat_name: str) -> Optional[Dict]:
        """获取用户信息"""
        def _get_operation():
            with self.read_lock:
                with self.get_connection() as conn:
                    cursor = conn.cursor()
                    
                    cursor.execute("SELECT * FROM users WHERE wechat_name = ?", (wechat_name,))
                    result = cursor.fetchone()
                    
                    return dict(result) if result else None
        
        try:
            return self._execute_with_retry(_get_operation)
        except Exception as e:
            print(f"获取用户信息失败: {e}")
            return None
    
    def update_user(self, wechat_name: str, **kwargs) -> bool:
        """更新用户信息"""
        def _update_operation():
            with self.write_lock:
                with self.get_connection() as conn:
                    cursor = conn.cursor()
                    
                    # 构建更新语句
                    update_fields = []
                    update_values = []
                    
                    for field, value in kwargs.items():
                        if field in ['phone_number', 'skip_test', 'skip_consistency_test', 'volume_setting',
                                   'volume_test_completed', 'second_consistency_test_completed', 'group_id']:
                            update_fields.append(f'{field} = ?')
                            update_values.append(value)
                    
                    if not update_fields:
                        return True
                    
                    conn.execute('BEGIN IMMEDIATE;')
                    try:
                        update_values.append(wechat_name)
                        update_sql = f"UPDATE users SET {', '.join(update_fields)} WHERE wechat_name = ?"
                        
                        cursor.execute(update_sql, update_values)
                        conn.commit()
                        return True
                    except Exception as e:
                        conn.rollback()
                        raise e
        
        try:
            return self._execute_with_retry(_update_operation)
        except Exception as e:
            print(f"更新用户信息失败: {e}")
            return False
    
    def get_all_users(self) -> List[Dict]:
        """获取所有用户"""
        def _get_all_operation():
            with self.read_lock:
                with self.get_connection() as conn:
                    cursor = conn.cursor()
                    
                    cursor.execute("SELECT * FROM users ORDER BY created_at DESC")
                    return [dict(row) for row in cursor.fetchall()]
        
        try:
            return self._execute_with_retry(_get_all_operation)
        except Exception as e:
            print(f"获取所有用户失败: {e}")
            return []
    
    # ==================== 管理员相关方法 ====================
    
    def create_admin(self, username: str, password_hash: str, salt: str, role: str = 'admin', **kwargs) -> bool:
        """创建管理员"""
        def _create_admin_operation():
            with self.write_lock:
                with self.get_connection() as conn:
                    cursor = conn.cursor()
                    
                    conn.execute('BEGIN IMMEDIATE;')
                    try:
                        cursor.execute('''
                            INSERT INTO admins (username, password_hash, salt, role, created_by, description)
                            VALUES (?, ?, ?, ?, ?, ?)
                        ''', (username, password_hash, salt, role, kwargs.get('created_by'), kwargs.get('description')))
                        
                        conn.commit()
                        return True
                    except Exception as e:
                        conn.rollback()
                        raise e
        
        try:
            return self._execute_with_retry(_create_admin_operation)
        except Exception as e:
            print(f"创建管理员失败: {e}")
            return False
    
    def get_admin(self, username: str) -> Optional[Dict]:
        """获取管理员信息"""
        def _get_admin_operation():
            with self.read_lock:
                with self.get_connection() as conn:
                    cursor = conn.cursor()
                    
                    cursor.execute("SELECT * FROM admins WHERE username = ? AND is_active = 1", (username,))
                    result = cursor.fetchone()
                    
                    return dict(result) if result else None
        
        try:
            return self._execute_with_retry(_get_admin_operation)
        except Exception as e:
            print(f"获取管理员信息失败: {e}")
            return None
    
    def update_admin_login(self, username: str) -> bool:
        """更新管理员登录时间"""
        def _update_admin_login_operation():
            with self.write_lock:
                with self.get_connection() as conn:
                    cursor = conn.cursor()
                    
                    conn.execute('BEGIN IMMEDIATE;')
                    try:
                        cursor.execute('''
                            UPDATE admins SET last_login = CURRENT_TIMESTAMP, failed_login_attempts = 0
                            WHERE username = ?
                        ''', (username,))
                        
                        conn.commit()
                        return True
                    except Exception as e:
                        conn.rollback()
                        raise e
        
        try:
            return self._execute_with_retry(_update_admin_login_operation)
        except Exception as e:
            print(f"更新管理员登录时间失败: {e}")
            return False
    
    # ==================== 通用方法 ====================
    
    def execute_query(self, sql: str, params: Tuple = ()) -> List[Dict]:
        """执行查询语句"""
        def _execute_query_operation():
            with self.read_lock:
                with self.get_connection() as conn:
                    cursor = conn.cursor()
                    
                    cursor.execute(sql, params)
                    return [dict(row) for row in cursor.fetchall()]
        
        try:
            return self._execute_with_retry(_execute_query_operation)
        except Exception as e:
            print(f"执行查询失败: {e}")
            return []
    
    def execute_update(self, sql: str, params: Tuple = ()) -> bool:
        """执行更新语句"""
        def _execute_update_operation():
            with self.write_lock:
                with self.get_connection() as conn:
                    cursor = conn.cursor()
                    
                    conn.execute('BEGIN IMMEDIATE;')
                    try:
                        cursor.execute(sql, params)
                        conn.commit()
                        return True
                    except Exception as e:
                        conn.rollback()
                        raise e
        
        try:
            return self._execute_with_retry(_execute_update_operation)
        except Exception as e:
            print(f"执行更新失败: {e}")
            return False
    
    def backup_database(self, backup_path: str) -> bool:
        """备份数据库"""
        def _backup_operation():
            with self.read_lock:
                # 确保所有写操作完成后再备份
                with self.get_connection() as conn:
                    # 执行VACUUM以优化数据库并确保数据完整性
                    conn.execute('VACUUM;')
                    conn.commit()
                
                # 使用文件系统级别的复制
                import shutil
                shutil.copy2(self.db_path, backup_path)
                return True
        
        try:
            return self._execute_with_retry(_backup_operation)
        except Exception as e:
            print(f"备份数据库失败: {e}")
            return False
    

    
    def get_database_info(self) -> Dict:
        """获取数据库信息"""
        def _get_db_info_operation():
            with self.read_lock:
                with self.get_connection() as conn:
                    cursor = conn.cursor()
                    
                    # 获取所有表名和记录数
                    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
                    tables = [row[0] for row in cursor.fetchall()]
                    
                    table_info = {}
                    total_records = 0
                    
                    for table in tables:
                        if table == 'sqlite_sequence':
                            continue
                            
                        cursor.execute(f"SELECT COUNT(*) FROM {table}")
                        count = cursor.fetchone()[0]
                        table_info[table] = count
                        total_records += count
                    
                    # 获取数据库文件大小
                    db_size = os.path.getsize(self.db_path) if os.path.exists(self.db_path) else 0
                    
                    return {
                        'database_path': self.db_path,
                        'database_size': db_size,
                        'total_tables': len(table_info),
                        'total_records': total_records,
                        'table_info': table_info
                    }
        
        try:
            return self._execute_with_retry(_get_db_info_operation)
        except Exception as e:
            print(f"获取数据库信息失败: {e}")
            return {}
    
    # ==================== 标注统计相关方法 ====================
    
    def update_all_annotated_counts(self) -> bool:
        """更新所有用户的annotated_count字段"""
        def _update_counts_operation():
            with self.write_lock:
                with self.get_connection() as conn:
                    cursor = conn.cursor()
                    
                    conn.execute('BEGIN IMMEDIATE;')
                    try:
                        # 更新所有用户的annotated_count
                        cursor.execute('''
                            UPDATE group_assignments 
                            SET annotated_count = (
                                SELECT COUNT(*) FROM emotion_labels 
                                WHERE emotion_labels.username = group_assignments.username
                            )
                        ''')
                        
                        conn.commit()
                        return True
                    except Exception as e:
                        conn.rollback()
                        raise e
        
        try:
            return self._execute_with_retry(_update_counts_operation)
        except Exception as e:
            print(f"更新标注统计失败: {e}")
            return False
    
    def get_user_annotation_stats(self, username: str) -> Dict:
        """获取用户的标注统计信息"""
        def _get_user_stats_operation():
            with self.read_lock:
                with self.get_connection() as conn:
                    cursor = conn.cursor()
                    
                    # 获取用户的分组分配信息和标注统计
                    cursor.execute('''
                        SELECT ga.group_id, ga.annotated_count, ga.total_segments, ga.progress_count,
                               ga.status, ga.assigned_at, ga.completed_at
                        FROM group_assignments ga
                        WHERE ga.username = ?
                    ''', (username,))
                    
                    assignment = cursor.fetchone()
                    
                    if not assignment:
                        return {}
                    
                    # 获取用户在emotion_labels表中的实际标注数量（用于验证）
                    cursor.execute('''
                        SELECT COUNT(*) as actual_count
                        FROM emotion_labels
                        WHERE username = ?
                    ''', (username,))
                    
                    actual_count = cursor.fetchone()[0]
                    
                    return {
                        'group_id': assignment[0],
                        'annotated_count': assignment[1],
                        'total_segments': assignment[2],
                        'progress_count': assignment[3],
                        'status': assignment[4],
                        'assigned_at': assignment[5],
                        'completed_at': assignment[6],
                        'actual_count': actual_count,
                        'count_match': assignment[1] == actual_count
                    }
        
        try:
            return self._execute_with_retry(_get_user_stats_operation)
        except Exception as e:
            print(f"获取用户标注统计失败: {e}")
            return {}
    
    def get_all_users_annotation_stats(self) -> List[Dict]:
        """获取所有用户的标注统计信息"""
        def _get_all_stats_operation():
            with self.read_lock:
                with self.get_connection() as conn:
                    cursor = conn.cursor()
                    
                    # 获取所有用户的分组分配信息和标注统计
                    cursor.execute('''
                        SELECT ga.username, ga.group_id, ga.annotated_count, ga.total_segments, 
                               ga.progress_count, ga.status, ga.assigned_at, ga.completed_at,
                               (SELECT COUNT(*) FROM emotion_labels el WHERE el.username = ga.username) as actual_count
                        FROM group_assignments ga
                        ORDER BY ga.username
                    ''')
                    
                    results = []
                    for row in cursor.fetchall():
                        results.append({
                            'username': row[0],
                            'group_id': row[1],
                            'annotated_count': row[2],
                            'total_segments': row[3],
                            'progress_count': row[4],
                            'status': row[5],
                            'assigned_at': row[6],
                            'completed_at': row[7],
                            'actual_count': row[8],
                            'count_match': row[2] == row[8]
                        })
                    
                    return results
        
        try:
            return self._execute_with_retry(_get_all_stats_operation)
        except Exception as e:
            print(f"获取所有用户标注统计失败: {e}")
            return []

# 创建全局实例
unified_db_manager = UnifiedDatabaseManager()