import sqlite3
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATABASE_PATH = PROJECT_ROOT / "database" / "unified_emotion_system.db"

def check_table_structure():
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    # Check emotion_labels table structure
    print("emotion_labels table columns:")
    cursor.execute('PRAGMA table_info(emotion_labels);')
    columns = cursor.fetchall()
    for col in columns:
        print(f"  {col[1]} ({col[2]})")
    
    # Also check if created_at column exists
    cursor.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='emotion_labels';")
    table_sql = cursor.fetchone()
    if table_sql:
        print("\nTable creation SQL:")
        print(table_sql[0])
    
    conn.close()

if __name__ == "__main__":
    check_table_structure()
