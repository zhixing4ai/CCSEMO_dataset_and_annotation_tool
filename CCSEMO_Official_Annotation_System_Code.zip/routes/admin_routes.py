# -*- coding: utf-8 -*-
"""
管理员路由
提供管理员后台管理功能的API接口
"""

import os
import json
from flask import Blueprint, jsonify, request, render_template, session, send_file
from services.admin_service import AdminService
from services.user_service import UserService
from models.admin_model import AdminModel
from utils.logger import emotion_logger, get_client_ip
from config import Config
from services.database_service import DatabaseService

admin_bp = Blueprint('admin', __name__)

# 创建服务实例
admin_service = AdminService()
user_service = UserService()

# 管理员认证装饰器
def admin_required(f):
    """
    管理员权限验证装饰器
    
    Args:
        f: 被装饰的函数
        
    Returns:
        装饰后的函数
    """
    def decorated_function(*args, **kwargs):
        if not session.get('is_admin'):
            return jsonify({"error": "需要管理员权限"}), 403
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

# 超级管理员认证装饰器
def super_admin_required(f):
    """
    超级管理员权限验证装饰器
    
    Args:
        f: 被装饰的函数
        
    Returns:
        装饰后的函数
    """
    def decorated_function(*args, **kwargs):
        if not session.get('is_admin'):
            return jsonify({"error": "需要管理员权限"}), 403
        
        admin_username = session.get('admin_username')
        if not admin_username:
            return jsonify({"error": "管理员身份验证失败"}), 403
        
        admin_model = AdminModel()
        if not admin_model.is_super_admin(admin_username):
            return jsonify({"error": "需要超级管理员权限"}), 403
        
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

@admin_bp.route('/login', methods=['GET'])
def admin_login_page():
    """
    管理员登录页面
    
    Returns:
        渲染的HTML登录页面
    """
    return render_template('admin_login.html')

@admin_bp.route('/login', methods=['POST'])
def admin_login():
    """
    管理员登录API
    
    Returns:
        JSON响应，包含登录结果
    """
    try:
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')
        captcha = data.get('captcha')
        ip_address = get_client_ip()
        
        if not username or not password or not captcha:
            emotion_logger.log_user_activity(
                username=username or 'unknown',
                action="管理员登录失败",
                details={"reason": "用户名、密码或验证码为空"},
                ip_address=ip_address
            )
            return jsonify({"success": False, "message": "用户名、密码和验证码不能为空"}), 400
        
        # 验证码验证（这里简化处理，实际应该使用session存储验证码）
        # 由于前端已经验证了验证码，这里主要是防止绕过前端的攻击
        if len(captcha) != 4 or not captcha.isalnum():
            emotion_logger.log_user_activity(
                username=username,
                action="管理员登录失败",
                details={"reason": "验证码格式错误"},
                ip_address=ip_address
            )
            return jsonify({"success": False, "message": "验证码格式错误"}), 400
        
        admin_model = AdminModel()
        admin_info = admin_model.verify_admin(username, password)
        
        if admin_info:
            session['is_admin'] = True
            session['admin_username'] = username
            session['admin_role'] = admin_info['role']
            session['admin_id'] = admin_info['id']
            
            emotion_logger.log_user_activity(
                username=username,
                action="管理员登录成功",
                details={
                    "role": admin_info['role'],
                    "admin_id": admin_info['id']
                },
                ip_address=ip_address
            )
            
            # 检查是否需要强制修改密码
            if admin_info.get('force_password_change', False):
                return jsonify({
                    "success": True, 
                    "message": "登录成功，但需要修改密码",
                    "force_password_change": True,
                    "admin_info": {
                        "username": admin_info['username'],
                        "role": admin_info['role'],
                        "description": admin_info['description']
                    }
                })
            
            return jsonify({
                "success": True, 
                "message": "登录成功",
                "admin_info": {
                    "username": admin_info['username'],
                    "role": admin_info['role'],
                    "description": admin_info['description']
                }
            })
        else:
            emotion_logger.log_user_activity(
                username=username,
                action="管理员登录失败",
                details={"reason": "用户名或密码错误"},
                ip_address=ip_address
            )
            return jsonify({"success": False, "message": "用户名或密码错误"}), 401
            
    except Exception as e:
        emotion_logger.log_error(e, "管理员登录异常", username)
        return jsonify({"error": str(e)}), 500



@admin_bp.route('/api/users/test-settings', methods=['GET'])
@admin_required
def get_users_test_settings():
    """
    获取所有用户的测试跳过设置
    
    Returns:
        JSON响应，包含所有用户的测试设置信息
    """
    try:
        from models.user_model import UserModel
        
        user_model = UserModel()
        users = user_model.get_all_users()
        
        return jsonify({
            'success': True,
            'users': users
        })
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/api/users/test-settings', methods=['POST'])
@admin_required
def update_user_test_settings():
    """
    更新用户的测试跳过设置
    
    Returns:
        JSON响应，包含更新结果
    """
    try:
        from models.user_model import UserModel
        
        data = request.get_json()
        username = data.get('username')
        skip_test = data.get('skip_test')
        skip_consistency_test = data.get('skip_consistency_test')
        
        if not username:
            return jsonify({"error": "用户名不能为空"}), 400
        
        user_model = UserModel()
        success = user_model.update_user_test_settings(
            username, 
            skip_test=skip_test, 
            skip_consistency_test=skip_consistency_test
        )
        
        if success:
            return jsonify({
                'success': True,
                'message': '用户测试设置更新成功'
            })
        else:
            return jsonify({
                'success': False,
                'message': '用户不存在或更新失败'
            }), 404
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/api/consistency/users')
@admin_required
def get_consistency_users():
    """
    获取参与一致性测试的用户列表
    
    Returns:
        JSON响应，包含用户列表
    """
    try:
        # 检查SQLite是否可用
        try:
            import sqlite3
        except ImportError:
            return jsonify({
                "error": "SQLite3 模块不可用，请检查Python环境配置",
                "details": "数据库功能需要SQLite3支持"
            }), 500
        
        with admin_service.db_service.get_connection() as conn:
            cursor = conn.cursor()
            
            cursor.execute('SELECT DISTINCT username FROM consistency_test_results ORDER BY username')
            users = [row[0] for row in cursor.fetchall()]
        
        return jsonify({
            'success': True,
            'users': users
        })
        
    except Exception as e:
        error_msg = str(e)
        if "SQLite3 模块不可用" in error_msg:
            return jsonify({
                "error": "数据库连接失败：SQLite3 模块不可用",
                "details": "请检查Python环境是否正确安装了SQLite3支持",
                "solution": "可能需要重新安装Python或安装sqlite3-dev包"
            }), 500
        else:
            return jsonify({
                "error": f"获取用户列表失败: {error_msg}"
            }), 500

@admin_bp.route('/api/second-consistency/users')
@admin_required
def get_second_consistency_users():
    """
    获取参与第二次一致性测试的用户列表
    
    Returns:
        JSON响应，包含用户列表
    """
    try:
        # 检查SQLite是否可用
        try:
            import sqlite3
        except ImportError:
            return jsonify({
                "error": "SQLite3 模块不可用，请检查Python环境配置",
                "details": "数据库功能需要SQLite3支持"
            }), 500
        
        with admin_service.db_service.get_connection() as conn:
            cursor = conn.cursor()
            
            cursor.execute('SELECT DISTINCT username FROM second_consistency_test_results ORDER BY username')
            users = [row[0] for row in cursor.fetchall()]
        
        return jsonify({
            'success': True,
            'users': users
        })
        
    except Exception as e:
        error_msg = str(e)
        if "SQLite3 模块不可用" in error_msg:
            return jsonify({
                "error": "数据库连接失败：SQLite3 模块不可用",
                "details": "请检查Python环境是否正确安装了SQLite3支持",
                "solution": "可能需要重新安装Python或安装sqlite3-dev包"
            }), 500
        else:
            return jsonify({
                "error": f"获取第二次一致性用户列表失败: {error_msg}"
            }), 500

@admin_bp.route('/api/consistency/calculate/<username>')
@admin_required
def calculate_user_consistency(username):
    """
    计算指定用户的一致性
    
    Args:
        username (str): 用户名
        
    Returns:
        JSON响应，包含用户一致性分析结果
    """
    try:
        # 检查SQLite是否可用
        try:
            import sqlite3
        except ImportError:
            return jsonify({
                "error": "SQLite3 模块不可用，请检查Python环境配置",
                "details": "数据库功能需要SQLite3支持"
            }), 500
        
        # 获取用户的一致性测试结果
        with admin_service.db_service.get_connection() as conn:
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT audio_file, v_value, a_value, emotion_type, discrete_emotion, patient_status
                FROM consistency_test_results 
                WHERE username = ?
            ''', (username,))
            
            user_results = cursor.fetchall()
        
        if not user_results:
            return jsonify({
                'success': False,
                'error': '该用户没有一致性测试数据'
            }), 404
        
        # 使用标准答案服务获取标准答案
        from services.standard_answers_service import StandardAnswersService
        
        # 将用户结果转换为字典列表格式
        user_results_list = []
        for result in user_results:
            user_results_list.append({
                'audio_file': result[0],
                'v_value': result[1],
                'a_value': result[2],
                'emotion_type': result[3],
                'discrete_emotion': result[4],
                'patient_status': result[5]
            })
        
        # 使用标准答案服务计算一致性
        consistency_result = StandardAnswersService.calculate_consistency_with_standard(user_results_list)
        
        return jsonify({
            'success': True,
            'username': username,
            'consistency_analysis': consistency_result
        })
        
    except Exception as e:
        error_msg = str(e)
        if "SQLite3 模块不可用" in error_msg:
            return jsonify({
                "error": "数据库连接失败：SQLite3 模块不可用",
                "details": "请检查Python环境是否正确安装了SQLite3支持",
                "solution": "可能需要重新安装Python或安装sqlite3-dev包"
            }), 500
        else:
            return jsonify({
                "error": f"计算一致性失败: {error_msg}"
            }), 500

@admin_bp.route('/api/second-consistency/calculate/<username>')
@admin_required
def calculate_user_second_consistency(username):
    """
    计算指定用户的第二次一致性
    
    Args:
        username (str): 用户名
        
    Returns:
        JSON响应，包含用户第二次一致性分析结果
    """
    try:
        # 检查SQLite是否可用
        try:
            import sqlite3
        except ImportError:
            return jsonify({
                "error": "SQLite3 模块不可用，请检查Python环境配置",
                "details": "数据库功能需要SQLite3支持"
            }), 500
        
        from services.database_service import DatabaseService
        
        # 使用数据库服务计算第二次一致性得分
        consistency_score = DatabaseService.calculate_second_consistency_score(username)
        
        if consistency_score is None:
            return jsonify({
                'success': False,
                'error': '该用户没有第二次一致性测试数据'
            }), 404
        
        return jsonify({
            'success': True,
            'username': username,
            'consistency_analysis': consistency_score
        })
        
    except Exception as e:
        error_msg = str(e)
        if "SQLite3 模块不可用" in error_msg:
            return jsonify({
                "error": "数据库连接失败：SQLite3 模块不可用",
                "details": "请检查Python环境是否正确安装了SQLite3支持",
                "solution": "可能需要重新安装Python或安装sqlite3-dev包"
            }), 500
        else:
            return jsonify({
                "error": f"计算第二次一致性失败: {error_msg}"
            }), 500

# 管理员管理相关路由
@admin_bp.route('/api/admins', methods=['GET'])
@admin_required
def get_all_admins():
    """
    获取所有管理员列表
    
    Returns:
        JSON响应，包含管理员列表
    """
    try:
        admin_model = AdminModel()
        admins = admin_model.get_all_admins()
        
        # 获取当前管理员信息
        current_admin_username = session.get('admin_username')
        current_admin = next((admin for admin in admins if admin['username'] == current_admin_username), None)
        
        emotion_logger.log_user_activity(
            username=current_admin_username,
            action="查看管理员列表",
            details={"admin_count": len(admins)},
            ip_address=get_client_ip()
        )
        
        return jsonify({
            "success": True, 
            "admins": admins,
            "current_admin": current_admin
        })
        
    except Exception as e:
        emotion_logger.log_error(e, "获取管理员列表异常", session.get('admin_username'))
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/api/admins', methods=['POST'])
@super_admin_required
def create_admin():
    """
    创建新管理员（仅超级管理员可用）
    
    Returns:
        JSON响应，包含创建结果
    """
    try:
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')
        description = data.get('description', '')
        
        if not username or not password:
            return jsonify({"success": False, "message": "用户名和密码不能为空"}), 400
        
        # 验证密码复杂度
        is_valid, error_message = Config.validate_admin_password(password)
        if not is_valid:
            return jsonify({"success": False, "message": error_message}), 400
        
        admin_model = AdminModel()
        # 新创建的管理员默认为普通管理员角色
        role = AdminModel.ROLE_ADMIN
        created_by = session.get('admin_username')
        success = admin_model.create_admin(username, password, role, created_by, description)
        
        if success:
            emotion_logger.log_user_activity(
                username=session.get('admin_username'),
                action="创建新管理员",
                details={
                    "new_admin_username": username,
                    "description": description
                },
                ip_address=get_client_ip()
            )
            return jsonify({"success": True, "message": "管理员创建成功"})
        else:
            return jsonify({"success": False, "message": "管理员创建失败，可能用户名已存在或密码不符合要求"}), 409
            
    except Exception as e:
        emotion_logger.log_error(e, "创建管理员异常", session.get('admin_username'))
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/api/admins/<int:admin_id>', methods=['PUT'])
@super_admin_required
def update_admin_status(admin_id):
    """
    更新管理员状态（仅超级管理员可用）
    
    Args:
        admin_id: 管理员ID
        
    Returns:
        JSON响应，包含更新结果
    """
    try:
        data = request.get_json()
        is_active = data.get('is_active')
        
        if is_active is None:
            return jsonify({"success": False, "message": "缺少is_active参数"}), 400
        
        admin_model = AdminModel()
        success = admin_model.update_admin_status(admin_id, is_active)
        
        if success:
            emotion_logger.log_user_activity(
                username=session.get('admin_username'),
                action="更新管理员状态",
                details={
                    "admin_id": admin_id,
                    "new_status": "激活" if is_active else "禁用"
                },
                ip_address=get_client_ip()
            )
            return jsonify({"success": True, "message": "管理员状态更新成功"})
        else:
            return jsonify({"success": False, "message": "管理员不存在或更新失败"}), 404
            
    except Exception as e:
        emotion_logger.log_error(e, "更新管理员状态异常", session.get('admin_username'))
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/api/admins/<int:admin_id>', methods=['DELETE'])
@super_admin_required
def delete_admin(admin_id):
    """
    删除管理员（仅超级管理员可用）
    
    Args:
        admin_id: 管理员ID
        
    Returns:
        JSON响应，包含删除结果
    """
    try:
        admin_model = AdminModel()
        
        # 获取要删除的管理员信息
        admins = admin_model.get_all_admins()
        target_admin = next((admin for admin in admins if admin['id'] == admin_id), None)
        
        if not target_admin:
            return jsonify({"success": False, "message": "管理员不存在"}), 404
        
        # 不能删除超级管理员
        if target_admin['role'] == 'super_admin':
            return jsonify({"success": False, "message": "不能删除超级管理员"}), 403
        
        success = admin_model.delete_admin(admin_id)
        
        if success:
            emotion_logger.log_user_activity(
                username=session.get('admin_username'),
                action="删除管理员",
                details={
                    "deleted_admin_id": admin_id,
                    "deleted_admin_username": target_admin['username']
                },
                ip_address=get_client_ip()
            )
            return jsonify({"success": True, "message": "管理员删除成功"})
        else:
            return jsonify({"success": False, "message": "删除失败"}), 500
            
    except Exception as e:
        emotion_logger.log_error(e, "删除管理员异常", session.get('admin_username'))
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/api/admins/change-password', methods=['POST'])
@admin_required
def change_admin_password():
    """
    修改管理员密码
    
    Returns:
        JSON响应，包含修改结果
    """
    try:
        data = request.get_json()
        old_password = data.get('old_password')
        new_password = data.get('new_password')
        
        if not old_password or not new_password:
            return jsonify({"success": False, "message": "旧密码和新密码不能为空"}), 400
        
        # 验证新密码复杂度
        is_valid, error_message = Config.validate_admin_password(new_password)
        if not is_valid:
            return jsonify({"success": False, "message": error_message}), 400
        
        admin_username = session.get('admin_username')
        admin_model = AdminModel()
        
        # 验证旧密码
        if not admin_model.verify_admin(admin_username, old_password):
            return jsonify({"success": False, "message": "旧密码错误"}), 401
        
        success = admin_model.change_password_by_username(admin_username, new_password, admin_username)
        
        if success:
            emotion_logger.log_user_activity(
                username=admin_username,
                action="修改管理员密码",
                details={"result": "成功"},
                ip_address=get_client_ip()
            )
            return jsonify({"success": True, "message": "密码修改成功"})
        else:
            return jsonify({"success": False, "message": "密码修改失败"}), 500
            
    except Exception as e:
        emotion_logger.log_error(e, "修改管理员密码异常", session.get('admin_username'))
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/logout', methods=['POST'])
@admin_required
def admin_logout():
    """
    管理员登出
    
    Returns:
        JSON响应，包含登出结果
    """
    try:
        admin_username = session.get('admin_username')
        admin_role = session.get('admin_role')
        
        emotion_logger.log_user_activity(
            username=admin_username,
            action="管理员登出",
            details={
                "result": "成功",
                "role": admin_role,
                "session_keys": list(session.keys())
            },
            ip_address=get_client_ip()
        )
        
        # 清除会话
        session.pop('is_admin', None)
        session.pop('admin_username', None)
        session.pop('admin_role', None)
        session.pop('admin_id', None)
        
        # 确保会话被完全清除
        session.clear()
        
        return jsonify({
            "success": True, 
            "message": "登出成功",
            "redirect": "/admin/login"
        })
        
    except Exception as e:
        error_msg = str(e)
        emotion_logger.log_error(e, "管理员登出异常", session.get('admin_username'))
        
        # 即使出现异常，也尝试清除会话
        try:
            session.clear()
        except:
            pass
            
        return jsonify({
            "error": error_msg,
            "message": "登出过程中出现错误，但会话已清除",
            "redirect": "/admin/login"
        }), 500

@admin_bp.route('/dashboard')
@admin_required
def dashboard():
    """
    管理员仪表板页面
    
    Returns:
        渲染的HTML页面
    """
    return render_template('admin_dashboard.html')



@admin_bp.route('/api/users')
@admin_required
def get_users():
    """
    获取所有用户列表及其标注统计
    
    Returns:
        JSON响应，包含用户列表和统计信息
    """
    try:
        users_data = admin_service.get_users_statistics()
        return jsonify(users_data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/api/users/<username>/details')
@admin_required
def get_user_details(username):
    """
    获取指定用户的详细标注信息
    
    Args:
        username (str): 用户名
        
    Returns:
        JSON响应，包含用户详细标注信息
    """
    try:
        user_details = admin_service.get_user_details(username)
        return jsonify(user_details)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/api/speakers')
@admin_required
def get_speakers_statistics():
    """
    获取说话人的标注统计
    
    Query Parameters:
        group_id (optional): 分组ID，如果提供则只返回该分组的说话人统计
    
    Returns:
        JSON响应，包含说话人标注统计信息
    """
    try:
        group_id = request.args.get('group_id', type=int)
        speakers_data = admin_service.get_speakers_statistics(group_id)
        return jsonify(speakers_data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/api/groups')
@admin_required
def get_groups_list():
    """
    获取所有分组列表
    
    Returns:
        JSON响应，包含分组信息列表
    """
    try:
        groups_data = admin_service.get_groups_list()
        # 转换数据格式以匹配前端期望
        formatted_groups = [{
            'id': group['group_id'],
            'name': f"分组 {group['group_id']}",
            'total_segments': group['total_segments'],
            'assigned_count': group['assigned_count'],
            'status': group['status']
        } for group in groups_data]
        
        return jsonify({
            "success": True,
            "groups": formatted_groups
        })
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@admin_bp.route('/api/groups/<int:group_id>/statistics')
@admin_required
def get_group_detailed_statistics(group_id):
    """
    获取指定分组的详细统计信息
    
    Args:
        group_id: 分组ID
    
    Returns:
        JSON响应，包含分组详细统计信息
    """
    try:
        group_stats = admin_service.get_group_detailed_statistics(group_id)
        return jsonify(group_stats)
    except Exception as e:
        return jsonify({"error": str(e)}), 500



@admin_bp.route('/api/quality')
@admin_required
def get_annotation_quality():
    """
    获取标注质量分析
    
    Args:
        group_id (optional): 分组ID，通过查询参数传递
    
    Returns:
        JSON响应，包含标注质量分析数据
    """
    try:
        group_id = request.args.get('group_id', type=int)
        quality_data = admin_service.get_annotation_quality(group_id)
        return jsonify({
            "success": True,
            "data": quality_data
        })
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@admin_bp.route('/api/export')
@admin_required
def export_data():
    """
    导出标注数据
    
    Returns:
        JSON响应，包含导出文件信息
    """
    try:
        export_format = request.args.get('format', 'csv')
        username = request.args.get('username')
        speaker = request.args.get('speaker')
        
        export_result = admin_service.export_annotation_data(
            format=export_format,
            username=username,
            speaker=speaker
        )
        return jsonify(export_result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/api/export/download')
@admin_required
def download_export_data():
    """
    直接下载导出的标注数据
    
    Returns:
        文件下载响应
    """
    try:
        export_format = request.args.get('format', 'csv')
        username = request.args.get('username')
        speaker = request.args.get('speaker')
        
        export_result = admin_service.export_annotation_data(
            format=export_format,
            username=username,
            speaker=speaker
        )
        
        if export_result['success']:
            filepath = export_result['filepath']
            filename = export_result['filename']
            
            # 设置正确的MIME类型
            if export_format.lower() == 'csv':
                mimetype = 'text/csv'
            elif export_format.lower() == 'json':
                mimetype = 'application/json'
            else:
                mimetype = 'application/octet-stream'
            
            return send_file(
                filepath,
                as_attachment=True,
                download_name=filename,
                mimetype=mimetype
            )
        else:
            return jsonify({"error": "导出失败"}), 500
            
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/api/users/<username>/reset', methods=['POST'])
@admin_required
def reset_user_progress(username):
    """
    重置用户标注进度
    
    Args:
        username (str): 用户名
        
    Returns:
        JSON响应，包含重置结果
    """
    try:
        result = admin_service.reset_user_progress(username)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/api/users/<username>', methods=['DELETE'])
@admin_required
def delete_user(username):
    """
    删除用户及其所有相关数据
    
    Args:
        username (str): 用户名
        
    Returns:
        JSON响应，包含删除结果
    """
    try:
        from services.user_service import UserService
        
        user_service = UserService()
        user_service.delete_user_data(username)
        
        return jsonify({
            "success": True,
            "message": f"用户 {username} 及其所有数据已成功删除"
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/api/users/<username>/group', methods=['PUT'])
@admin_required
def update_user_group(username):
    """
    更新用户分组（管理员手动分配）
    
    Args:
        username (str): 用户名
        
    Returns:
        JSON响应，包含更新结果
    """
    try:
        data = request.get_json()
        user_group = data.get('user_group')
        
        # 添加调试日志
        print(f"[DEBUG] 收到分组更新请求: username={username}, user_group={user_group}")
        
        # 调用服务层方法更新用户分组
        success, error_message = admin_service.update_user_group_with_validation(username, user_group)
        
        if success:
            group_name = user_group if user_group else "未分组"
            return jsonify({
                "success": True,
                "message": f"用户 {username} 已成功设置为 {group_name}"
            })
        else:
            return jsonify({
                "success": False,
                "error": error_message or "更新用户分组失败"
            }), 400
            
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/api/backup', methods=['POST'])
@admin_required
def backup_database():
    """
    备份数据库
    
    Returns:
        JSON响应，包含备份结果
    """
    try:
        backup_result = admin_service.backup_database()
        return jsonify(backup_result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/api/system/status')
@admin_required
def get_system_status():
    """
    获取系统状态信息
    
    Returns:
        JSON响应，包含系统状态信息
    """
    try:
        status_data = admin_service.get_system_status()
        return jsonify(status_data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/api/export/consistency-results', methods=['GET'])
@admin_required
def export_consistency_results():
    """
    导出整个consistency_test_results表的数据为xlsx格式
    
    Returns:
        文件下载响应或JSON错误响应
    """
    try:
        import pandas as pd
        from services.database_service import DatabaseService
        import os
        from datetime import datetime
        
        # 获取数据库连接
        db_service = DatabaseService()
        
        # 查询consistency_test_results表的所有数据，并联接标准答案
        query = '''
            SELECT 
                ctr.id,
                ctr.username,
                ctr.audio_file,
                ctr.v_value as user_v_value,
                ctr.a_value as user_a_value,
                ctr.discrete_emotion as user_discrete_emotion,
                ctr.timestamp,
                sa.v_value as standard_v_value,
                sa.a_value as standard_a_value,
                sa.discrete_emotion as standard_discrete_emotion
            FROM consistency_test_results ctr
            LEFT JOIN standard_answers sa 
                ON ctr.audio_file = sa.audio_file
            ORDER BY ctr.username, ctr.audio_file
        '''
        
        # 使用pandas读取数据
        with db_service.get_connection() as conn:
            df = pd.read_sql_query(query, conn)
        
        if df.empty:
            return jsonify({
                "success": False,
                "error": "没有找到一致性测试数据"
            }), 404
        
        # 创建导出文件名
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"consistency_test_results_{timestamp}.xlsx"
        
        # 确保导出目录存在
        export_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'database', 'exports')
        os.makedirs(export_dir, exist_ok=True)
        
        filepath = os.path.join(export_dir, filename)
        
        # 导出为xlsx文件
        df.to_excel(filepath, index=False, engine='openpyxl')
        
        # 返回文件下载
        return send_file(
            filepath,
            as_attachment=True,
            download_name=filename,
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )
        
    except ImportError:
        return jsonify({
            "success": False,
            "error": "缺少必要的依赖包，请安装pandas和openpyxl"
        }), 500
    except Exception as e:
        return jsonify({
            "success": False,
            "error": f"导出失败: {str(e)}"
        }), 500

@admin_bp.route('/api/users/<username>/speaker-permissions', methods=['GET'])
@admin_required
def get_user_speaker_permissions(username):
    """获取用户的spk标注权限设置"""
    try:
        result = admin_service.get_user_speaker_permissions(username)
        
        if result['success']:
            return jsonify(result), 200
        else:
            return jsonify(result), 400
            
    except Exception as e:
        return jsonify({'success': False, 'message': f'获取用户权限设置失败: {str(e)}'}), 500

@admin_bp.route('/api/users/<username>/speaker-permissions', methods=['PUT'])
@admin_required
def update_user_speaker_permissions(username):
    """更新用户的spk标注权限设置"""
    try:
        data = request.get_json()
        speaker_permissions = data.get('speaker_permissions', [])
        
        if not isinstance(speaker_permissions, list):
            return jsonify({'success': False, 'message': '权限设置格式错误'}), 400
        
        result = admin_service.update_user_speaker_permissions(username, speaker_permissions)
        
        if result['success']:
            return jsonify(result), 200
        else:
            return jsonify(result), 400
            
    except Exception as e:
        return jsonify({'success': False, 'message': f'更新用户权限设置失败: {str(e)}'}), 500