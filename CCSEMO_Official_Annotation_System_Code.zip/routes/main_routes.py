from flask import Blueprint, render_template, request, redirect, url_for, session, jsonify, make_response, send_from_directory
from functools import wraps
from datetime import timedelta
import secrets
import string
from models.user_model import UserModel
from utils.logger import emotion_logger, get_client_ip
from services.group_assignment_service import GroupAssignmentManager

main_bp = Blueprint('main', __name__)
user_model = UserModel()
group_manager = GroupAssignmentManager()

def generate_captcha():
    """生成4位数字验证码"""
    return ''.join(secrets.choice(string.digits) for _ in range(4))

@main_bp.route("/api/captcha", methods=["GET"])
def get_captcha():
    """获取验证码"""
    captcha = generate_captcha()
    session['captcha'] = captcha
    session['captcha_attempts'] = session.get('captcha_attempts', 0)
    
    # 简单的验证码图片生成（实际项目中应使用更复杂的图片验证码）
    return jsonify({
        'success': True,
        'captcha': captcha,
        'message': '验证码已生成'
    })

@main_bp.route("/test-second-consistency")
def test_second_consistency():
    """测试第二次一致性测试页面"""
    return send_from_directory('.', 'test_second_consistency.html')

@main_bp.route("/login", methods=["GET", "POST"])
def login():
    """登录页面和登录处理"""
    if request.method == "GET":
        return render_template("login.html")
    
    # 处理POST请求 - 登录验证
    data = request.get_json() if request.is_json else request.form
    wechat_name = data.get('text1', '').strip()
    phone_number = data.get('password', '').strip()
    captcha = data.get('captcha', '').strip()
    ip_address = get_client_ip()
    
    if not wechat_name or not phone_number or not captcha:
        emotion_logger.log_user_activity(
            username=wechat_name or 'unknown',
            action="登录失败",
            details={"reason": "信息不完整", "wechat_name": wechat_name, "phone_number": phone_number},
            ip_address=ip_address
        )
        if request.is_json:
            return jsonify({'success': False, 'message': '请填写完整的微信昵称、手机号和验证码'}), 400
        return render_template("login.html", error="请填写完整的微信昵称、手机号和验证码")
    
    # 验证码验证
    stored_captcha = session.get('captcha')
    captcha_attempts = session.get('captcha_attempts', 0)
    
    # 检查验证码尝试次数
    if captcha_attempts >= 5:
        emotion_logger.log_user_activity(
            username=wechat_name,
            action="登录失败",
            details={"reason": "验证码尝试次数过多"},
            ip_address=ip_address
        )
        if request.is_json:
            return jsonify({'success': False, 'message': '验证码尝试次数过多，请刷新页面重新获取'}), 429
        return render_template("login.html", error="验证码尝试次数过多，请刷新页面重新获取")
    
    # 验证验证码
    if not stored_captcha or captcha != stored_captcha:
        session['captcha_attempts'] = captcha_attempts + 1
        emotion_logger.log_user_activity(
            username=wechat_name,
            action="登录失败",
            details={"reason": "验证码错误", "attempts": captcha_attempts + 1},
            ip_address=ip_address
        )
        if request.is_json:
            return jsonify({'success': False, 'message': '验证码错误'}), 400
        return render_template("login.html", error="验证码错误")
    
    # 验证码正确，清除验证码信息
    session.pop('captcha', None)
    session.pop('captcha_attempts', None)
    
    # 验证用户信息
    if user_model.verify_user(wechat_name, phone_number):
        # 设置安全的会话
        session.permanent = True  # 设置为永久会话
        session['username'] = wechat_name
        session['authenticated'] = True
        
        # 检查用户测试跳过设置
        test_settings = user_model.get_user_test_settings(wechat_name)
        
        # 检查用户是否已有管理员分配的分组
        assignment_info = group_manager.get_user_assignment_info(wechat_name)
        group_id = assignment_info['group_id'] if assignment_info else None
        
        emotion_logger.log_user_activity(
            username=wechat_name,
            action="登录成功",
            details={
                "phone_number": phone_number,
                "skip_test": test_settings.get('skip_test', False),
                "skip_consistency_test": test_settings.get('skip_consistency_test', False),
                "assigned_group": group_id
            },
            ip_address=ip_address
        )
        
        if request.is_json:
            # 检查用户是否已完成音量测试
            volume_test_completed = user_model.has_completed_volume_test(wechat_name)
            
            response_data = {
                'success': True, 
                'message': '登录成功', 
                'username': wechat_name,
                'skip_test': test_settings.get('skip_test', False),
                'skip_consistency_test': test_settings.get('skip_consistency_test', False),
                'volume_test_completed': volume_test_completed
            }
            response = make_response(jsonify(response_data))
            # 确保Cookie安全设置
            response.set_cookie('session_active', 'true', httponly=True, secure=False, samesite='Lax')
            return response
        
        # 检查用户是否已完成音量测试
        if not user_model.has_completed_volume_test(wechat_name):
            return redirect(url_for('main.volume_test_page'))
        # 如果已完成音量测试，跳转到确认页面
        else:
            return redirect(url_for('main.volume_test_confirmation_page'))
    else:
        # 用户不存在，自动注册
        if user_model.add_user(wechat_name, phone_number):
            # 设置安全的会话
            session.permanent = True  # 设置为永久会话
            session['username'] = wechat_name
            session['authenticated'] = True
            
            # 注册成功后，同样检查测试跳过设置
            test_settings = user_model.get_user_test_settings(wechat_name)
            
            # 新注册用户暂无分组，需要管理员手动分配
            group_id = None
            
            if request.is_json:
                response_data = {
                    'success': True, 
                    'message': '注册并登录成功', 
                    'username': wechat_name,
                    'skip_test': test_settings.get('skip_test', False),
                    'skip_consistency_test': test_settings.get('skip_consistency_test', False)
                }
                response = make_response(jsonify(response_data))
                # 确保Cookie安全设置
                response.set_cookie('session_active', 'true', httponly=True, secure=False, samesite='Lax')
                return response
            
            # 检查用户是否已完成音量测试
            if not user_model.has_completed_volume_test(wechat_name):
                return redirect(url_for('main.volume_test_page'))
            # 如果已完成音量测试，跳转到确认页面
            else:
                return redirect(url_for('main.volume_test_confirmation_page'))
        else:
            emotion_logger.log_user_activity(
                username=wechat_name,
                action="注册失败",
                details={"reason": "注册失败", "phone_number": phone_number},
                ip_address=ip_address
            )
            if request.is_json:
                return jsonify({'success': False, 'message': '登录失败，请重试'}), 400
            return render_template("login.html", error="登录失败，请重试")

def login_required(f):
    """登录验证装饰器"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # 检查会话是否存在且已认证
        if 'username' not in session or not session.get('authenticated', False):
            # 清除可能存在的无效会话
            session.clear()
            return redirect(url_for('main.login'))
        return f(*args, **kwargs)
    return decorated_function

@main_bp.route("/")
def index():
    """主页 - 已登录用户重定向到音量测试确认页面，未登录用户重定向到登录页面"""
    if 'username' in session and session.get('authenticated', False):
        username = session['username']
        emotion_logger.log_user_activity(
            username=username,
            action="访问主页",
            details={"page": "index"},
            ip_address=get_client_ip()
        )
        # 检查用户是否已完成音量测试
        if not user_model.has_completed_volume_test(username):
            return redirect(url_for('main.volume_test_page'))
        # 如果已完成音量测试，跳转到确认页面
        else:
            return redirect(url_for('main.volume_test_confirmation_page'))
    return redirect(url_for('main.login'))

@main_bp.route("/main")
@login_required
def main_page():
    """主页面"""
    return render_template("index.html")

@main_bp.route('/volume-test')
@login_required
def volume_test_page():
    """音量测试页面"""
    return render_template('volume_test.html')

@main_bp.route('/volume-test-confirmation')
@login_required
def volume_test_confirmation_page():
    """音量测试完成确认页面"""
    return render_template('volume_test_confirmation.html')

@main_bp.route('/test')
@login_required
def test_page():
    """测试页面"""
    return render_template('test.html')

@main_bp.route("/logout", methods=["GET", "POST"])
def logout():
    """退出登录"""
    username = session.get('username', 'unknown')
    
    emotion_logger.log_user_activity(
        username=username,
        action="退出登录",
        details={"session_cleared": True},
        ip_address=get_client_ip()
    )
    
    # 完全清除会话
    session.clear()
    
    # 创建响应并清除相关Cookie
    response = make_response(redirect(url_for('main.login')))
    response.set_cookie('session_active', '', expires=0, httponly=True, secure=False, samesite='Lax')
    
    return response