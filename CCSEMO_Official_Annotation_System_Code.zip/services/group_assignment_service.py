#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
分组分配管理器
负责管理用户分组分配、进度跟踪等功能
"""

import sqlite3
import os
import sys
from datetime import datetime

# 添加父目录到 Python 路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import Config

class GroupAssignmentManager:
    def __init__(self):
        self.db_path = os.path.join(Config.DATABASE_FOLDER, 'unified_emotion_system.db')
        self.ensure_database_exists()
    
    def ensure_database_exists(self):
        """确保数据库存在"""
        if not os.path.exists(self.db_path):
            print(f"分组分配数据库不存在，请先运行初始化脚本")
            return False
        return True
    
    def get_available_group_for_user(self, username):
        """
        获取用户已分配的分组（仅返回管理员分配的分组）
        返回: (group_id, group_info) 或 None
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            # 检查用户是否已经有分配的分组
            cursor.execute('''
                SELECT group_id, status FROM group_assignments 
                WHERE username = ? AND status IN ('assigned', 'in_progress')
            ''', (username,))
            
            existing_assignment = cursor.fetchone()
            if existing_assignment:
                group_id, status = existing_assignment
                # 获取分组详细信息
                group_info = self.get_group_info(group_id)
                return group_id, group_info
            
            # 不再自动分配分组，只返回已分配的分组
            return None, None
            
        finally:
            conn.close()
    
    def get_user_annotation_stats(self, username):
        """
        获取用户的标注统计信息
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            # 检查annotated_count字段是否存在
            cursor.execute("PRAGMA table_info(group_assignments)")
            columns = [row[1] for row in cursor.fetchall()]
            has_annotated_count = 'annotated_count' in columns
            
            if has_annotated_count:
                # 如果有annotated_count字段，使用它
                cursor.execute('''
                    SELECT ga.group_id, ga.annotated_count, ga.total_segments, ga.progress_count,
                           ga.status, ga.assigned_at, ga.completed_at, ga.second_consistency_completed
                    FROM group_assignments ga
                    WHERE ga.username = ?
                ''', (username,))
                
                assignment = cursor.fetchone()
                
                if not assignment:
                    return None
                
                # 获取实际标注数量用于验证
                cursor.execute('''
                    SELECT COUNT(*) as actual_count
                    FROM emotion_labels
                    WHERE username = ?
                ''', (username,))
                
                actual_count = cursor.fetchone()[0]
                
                return {
                    'group_id': assignment[0],
                    'annotated_count': assignment[1],
                    'total_segments': assignment[2],
                    'progress_count': assignment[3],
                    'status': assignment[4],
                    'assigned_at': assignment[5],
                    'completed_at': assignment[6],
                    'second_consistency_completed': bool(assignment[7]) if assignment[7] is not None else False,
                    'actual_count': actual_count,
                    'count_match': assignment[1] == actual_count
                }
            else:
                # 如果没有annotated_count字段，直接计算
                cursor.execute('''
                    SELECT ga.group_id, ga.total_segments, ga.progress_count,
                           ga.status, ga.assigned_at, ga.completed_at, ga.second_consistency_completed
                    FROM group_assignments ga
                    WHERE ga.username = ?
                ''', (username,))
                
                assignment = cursor.fetchone()
                
                if not assignment:
                    return None
                
                # 计算实际标注数量
                cursor.execute('''
                    SELECT COUNT(*) as actual_count
                    FROM emotion_labels
                    WHERE username = ?
                ''', (username,))
                
                actual_count = cursor.fetchone()[0]
                
                return {
                    'group_id': assignment[0],
                    'annotated_count': actual_count,  # 使用实际计算的数量
                    'total_segments': assignment[1],
                    'progress_count': assignment[2],
                    'status': assignment[3],
                    'assigned_at': assignment[4],
                    'completed_at': assignment[5],
                    'second_consistency_completed': bool(assignment[6]) if assignment[6] is not None else False,
                    'actual_count': actual_count,
                    'count_match': True  # 总是匹配，因为是同一个值
                }
                
        finally:
            conn.close()
    
    def update_annotated_count_for_user(self, username):
        """
        更新指定用户的annotated_count字段
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            # 检查annotated_count字段是否存在
            cursor.execute("PRAGMA table_info(group_assignments)")
            columns = [row[1] for row in cursor.fetchall()]
            has_annotated_count = 'annotated_count' in columns
            
            if not has_annotated_count:
                # 添加annotated_count字段
                cursor.execute('''
                    ALTER TABLE group_assignments 
                    ADD COLUMN annotated_count INTEGER DEFAULT 0
                ''')
            
            # 更新用户的annotated_count
            cursor.execute('''
                UPDATE group_assignments 
                SET annotated_count = (
                    SELECT COUNT(*) FROM emotion_labels 
                    WHERE emotion_labels.username = group_assignments.username
                )
                WHERE username = ?
            ''', (username,))
            
            conn.commit()
            return True
            
        except Exception as e:
            print(f"更新用户标注统计失败: {e}")
            return False
        finally:
            conn.close()
    
    def update_second_consistency_completed(self, username, completed=True):
        """
        更新用户的第二次一致性测试完成状态
        
        Args:
            username: 用户名
            completed: 是否完成，默认为True
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                UPDATE group_assignments 
                SET second_consistency_completed = ?
                WHERE username = ?
            ''', (completed, username))
            
            conn.commit()
            
        finally:
            conn.close()
    
    def assign_group_to_user(self, username, group_id):
        """
        将分组分配给用户（已废弃 - 现在由管理员通过admin_service控制）
        
        注意：此方法已废弃，分组分配现在完全由管理员通过后台界面控制。
        请使用 admin_service.update_user_group() 方法进行分组分配。
        """
        # 此方法已废弃，返回错误信息
        return False, "分组分配现在由管理员控制，请联系管理员进行分组分配"
    
    def get_group_info(self, group_id):
        """
        获取分组详细信息
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            # 获取分组基本信息
            cursor.execute('''
                SELECT total_duration, total_segments, assigned_count, status
                FROM group_status 
                WHERE group_id = ?
            ''', (group_id,))
            
            group_basic = cursor.fetchone()
            if not group_basic:
                return None
            
            # 获取分组中的说话人信息
            cursor.execute('''
                SELECT speaker_id, duration, segment_count
                FROM speaker_groups 
                WHERE group_id = ?
                ORDER BY duration DESC
            ''', (group_id,))
            
            speakers = cursor.fetchall()
            
            return {
                'group_id': group_id,
                'total_duration': group_basic[0],
                'total_segments': group_basic[1],
                'assigned_count': group_basic[2],
                'status': group_basic[3],
                'speakers': [{
                    'speaker_id': speaker[0],
                    'duration': speaker[1],
                    'segment_count': speaker[2]
                } for speaker in speakers]
            }
            
        finally:
            conn.close()
    
    def get_user_assignment_info(self, username):
        """
        获取用户的分组分配信息
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                SELECT ga.group_id, ga.status, ga.progress_count, ga.total_segments,
                       ga.assigned_at, ga.completed_at, ga.second_consistency_completed,
                       ga.annotated_count
                FROM group_assignments ga
                WHERE ga.username = ?
            ''', (username,))
            
            assignment = cursor.fetchone()
            if not assignment:
                return None
            
            group_id, status, progress_count, total_segments, assigned_at, completed_at, second_consistency_completed, annotated_count = assignment
            
            # 获取分组详细信息
            group_info = self.get_group_info(group_id)
            
            return {
                'group_id': group_id,
                'status': status,
                'progress_count': progress_count,
                'total_segments': total_segments,
                'assigned_at': assigned_at,
                'completed_at': completed_at,
                'second_consistency_completed': bool(second_consistency_completed),
                'annotated_count': annotated_count or 0,
                'group_info': group_info
            }
            
        finally:
            conn.close()
    
    def update_user_progress(self, username, group_id, progress_count, cursor=None):
        """
        更新用户标注进度
        
        Args:
            username: 用户名
            group_id: 分组ID
            progress_count: 进度计数
            cursor: 可选的数据库游标，如果提供则使用现有事务
        """
        if cursor:
            # 使用传入的cursor，不创建新连接
            try:
                cursor.execute('''
                    UPDATE group_assignments 
                    SET progress_count = ?,
                        status = CASE 
                            WHEN progress_count >= total_segments THEN 'completed'
                            ELSE 'in_progress'
                        END,
                        completed_at = CASE 
                            WHEN progress_count >= total_segments THEN CURRENT_TIMESTAMP
                            ELSE completed_at
                        END
                    WHERE username = ? AND group_id = ?
                ''', (progress_count, username, group_id))
                return True
            except Exception as e:
                print(f"更新进度失败: {e}")
                return False
        else:
            # 创建新连接（向后兼容）
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            try:
                cursor.execute('''
                    UPDATE group_assignments 
                    SET progress_count = ?,
                        status = CASE 
                            WHEN progress_count >= total_segments THEN 'completed'
                            ELSE 'in_progress'
                        END,
                        completed_at = CASE 
                            WHEN progress_count >= total_segments THEN CURRENT_TIMESTAMP
                            ELSE completed_at
                        END
                    WHERE username = ? AND group_id = ?
                ''', (progress_count, username, group_id))
                
                conn.commit()
                return True
                
            except Exception as e:
                print(f"更新进度失败: {e}")
                return False
            finally:
                conn.close()
    
    def update_second_consistency_status(self, username, group_id, completed=True):
        """
        更新用户第二次一致性测试完成状态
        
        Args:
            username (str): 用户名
            group_id (int): 分组ID
            completed (bool): 是否完成第二次一致性测试
            
        Returns:
            bool: 更新是否成功
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                UPDATE group_assignments 
                SET second_consistency_completed = ?
                WHERE username = ? AND group_id = ?
            ''', (1 if completed else 0, username, group_id))
            
            conn.commit()
            return cursor.rowcount > 0
            
        except Exception as e:
            print(f"更新第二次一致性测试状态失败: {e}")
            return False
        finally:
            conn.close()
    
    def get_second_consistency_status(self, username, group_id):
        """
        获取用户第二次一致性测试完成状态
        
        Args:
            username (str): 用户名
            group_id (int): 分组ID
            
        Returns:
            bool: 是否完成第二次一致性测试
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                SELECT second_consistency_completed
                FROM group_assignments
                WHERE username = ? AND group_id = ?
            ''', (username, group_id))
            
            result = cursor.fetchone()
            return bool(result[0]) if result else False
            
        except Exception as e:
            print(f"获取第二次一致性测试状态失败: {e}")
            return False
        finally:
            conn.close()
    
    def get_group_speakers(self, group_id):
        """
        获取分组中的所有说话人ID列表
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                SELECT speaker_id FROM speaker_groups 
                WHERE group_id = ?
                ORDER BY speaker_id
            ''', (group_id,))
            
            speakers = cursor.fetchall()
            return [speaker[0] for speaker in speakers]
            
        finally:
            conn.close()
    
    def get_all_groups_status(self):
        """
        获取所有分组的状态信息
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                SELECT gs.group_id, gs.total_duration, gs.total_segments, 
                       gs.assigned_count, gs.completed_count, gs.status,
                       COUNT(ga.username) as actual_assigned,
                       SUM(CASE WHEN ga.second_consistency_completed = 1 THEN 1 ELSE 0 END) as second_consistency_completed_count
                FROM group_status gs
                LEFT JOIN group_assignments ga ON gs.group_id = ga.group_id
                GROUP BY gs.group_id
                ORDER BY gs.group_id
            ''')
            
            groups = cursor.fetchall()
            return [{
                'group_id': group[0],
                'total_duration': group[1],
                'total_segments': group[2],
                'assigned_count': group[3],
                'completed_count': group[4],
                'status': group[5],
                'actual_assigned': group[6],
                'second_consistency_completed_count': group[7]
            } for group in groups]
            
        finally:
            conn.close()