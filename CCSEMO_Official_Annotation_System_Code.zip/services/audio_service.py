# services/audio_service.py
import os
import glob
import re
import random
from config import Config
from services.order_service import OrderService
from .group_assignment_service import GroupAssignmentManager

class AudioService:
    """音频文件相关服务"""
    
    @staticmethod
    def get_speakers_list(username="default"):
        """获取说话人列表（根据用户分组和spk权限过滤）"""
        if not os.path.exists(Config.AUDIO_FOLDER):
            raise FileNotFoundError(f"音频文件夹不存在: {Config.AUDIO_FOLDER}")

        # 获取用户分配的分组信息
        group_manager = GroupAssignmentManager()
        user_assignment = group_manager.get_user_assignment_info(username)
        
        if user_assignment:
            # 用户有分配的分组，只返回该分组的说话人
            group_id = user_assignment['group_id']
            assigned_speakers = group_manager.get_group_speakers(group_id)
            
            # 获取用户的spk权限设置
            enabled_speakers = AudioService._get_enabled_speakers(username, assigned_speakers)
            
            # 获取所有说话人目录
            all_speakers = [
                d for d in os.listdir(Config.AUDIO_FOLDER)
                if os.path.isdir(os.path.join(Config.AUDIO_FOLDER, d))
            ]
            
            # 按spk编号分组，但只包含分配给用户且启用的说话人
            speaker_groups = {}
            for speaker in all_speakers:
                match = re.match(r'(spk)(\d+)-(\d+)-(\d+)', speaker)
                if match:
                    prefix, spk_id, part, section = match.groups()
                    spk_group = f"spk{spk_id}"
                    # 只包含分配给用户且启用的说话人
                    if spk_group in enabled_speakers:
                        if spk_group not in speaker_groups:
                            speaker_groups[spk_group] = []
                        speaker_groups[spk_group].append(speaker)
                else:
                    # 直接匹配的说话人
                    if speaker in enabled_speakers:
                        speaker_groups[speaker] = [speaker]
        else:
            # 用户没有分配分组，返回空列表
            return []
        
        # 获取或创建用户专属排序
        return AudioService._get_user_speaker_order(username, speaker_groups)
    
    @staticmethod
    def _get_enabled_speakers(username, assigned_speakers):
        """获取用户启用的说话人列表"""
        try:
            import sqlite3
            from config import Config
            
            db_path = os.path.join(Config.DATABASE_FOLDER, 'unified_emotion_system.db')
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            # 获取用户的分组ID
            cursor.execute("""
                SELECT group_id FROM users WHERE wechat_name = ?
            """, (username,))
            
            user_row = cursor.fetchone()
            if not user_row or not user_row[0]:
                conn.close()
                return assigned_speakers  # 如果没有分组信息，返回所有分配的说话人
            
            group_id = user_row[0]
            
            # 获取用户的权限设置
            cursor.execute("""
                SELECT speaker_id, annotation_enabled 
                FROM user_speaker_permissions 
                WHERE username = ? AND group_id = ?
            """, (username, group_id))
            
            permissions = {}
            for row in cursor.fetchall():
                permissions[row[0]] = bool(row[1])
            
            conn.close()
            
            # 过滤出启用的说话人（默认启用）
            enabled_speakers = []
            for speaker in assigned_speakers:
                if permissions.get(speaker, True):  # 默认启用
                    enabled_speakers.append(speaker)
            
            return enabled_speakers
            
        except Exception as e:
            # 如果出错，返回所有分配的说话人
            return assigned_speakers
    
    @staticmethod
    def _check_speaker_permission(username, speaker):
        """检查用户是否有权限访问指定说话人"""
        try:
            import sqlite3
            from config import Config
            
            db_path = os.path.join(Config.DATABASE_FOLDER, 'unified_emotion_system.db')
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            # 获取用户的分组ID
            cursor.execute("""
                SELECT group_id FROM users WHERE wechat_name = ?
            """, (username,))
            
            user_row = cursor.fetchone()
            if not user_row or not user_row[0]:
                conn.close()
                return False  # 用户没有分组信息，拒绝访问
            
            group_id = user_row[0]
            
            # 检查说话人是否在用户分组中
            cursor.execute("""
                SELECT speaker_id FROM speaker_groups 
                WHERE group_id = ? AND speaker_id = ?
            """, (group_id, speaker))
            
            if not cursor.fetchone():
                conn.close()
                return False  # 说话人不在用户分组中
            
            # 检查用户的权限设置
            cursor.execute("""
                SELECT annotation_enabled 
                FROM user_speaker_permissions 
                WHERE username = ? AND group_id = ? AND speaker_id = ?
            """, (username, group_id, speaker))
            
            permission_row = cursor.fetchone()
            conn.close()
            
            if permission_row is not None:
                return bool(permission_row[0])  # 返回权限设置
            else:
                return True  # 没有设置权限，默认启用
            
        except Exception as e:
            # 如果出错，默认拒绝访问
            return False
    
    @staticmethod
    def _get_user_speaker_order(username, speaker_groups):
        """获取用户专属的说话人排序"""
        order_service = OrderService()
        return order_service.get_user_speaker_order(username, speaker_groups)
    
    @staticmethod
    def get_audio_files_list(speaker, username=""):
        """获取指定说话人的音频文件列表"""
        # 检查用户是否有权限访问该说话人
        if username and not AudioService._check_speaker_permission(username, speaker):
            return []  # 用户没有权限，返回空列表
        
        # 获取音频文件
        if re.match(r'spk\d+$', speaker):
            audio_files = AudioService._get_grouped_speaker_files(speaker)
        else:
            audio_files = AudioService._get_single_speaker_files(speaker)
        
        # 获取用户专属的文件排序
        if username:
            audio_files = AudioService._get_user_audio_order(speaker, username, audio_files)
        else:
            random.shuffle(audio_files)
        
        return audio_files
    
    @staticmethod
    def _get_grouped_speaker_files(speaker):
        """获取分组说话人的音频文件"""
        all_speakers = [
            d for d in os.listdir(Config.AUDIO_FOLDER)
            if os.path.isdir(os.path.join(Config.AUDIO_FOLDER, d)) 
            and d.startswith(speaker + '-')
        ]
        
        audio_files = []
        for sub_speaker in all_speakers:
            speaker_folder = os.path.join(Config.AUDIO_FOLDER, sub_speaker)
            files = glob.glob(os.path.join(speaker_folder, "*.wav"))
            audio_files.extend(files)
        
        return audio_files
    
    @staticmethod
    def _get_single_speaker_files(speaker):
        """获取单个说话人的音频文件"""
        speaker_folder = os.path.join(Config.AUDIO_FOLDER, speaker)
        if not os.path.exists(speaker_folder):
            raise FileNotFoundError(f"找不到说话人 {speaker} 的文件夹")
        
        return glob.glob(os.path.join(speaker_folder, "*.wav"))
    
    @staticmethod
    def _get_user_audio_order(speaker, username, audio_files):
        """获取用户专属的音频文件排序"""
        order_service = OrderService()
        return order_service.get_user_audio_order(speaker, username, audio_files)
    
    @staticmethod
    def find_audio_file(speaker, filename):
        """查找音频文件的完整路径"""
        if re.match(r'spk\d+$', speaker):
            # 分组说话人
            all_speakers = [
                d for d in os.listdir(Config.AUDIO_FOLDER)
                if os.path.isdir(os.path.join(Config.AUDIO_FOLDER, d)) 
                and d.startswith(speaker + '-')
            ]
            
            for sub_speaker in all_speakers:
                # 首先尝试直接查找文件名
                file_path = os.path.join(Config.AUDIO_FOLDER, sub_speaker, filename)
                if os.path.exists(file_path):
                    return file_path, sub_speaker
                
                # 如果文件名包含说话人前缀，尝试提取实际文件名
                if filename.startswith(sub_speaker + '-'):
                    # 提取去掉说话人前缀的文件名部分
                    actual_filename = filename[len(sub_speaker + '-'):]
                    file_path = os.path.join(Config.AUDIO_FOLDER, sub_speaker, actual_filename)
                    if os.path.exists(file_path):
                        return file_path, sub_speaker
            return None, None
        else:
            # 单个说话人
            file_path = os.path.join(Config.AUDIO_FOLDER, speaker, filename)
            if os.path.exists(file_path):
                return file_path, speaker
            return None, None