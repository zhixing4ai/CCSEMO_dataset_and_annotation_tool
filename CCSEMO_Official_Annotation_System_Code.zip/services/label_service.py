import os
from .database_service import DatabaseService
from .optimized_label_service import optimized_label_service

class LabelService:
    """标注相关服务"""
    
    def __init__(self):
        self.db_service = DatabaseService()
        # 使用优化的标注服务
        self.optimized_service = optimized_label_service
    
    def get_labeled_files(self, username, speaker):
        """获取已标注的文件列表"""
        return self.optimized_service.get_labeled_files(username, speaker)
    
    def save_label(self, label_data, speaker, audio_file_path):
        """保存标注数据到数据库（使用优化版本）"""
        return self.optimized_service.save_label_optimized(label_data, speaker, audio_file_path)
    
    def get_label(self, username, speaker, filename):
        """获取标注数据"""
        return self.optimized_service.get_label(username, speaker, filename)
    
    def save_play_count(self, username, speaker, filename):
        """保存音频播放次数"""
        return self.optimized_service.save_play_count(username, speaker, filename)
    
    def get_play_count(self, username, speaker, filename):
        """获取音频播放次数"""
        return self.optimized_service.get_play_count(username, speaker, filename)