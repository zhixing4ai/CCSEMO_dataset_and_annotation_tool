# -*- coding: utf-8 -*-
"""
优化版本的数据库服务 - 解决保存卡顿问题
主要优化：
1. 批量更新分组进度
2. 缓存机制减少重复查询
3. 异步处理非关键操作
"""

import sqlite3
import threading
import time
from typing import Dict, List, Optional, Tuple
from collections import defaultdict
from datetime import datetime, timedelta
import json
import logging
from .database_service import DatabaseService

logger = logging.getLogger(__name__)

class DatabaseServiceOptimized(DatabaseService):
    """
    优化版本的数据库服务类
    """
    
    def __init__(self, db_path: str):
        super().__init__(db_path)
        self.progress_cache = {}
        self.cache_expiry = 300  # 5分钟缓存
        self.batch_updates = defaultdict(list)
        self.batch_lock = threading.Lock()
        self.last_batch_process = time.time()
        self.batch_interval = 30  # 30秒批量处理一次
        
        # 启动后台批量处理线程
        self._start_batch_processor()
    
    def _start_batch_processor(self):
        """
        启动后台批量处理线程
        """
        def batch_processor():
            while True:
                try:
                    time.sleep(self.batch_interval)
                    self._process_batch_updates()
                except Exception as e:
                    logger.error(f"批量处理错误: {e}")
        
        thread = threading.Thread(target=batch_processor, daemon=True)
        thread.start()
        logger.info("批量处理线程已启动")
    
    def save_label_optimized(self, label_data: Dict) -> Dict:
        """
        优化版本的保存标注方法
        
        Args:
            label_data: 标注数据字典
            
        Returns:
            Dict: 保存结果
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # 1. 快速保存标注数据（核心操作）
            result = self._save_label_core(cursor, label_data)
            
            if result['success']:
                # 2. 将进度更新加入批量队列（非阻塞）
                self._queue_progress_update(label_data['username'])
                
                # 3. 异步处理音频时长更新（如果需要）
                self._queue_audio_duration_update(label_data['audio_file'])
            
            conn.commit()
            conn.close()
            
            return result
            
        except Exception as e:
            logger.error(f"保存标注失败: {e}")
            if 'conn' in locals():
                conn.rollback()
                conn.close()
            return {'success': False, 'error': str(e)}
    
    def _save_label_core(self, cursor: sqlite3.Cursor, label_data: Dict) -> Dict:
        """
        核心标注保存逻辑（快速执行）
        
        Args:
            cursor: 数据库游标
            label_data: 标注数据
            
        Returns:
            Dict: 保存结果
        """
        try:
            # 处理分组说话人逻辑
            if label_data.get('speaker') == 'group':
                label_data['speaker'] = None
            
            # 优先使用已存在的音频时长，避免重复计算
            audio_duration = self._get_cached_audio_duration(label_data['audio_file'])
            if audio_duration is None:
                audio_duration = 0  # 设置为0，后续异步更新
            
            # 检查是否存在现有记录
            cursor.execute("""
                SELECT id FROM emotion_labels 
                WHERE audio_file = ? AND username = ? AND speaker = ?
            """, (label_data['audio_file'], label_data['username'], label_data['speaker']))
            
            existing_record = cursor.fetchone()
            
            if existing_record:
                # 更新现有记录
                cursor.execute("""
                    UPDATE emotion_labels SET
                        valence = ?, arousal = ?, dominance = ?,
                        emotion_category = ?, emotion_intensity = ?,
                        audio_duration = ?, updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                """, (
                    label_data.get('valence'),
                    label_data.get('arousal'), 
                    label_data.get('dominance'),
                    label_data.get('emotion_category'),
                    label_data.get('emotion_intensity'),
                    audio_duration,
                    existing_record[0]
                ))
            else:
                # 插入新记录
                cursor.execute("""
                    INSERT INTO emotion_labels (
                        audio_file, username, speaker, valence, arousal, dominance,
                        emotion_category, emotion_intensity, audio_duration
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    label_data['audio_file'],
                    label_data['username'],
                    label_data['speaker'],
                    label_data.get('valence'),
                    label_data.get('arousal'),
                    label_data.get('dominance'),
                    label_data.get('emotion_category'),
                    label_data.get('emotion_intensity'),
                    audio_duration
                ))
            
            return {'success': True}
            
        except Exception as e:
            logger.error(f"核心保存逻辑失败: {e}")
            return {'success': False, 'error': str(e)}
    
    def _get_cached_audio_duration(self, audio_file: str) -> Optional[float]:
        """
        获取缓存的音频时长
        
        Args:
            audio_file: 音频文件名
            
        Returns:
            Optional[float]: 音频时长，如果不存在则返回None
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT audio_duration FROM emotion_labels 
                WHERE audio_file = ? AND audio_duration > 0 
                LIMIT 1
            """, (audio_file,))
            
            result = cursor.fetchone()
            conn.close()
            
            return result[0] if result else None
            
        except Exception as e:
            logger.error(f"获取缓存音频时长失败: {e}")
            return None
    
    def _queue_progress_update(self, username: str):
        """
        将进度更新加入批量队列
        
        Args:
            username: 用户名
        """
        with self.batch_lock:
            if username not in self.batch_updates['progress']:
                self.batch_updates['progress'].append(username)
    
    def _queue_audio_duration_update(self, audio_file: str):
        """
        将音频时长更新加入批量队列
        
        Args:
            audio_file: 音频文件名
        """
        with self.batch_lock:
            if audio_file not in self.batch_updates['audio_duration']:
                self.batch_updates['audio_duration'].append(audio_file)
    
    def _process_batch_updates(self):
        """
        处理批量更新队列
        """
        with self.batch_lock:
            if not self.batch_updates['progress'] and not self.batch_updates['audio_duration']:
                return
            
            progress_users = list(self.batch_updates['progress'])
            audio_files = list(self.batch_updates['audio_duration'])
            
            # 清空队列
            self.batch_updates['progress'].clear()
            self.batch_updates['audio_duration'].clear()
        
        # 批量处理进度更新
        if progress_users:
            self._batch_update_progress(progress_users)
        
        # 批量处理音频时长更新
        if audio_files:
            self._batch_update_audio_duration(audio_files)
        
        logger.info(f"批量处理完成: {len(progress_users)}个用户进度, {len(audio_files)}个音频时长")
    
    def _batch_update_progress(self, usernames: List[str]):
        """
        批量更新用户进度
        
        Args:
            usernames: 用户名列表
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            for username in usernames:
                # 计算用户标注进度
                cursor.execute("""
                    SELECT COUNT(*) FROM emotion_labels 
                    WHERE username = ?
                """, (username,))
                
                annotated_count = cursor.fetchone()[0]
                
                # 获取用户分组信息
                cursor.execute("""
                    SELECT total_segments FROM group_assignments 
                    WHERE username = ?
                """, (username,))
                
                result = cursor.fetchone()
                if result:
                    total_segments = result[0]
                    progress_percentage = (annotated_count / total_segments * 100) if total_segments > 0 else 0
                    
                    # 确定状态
                    if annotated_count >= total_segments:
                        status = 'completed'
                    elif annotated_count > 0:
                        status = 'in_progress'
                    else:
                        status = 'not_started'
                    
                    # 更新进度
                    cursor.execute("""
                        UPDATE group_assignments SET 
                            progress_count = ?, 
                            status = ?,
                            updated_at = CURRENT_TIMESTAMP
                        WHERE username = ?
                    """, (annotated_count, status, username))
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            logger.error(f"批量更新进度失败: {e}")
            if 'conn' in locals():
                conn.rollback()
                conn.close()
    
    def _batch_update_audio_duration(self, audio_files: List[str]):
        """
        批量更新音频时长
        
        Args:
            audio_files: 音频文件列表
        """
        try:
            # 这里可以调用音频处理库来计算实际时长
            # 为了演示，我们使用模拟值
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            for audio_file in audio_files:
                # 检查是否已有时长信息
                cursor.execute("""
                    SELECT COUNT(*) FROM emotion_labels 
                    WHERE audio_file = ? AND audio_duration > 0
                """, (audio_file,))
                
                if cursor.fetchone()[0] == 0:
                    # 计算音频时长（这里需要实际的音频处理逻辑）
                    # duration = calculate_audio_duration(audio_file)
                    duration = 10.0  # 模拟值
                    
                    # 更新所有相关记录
                    cursor.execute("""
                        UPDATE emotion_labels SET audio_duration = ?
                        WHERE audio_file = ? AND audio_duration = 0
                    """, (duration, audio_file))
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            logger.error(f"批量更新音频时长失败: {e}")
            if 'conn' in locals():
                conn.rollback()
                conn.close()
    
    def check_second_consistency_test_needed_optimized(self, username: str) -> Dict:
        """
        优化版本的第二次一致性测试检查
        使用缓存减少数据库查询
        
        Args:
            username: 用户名
            
        Returns:
            Dict: 检查结果
        """
        # 检查缓存
        cache_key = f"consistency_check_{username}"
        now = time.time()
        
        if cache_key in self.progress_cache:
            cached_data = self.progress_cache[cache_key]
            if now - cached_data['timestamp'] < self.cache_expiry:
                return cached_data['result']
        
        # 缓存未命中，执行查询
        try:
            result = self.check_second_consistency_test_needed(username)
            
            # 更新缓存
            self.progress_cache[cache_key] = {
                'result': result,
                'timestamp': now
            }
            
            return result
            
        except Exception as e:
            logger.error(f"检查第二次一致性测试失败: {e}")
            return {'success': False, 'error': str(e)}
    
    def clear_cache(self):
        """
        清空缓存
        """
        self.progress_cache.clear()
        logger.info("缓存已清空")
    
    def get_cache_stats(self) -> Dict:
        """
        获取缓存统计信息
        
        Returns:
            Dict: 缓存统计
        """
        now = time.time()
        valid_cache_count = 0
        expired_cache_count = 0
        
        for cache_data in self.progress_cache.values():
            if now - cache_data['timestamp'] < self.cache_expiry:
                valid_cache_count += 1
            else:
                expired_cache_count += 1
        
        return {
            'total_cache_entries': len(self.progress_cache),
            'valid_cache_entries': valid_cache_count,
            'expired_cache_entries': expired_cache_count,
            'cache_hit_rate': valid_cache_count / max(len(self.progress_cache), 1)
        }
    
    def force_batch_process(self):
        """
        强制执行批量处理（用于测试或紧急情况）
        """
        self._process_batch_updates()
        logger.info("强制批量处理完成")