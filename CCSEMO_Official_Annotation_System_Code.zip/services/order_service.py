#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
排序服务
处理用户的说话人和音频文件排序逻辑
"""

import os
import json
import random
from datetime import datetime
from .database_service import DatabaseService

class OrderService:
    """排序服务类"""
    
    def __init__(self):
        """初始化排序服务"""
        self.db_service = DatabaseService()
    
    def get_user_speaker_order(self, username, speaker_groups):
        """
        获取用户专属的说话人排序
        
        Args:
            username (str): 用户名
            speaker_groups (dict): 说话人分组字典
            
        Returns:
            list: 排序后的说话人列表
        """
        try:
            with self.db_service.get_connection() as conn:
                cursor = conn.cursor()
                
                # 检查用户是否有分配的group_id
                cursor.execute("SELECT group_id FROM users WHERE wechat_name = ?", (username,))
                user_result = cursor.fetchone()
                if not user_result or user_result[0] is None:
                    # 用户没有分配group_id，不生成排序数据
                    return list(speaker_groups.keys())
                
                # 查询用户的说话人排序
                cursor.execute(
                    "SELECT speaker_order FROM user_speaker_orders WHERE username = ?",
                    (username,)
                )
                result = cursor.fetchone()
                
                if result:
                    # 使用保存的排序（预生成的固定排序）
                    saved_order = json.loads(result[0])
                    sorted_groups = []
                    existing_groups = set(speaker_groups.keys())
                    
                    # 按保存的顺序重新排列
                    for group in saved_order:
                        if group in existing_groups:
                            sorted_groups.append(group)
                            existing_groups.remove(group)
                    
                    # 添加新的说话人组（如果有的话）
                    if existing_groups:
                        # 对新增的说话人组也使用固定的随机种子
                        new_groups = list(existing_groups)
                        random.seed(hash(f"{username}_new_speakers") % (2**32))
                        random.shuffle(new_groups)
                        random.seed()
                        sorted_groups.extend(new_groups)
                        
                        # 更新数据库中的排序
                        self._save_user_speaker_order(username, sorted_groups)
                    
                    return sorted_groups
                else:
                    # 如果数据库中没有排序数据，说明是旧用户或未分配分组的用户
                    # 使用兼容的随机排序逻辑
                    speaker_group_list = list(speaker_groups.keys())
                    
                    # 使用固定的随机种子确保排序一致性
                    random.seed(hash(f"{username}_speakers") % (2**32))
                    random.shuffle(speaker_group_list)
                    random.seed()
                    
                    sorted_groups = speaker_group_list
                    
                    # 保存到数据库
                    self._save_user_speaker_order(username, sorted_groups)
                    
                    return sorted_groups
            
        except Exception as e:
            print(f"获取用户说话人排序失败: {e}")
            # 降级处理：返回随机排序（不再特殊处理spk2和spk11）
            speaker_group_list = list(speaker_groups.keys())
            
            # 随机打乱所有说话人
            random.seed(hash(username) % (2**32))
            random.shuffle(speaker_group_list)
            random.seed()
            
            return speaker_group_list
    
    def _save_user_speaker_order(self, username, speaker_order):
        """
        保存用户的说话人排序到数据库
        
        Args:
            username (str): 用户名
            speaker_order (list): 说话人排序列表
        """
        try:
            with self.db_service.get_connection() as conn:
                cursor = conn.cursor()
                
                # 获取用户的 group_id
                cursor.execute("SELECT group_id FROM users WHERE wechat_name = ?", (username,))
                user_result = cursor.fetchone()
                group_id = user_result[0] if user_result else None
                
                cursor.execute('''
                    INSERT OR REPLACE INTO user_speaker_orders 
                    (username, speaker_order, group_id, updated_at)
                    VALUES (?, ?, ?, ?)
                ''', (
                    username,
                    json.dumps(speaker_order, ensure_ascii=False),
                    group_id,
                    datetime.now().isoformat()
                ))
                
                conn.commit()
            
        except Exception as e:
            print(f"保存用户说话人排序失败: {e}")
    
    def get_user_audio_order(self, speaker, username, audio_files):
        """
        获取用户专属的音频文件排序
        
        Args:
            speaker (str): 说话人
            username (str): 用户名
            audio_files (list): 音频文件列表
            
        Returns:
            list: 排序后的音频文件列表
        """
        try:
            with self.db_service.get_connection() as conn:
                cursor = conn.cursor()
                
                # 检查用户是否有分配的group_id
                cursor.execute("SELECT group_id FROM users WHERE wechat_name = ?", (username,))
                user_result = cursor.fetchone()
                if not user_result or user_result[0] is None:
                    # 用户没有分配group_id，不生成排序数据，返回原始列表
                    return audio_files
                
                # 查询用户的音频文件排序
                cursor.execute(
                    "SELECT audio_order FROM user_audio_orders WHERE username = ? AND speaker = ?",
                    (username, speaker)
                )
                result = cursor.fetchone()
                
                audio_file_names = [os.path.basename(f) for f in audio_files]
                
                if result:
                    # 使用保存的排序（预生成的固定排序）
                    saved_order = json.loads(result[0])
                    sorted_files = []
                    saved_names = set(saved_order)
                    current_names = set(audio_file_names)
                    
                    # 添加已保存顺序的文件
                    for name in saved_order:
                        if name in current_names:
                            for full_path in audio_files:
                                if os.path.basename(full_path) == name:
                                    sorted_files.append(full_path)
                                    break
                    
                    # 添加新文件（如果有的话）
                    new_files = current_names - saved_names
                    if new_files:
                        new_file_paths = [f for f in audio_files if os.path.basename(f) in new_files]
                        # 对新文件也使用固定的随机种子
                        seed_string = f"{username}_{speaker}_new_audio"
                        random.seed(hash(seed_string) % (2**32))
                        random.shuffle(new_file_paths)
                        random.seed()
                        sorted_files.extend(new_file_paths)
                        
                        # 更新保存的顺序
                        updated_order = [os.path.basename(f) for f in sorted_files]
                        self._save_user_audio_order(username, speaker, updated_order)
                    
                    return sorted_files
                else:
                    # 如果数据库中没有排序数据，说明是旧用户或未分配分组的用户
                    # 使用兼容的随机排序逻辑
                    seed_string = f"{username}_{speaker}_audio"
                    random.seed(hash(seed_string) % (2**32))
                    random.shuffle(audio_files)
                    random.seed()
                    sorted_files = audio_files
                    
                    # 保存排序
                    audio_order = [os.path.basename(f) for f in sorted_files]
                    self._save_user_audio_order(username, speaker, audio_order)
                    
                    return sorted_files
            
        except Exception as e:
            print(f"获取用户音频排序失败: {e}")
            # 降级处理：返回随机排序
            seed_string = f"{username}_{speaker}"
            random.seed(hash(seed_string) % (2**32))
            random.shuffle(audio_files)
            random.seed()
            return audio_files
    
    def _save_user_audio_order(self, username, speaker, audio_order):
        """
        保存用户的音频文件排序到数据库
        
        Args:
            username (str): 用户名
            speaker (str): 说话人
            audio_order (list): 音频文件排序列表
        """
        try:
            with self.db_service.get_connection() as conn:
                cursor = conn.cursor()
                
                # 获取用户的 group_id
                cursor.execute("SELECT group_id FROM users WHERE wechat_name = ?", (username,))
                user_result = cursor.fetchone()
                group_id = user_result[0] if user_result else None
                
                # 先删除该用户和说话人的现有记录，再插入新记录
                # 这样确保即使用户更换组，也不会有重复记录
                cursor.execute('''
                    DELETE FROM user_audio_orders 
                    WHERE username = ? AND speaker = ?
                ''', (username, speaker))
                
                cursor.execute('''
                    INSERT INTO user_audio_orders 
                    (username, speaker, audio_order, group_id, updated_at)
                    VALUES (?, ?, ?, ?, ?)
                ''', (
                    username,
                    speaker,
                    json.dumps(audio_order, ensure_ascii=False),
                    group_id,
                    datetime.now().isoformat()
                ))
                
                conn.commit()
            
        except Exception as e:
            print(f"保存用户音频排序失败: {e}")
    
    def delete_user_orders(self, username):
        """
        删除用户的所有排序数据
        
        Args:
            username (str): 用户名
        """
        try:
            with self.db_service.get_connection() as conn:
                cursor = conn.cursor()
                
                # 删除说话人排序
                cursor.execute(
                    "DELETE FROM user_speaker_orders WHERE username = ?",
                    (username,)
                )
                
                # 删除音频排序
                cursor.execute(
                    "DELETE FROM user_audio_orders WHERE username = ?",
                    (username,)
                )
                
                conn.commit()
            
        except Exception as e:
            print(f"删除用户排序数据失败: {e}")
    
    def get_user_order_statistics(self, username):
        """
        获取用户排序统计信息
        
        Args:
            username (str): 用户名
            
        Returns:
            dict: 统计信息
        """
        try:
            with self.db_service.get_connection() as conn:
                cursor = conn.cursor()
                
                # 获取说话人排序数量
                cursor.execute(
                    "SELECT COUNT(*) FROM user_speaker_orders WHERE username = ?",
                    (username,)
                )
                speaker_orders = cursor.fetchone()[0]
                
                # 获取音频排序数量
                cursor.execute(
                    "SELECT COUNT(*) FROM user_audio_orders WHERE username = ?",
                    (username,)
                )
                audio_orders = cursor.fetchone()[0]
                
                return {
                    'speaker_orders': speaker_orders,
                    'audio_orders': audio_orders
                }
            
        except Exception as e:
            print(f"获取用户排序统计失败: {e}")
            return {
                'speaker_orders': 0,
                'audio_orders': 0
            }