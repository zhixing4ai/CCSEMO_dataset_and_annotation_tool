import os
import shutil
from config import Config
from utils.file_utils import safe_json_load, safe_json_save
from services.order_service import OrderService
from .database_service import DatabaseService
from utils.logger import emotion_logger

class UserService:
    """用户相关服务"""
    
    def __init__(self):
        self.db_service = DatabaseService()
        self.order_service = OrderService()
    
    def update_username(self, old_username, new_username):
        """更新用户名并移动文件"""
        try:
            old_user_dir = os.path.join(Config.DATABASE_FOLDER, old_username)
            new_user_dir = os.path.join(Config.DATABASE_FOLDER, new_username)
            
            moved_count = 0
            
            emotion_logger.log_system_event(
                "开始更新用户名",
                {"old_username": old_username, "new_username": new_username}
            )
            
            if not os.path.exists(old_user_dir):
                return {'success': True, 'moved_files': 0}
            
            os.makedirs(new_user_dir, exist_ok=True)
            
            # 移动所有JSON文件并更新用户名
            for filename in os.listdir(old_user_dir):
                if filename.endswith('.json'):
                    old_file_path = os.path.join(old_user_dir, filename)
                    new_file_path = os.path.join(new_user_dir, filename)
                    
                    # 读取并更新用户名
                    data = safe_json_load(old_file_path, [])
                    for item in data:
                        if item.get("username") == old_username:
                            item["username"] = new_username
                    
                    # 保存到新位置
                    safe_json_save(new_file_path, data)
                    moved_count += 1
            
            # 删除旧目录
            if moved_count > 0:
                shutil.rmtree(old_user_dir)
            
            # 更新数据库中的用户排序数据
            UserService._update_user_orders_in_db(old_username, new_username)
            
            emotion_logger.log_system_event(
                "用户名更新完成",
                {
                    "old_username": old_username,
                    "new_username": new_username,
                    "moved_files": moved_count
                }
            )
            
            return {'success': True, 'moved_files': moved_count}
            
        except Exception as e:
            emotion_logger.log_error(
                e,
                f"更新用户名失败: {old_username} -> {new_username}",
                old_username
            )
            return {'success': False, 'error': str(e)}
    
    def _update_user_orders_in_db(self, old_username, new_username):
        """
        更新数据库中的用户排序数据
        
        Args:
            old_username (str): 旧用户名
            new_username (str): 新用户名
        """
        try:
            with self.db_service.get_connection() as conn:
                cursor = conn.cursor()
                
                # 更新说话人排序表中的用户名
                cursor.execute(
                    "UPDATE user_speaker_orders SET username = ? WHERE username = ?",
                    (new_username, old_username)
                )
                
                # 更新音频排序表中的用户名
                cursor.execute(
                    "UPDATE user_audio_orders SET username = ? WHERE username = ?",
                    (new_username, old_username)
                )
                
                # 更新情感标注表中的用户名
                cursor.execute(
                    "UPDATE emotion_labels SET username = ? WHERE username = ?",
                    (new_username, old_username)
                )
                
                conn.commit()
            
            print(f"已更新数据库中用户 {old_username} 的数据为 {new_username}")
            
        except Exception as e:
            print(f"更新数据库中用户数据失败: {e}")
    
    def delete_user_data(self, username):
        """
        删除用户的所有数据
        
        Args:
            username (str): 用户名
        """
        try:
            # 删除数据库中的排序数据
            self.order_service.delete_user_orders(username)
            
            # 使用统一的数据库连接删除所有相关数据
            with self.db_service.get_connection() as conn:
                cursor = conn.cursor()
                
                # 删除标注数据
                cursor.execute(
                    "DELETE FROM emotion_labels WHERE username = ?",
                    (username,)
                )
                
                # 删除用户分组数据
                cursor.execute(
                    "DELETE FROM group_assignments WHERE username = ?",
                    (username,)
                )
                
                # 删除一致性测试结果
                cursor.execute(
                    "DELETE FROM consistency_test_results WHERE username = ?",
                    (username,)
                )
                
                # 删除第二次一致性测试结果
                cursor.execute(
                    "DELETE FROM second_consistency_test_results WHERE username = ?",
                    (username,)
                )
                
                # 删除用户的spk权限设置
                cursor.execute(
                    "DELETE FROM user_speaker_permissions WHERE username = ?",
                    (username,)
                )
                
                # 删除users表中的用户记录（统一数据库中的用户表）
                cursor.execute(
                    "DELETE FROM users WHERE wechat_name = ?",
                    (username,)
                )
                
                conn.commit()
            
            # 删除文件系统中的用户目录（如果存在）
            user_dir = os.path.join(Config.DATABASE_FOLDER, username)
            if os.path.exists(user_dir):
                shutil.rmtree(user_dir)
            
            emotion_logger.log_system_event(
                f"已删除用户 {username} 的所有数据",
                {"username": username, "operation": "delete_user_data"}
            )
            
        except Exception as e:
            emotion_logger.log_error(
                e,
                f"删除用户数据失败: {username}",
                username
            )
            raise e