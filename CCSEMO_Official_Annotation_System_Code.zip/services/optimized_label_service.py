# -*- coding: utf-8 -*-
"""
优化的标注服务 - 解决多用户并发卡顿问题
主要优化：
1. 使用单例数据库连接
2. 优化的事务处理
3. 减少锁竞争
"""

import os
import sqlite3
import threading
import time
from typing import Dict, Any
from config import Config
try:
    from utils.logger import emotion_logger
except ImportError:
    # 如果导入失败，创建简单的logger替代
    class SimpleLogger:
        def log_database_operation(self, **kwargs):
            pass
    emotion_logger = SimpleLogger()

try:
    from models.emotion_model import EmotionLabel
except ImportError:
    # 如果找不到EmotionLabel，创建简单的替代
    class EmotionLabel:
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

class OptimizedLabelService:
    """优化的标注服务类"""
    
    # 类级别的锁和连接配置
    _lock = threading.RLock()
    _db_path = None
    
    def __init__(self):
        if OptimizedLabelService._db_path is None:
            OptimizedLabelService._db_path = os.path.join(Config.DATABASE_FOLDER, 'unified_emotion_system.db')
    
    @staticmethod
    def _get_optimized_connection():
        """获取优化的数据库连接"""
        conn = sqlite3.connect(
            OptimizedLabelService._db_path, 
            timeout=30.0, 
            check_same_thread=False
        )
        conn.row_factory = sqlite3.Row
        
        # 优化并发性能的PRAGMA设置
        conn.execute('PRAGMA journal_mode=WAL;')
        conn.execute('PRAGMA synchronous=NORMAL;')
        conn.execute('PRAGMA busy_timeout=30000;')  # 30秒超时
        conn.execute('PRAGMA cache_size=-64000;')   # 64MB缓存
        conn.execute('PRAGMA temp_store=MEMORY;')
        
        return conn
    
    def save_label_optimized(self, label_data: Dict[str, Any], speaker: str, audio_file_path: str) -> bool:
        """
        优化的标注保存方法
        
        Args:
            label_data: 标注数据字典
            speaker: 说话人
            audio_file_path: 音频文件路径
            
        Returns:
            bool: 保存是否成功
        """
        # 使用类级别锁减少锁竞争
        with self._lock:
            return self._save_label_internal(label_data, speaker, audio_file_path)
    
    def _save_label_internal(self, label_data: Dict[str, Any], speaker: str, audio_file_path: str) -> bool:
        """内部保存方法"""
        conn = None
        try:
            # 处理分组说话人逻辑
            import re
            speaker_base = speaker
            if re.match(r'spk\d+(-.+)?$', speaker):
                speaker_base = speaker.split('-')[0]
            
            # 获取优化的连接
            conn = self._get_optimized_connection()
            cursor = conn.cursor()
            
            # 开始事务（使用IMMEDIATE模式减少死锁）
            conn.execute('BEGIN IMMEDIATE;')
            
            try:
                # 查询现有记录的所有字段，用于数据合并
                cursor.execute('''
                    SELECT v_value, a_value, emotion_type, discrete_emotion, patient_status,
                           audio_duration, play_count FROM emotion_labels 
                    WHERE audio_file = ? AND speaker = ? AND username = ?
                ''', (label_data.get("audio_file"), speaker_base, label_data.get("username")))
                
                existing_record = cursor.fetchone()
                
                # 数据合并逻辑：优先使用新数据，如果新数据为None则保留现有数据
                if existing_record:
                    # 合并VA值
                    merged_v_value = label_data.get("v_value") if label_data.get("v_value") is not None else existing_record['v_value']
                    merged_a_value = label_data.get("a_value") if label_data.get("a_value") is not None else existing_record['a_value']
                    
                    # 合并离散情感值
                    merged_emotion_type = label_data.get("emotion_type") if label_data.get("emotion_type") is not None else existing_record['emotion_type']
                    merged_discrete_emotion = label_data.get("discrete_emotion") if label_data.get("discrete_emotion") is not None else existing_record['discrete_emotion']
                    merged_patient_status = label_data.get("patient_status") if label_data.get("patient_status") is not None else existing_record['patient_status']
                    
                    # 使用已有音频时长和播放次数
                    audio_duration = existing_record['audio_duration'] if existing_record['audio_duration'] and existing_record['audio_duration'] > 0 else 0.0
                    play_count = existing_record['play_count'] or 0
                else:
                    # 新记录，直接使用传入的数据
                    merged_v_value = label_data.get("v_value")
                    merged_a_value = label_data.get("a_value")
                    merged_emotion_type = label_data.get("emotion_type")
                    merged_discrete_emotion = label_data.get("discrete_emotion")
                    merged_patient_status = label_data.get("patient_status")
                    audio_duration = 0.0
                    play_count = 0
                
                # 创建标注对象，使用合并后的数据
                label = EmotionLabel(
                    audio_file=label_data.get("audio_file"),
                    v_value=merged_v_value,
                    a_value=merged_a_value,
                    emotion_type=merged_emotion_type,
                    discrete_emotion=merged_discrete_emotion,
                    username=label_data.get("username"),
                    patient_status=merged_patient_status,
                    audio_duration=audio_duration
                )
                
                # 高效的插入或更新操作
                cursor.execute('''
                    INSERT OR REPLACE INTO emotion_labels (
                        audio_file, speaker, username, v_value, a_value,
                        emotion_type, discrete_emotion, patient_status,
                        audio_duration, play_count, va_complete, discrete_complete
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    label.audio_file,
                    speaker_base,
                    label.username,
                    label.v_value,
                    label.a_value,
                    label.emotion_type,
                    label.discrete_emotion,
                    label.patient_status,
                    label.audio_duration,
                    play_count,
                    int(label.va_complete),
                    int(label.discrete_complete)
                ))
                
                # 记录操作日志
                emotion_logger.log_database_operation(
                    operation="INSERT OR REPLACE",
                    table="emotion_labels",
                    username=label.username,
                    details={
                        "audio_file": label.audio_file,
                        "speaker": speaker,
                        "optimized": True
                    },
                    success=True
                )
                
                # 跳过分组进度更新（异步处理）
                # 这是性能优化的关键 - 移除同步的进度更新
                
                # 提交事务
                conn.commit()
                return True
                
            except Exception as e:
                conn.rollback()
                raise e
                
        except Exception as e:
            emotion_logger.log_database_operation(
                operation="INSERT OR REPLACE",
                table="emotion_labels",
                username=label_data.get("username", "unknown"),
                details={"audio_file": label_data.get("audio_file"), "error": str(e), "optimized": True},
                success=False
            )
            print(f"优化保存标注数据时出错: {e}")
            return False
            
        finally:
            if conn:
                conn.close()
    
    def get_labeled_files(self, username: str, speaker: str):
        """
        获取已标注的文件列表
        
        Args:
            username: 用户名
            speaker: 说话人
            
        Returns:
            tuple: (已标注文件集合, 标注完整性字典)
        """
        conn = None
        try:
            conn = self._get_optimized_connection()
            cursor = conn.cursor()
            
            # 处理分组说话人
            import re
            # 如果speaker包含分组后缀，精确匹配；否则查询所有相关记录
            if '-' in speaker and re.match(r'spk\d+-.+$', speaker):
                # 精确匹配带分组后缀的speaker
                cursor.execute('''
                    SELECT audio_file, v_value, a_value, emotion_type, 
                           discrete_emotion, patient_status, va_complete, discrete_complete
                    FROM emotion_labels 
                    WHERE username = ? AND speaker = ?
                ''', (username, speaker))
            else:
                # 查询基础speaker的所有记录（包括有分组和无分组的）
                speaker_base = speaker.split('-')[0]
                cursor.execute('''
                    SELECT audio_file, v_value, a_value, emotion_type, 
                           discrete_emotion, patient_status, va_complete, discrete_complete
                    FROM emotion_labels 
                    WHERE username = ? AND (speaker = ? OR speaker LIKE ?)
                ''', (username, speaker_base, f"{speaker_base}-%"))
            
            rows = cursor.fetchall()
            
            labeled_files = set()
            annotation_completeness = {}
            
            for row in rows:
                filename = row['audio_file']
                labeled_files.add(filename)
                
                # 计算标注完整性
                try:
                    from models.emotion_model import calculate_annotation_completeness
                    label_dict = dict(row)
                    completeness = calculate_annotation_completeness(label_dict)
                    annotation_completeness[filename] = completeness
                except ImportError:
                    # 如果模块不存在，使用简单的完整性计算
                    completeness = []
                    if row['va_complete']:
                        completeness.append('va_complete')
                    if row['discrete_complete']:
                        completeness.append('discrete_complete')
                    if not completeness:
                        completeness = ['none']
                    annotation_completeness[filename] = completeness
            
            return labeled_files, annotation_completeness
            
        except Exception as e:
            print(f"获取已标注文件列表失败: {e}")
            return set(), {}
        finally:
            if conn:
                conn.close()
    
    def get_label(self, username: str, speaker: str, filename: str):
        """获取标注数据"""
        conn = None
        try:
            conn = self._get_optimized_connection()
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT * FROM emotion_labels 
                WHERE username = ? AND speaker = ? AND audio_file = ?
            ''', (username, speaker, filename))
            
            result = cursor.fetchone()
            return dict(result) if result else None
            
        except Exception as e:
            print(f"获取标注数据失败: {e}")
            return None
        finally:
            if conn:
                conn.close()
    
    def save_play_count(self, username: str, speaker: str, filename: str):
        """保存音频播放次数（优化版本）"""
        conn = None
        try:
            conn = self._get_optimized_connection()
            cursor = conn.cursor()
            
            # 使用原子操作更新播放次数
            cursor.execute('''
                UPDATE emotion_labels 
                SET play_count = COALESCE(play_count, 0) + 1 
                WHERE username = ? AND speaker = ? AND audio_file = ?
            ''', (username, speaker, filename))
            
            # 如果没有记录，插入新记录
            if cursor.rowcount == 0:
                cursor.execute('''
                    INSERT OR IGNORE INTO emotion_labels 
                    (username, speaker, audio_file, play_count) 
                    VALUES (?, ?, ?, 1)
                ''', (username, speaker, filename))
            
            conn.commit()
            return True
            
        except Exception as e:
            print(f"更新播放次数失败: {e}")
            return False
        finally:
            if conn:
                conn.close()
    
    def get_play_count(self, username: str, speaker: str, filename: str):
        """获取音频播放次数"""
        conn = None
        try:
            conn = self._get_optimized_connection()
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT play_count FROM emotion_labels 
                WHERE username = ? AND speaker = ? AND audio_file = ?
            ''', (username, speaker, filename))
            
            result = cursor.fetchone()
            return result['play_count'] if result and result['play_count'] else 0
            
        except Exception as e:
            print(f"获取播放次数失败: {e}")
            return 0
        finally:
            if conn:
                conn.close()

# 创建全局单例实例
optimized_label_service = OptimizedLabelService()